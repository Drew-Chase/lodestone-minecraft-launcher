// modals.jsx — Quick-action modals (New Instance, Import, Join Server, Co-op Sync)
// Each modal renders over a dimmed AppFrame so context is preserved.

function ModalShell({ title, subtitle, icon, accent = 'var(--mc-green)', width = 720, children, footer }) {
  const IconC = icon;
  return (
    <div style={{
      position: 'absolute', inset: 0,
      background: 'rgba(6, 10, 8, 0.62)',
      backdropFilter: 'blur(14px) saturate(110%)',
      WebkitBackdropFilter: 'blur(14px) saturate(110%)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 50,
    }}>
      <div style={{
        width, maxHeight: 'calc(100% - 80px)',
        background: 'linear-gradient(180deg, rgba(28,34,30,0.96), rgba(18,22,20,0.96))',
        border: '1px solid color-mix(in oklab, ' + accent + ' 24%, var(--line))',
        borderRadius: 18,
        boxShadow: `0 30px 80px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.03) inset, 0 0 60px color-mix(in oklab, ${accent} 18%, transparent)`,
        display: 'flex', flexDirection: 'column',
        overflow: 'hidden',
      }}>
        {/* Header */}
        <div style={{
          padding: '18px 22px 16px',
          display: 'flex', alignItems: 'center', gap: 14,
          borderBottom: '1px solid var(--line)',
          position: 'relative',
        }}>
          <div style={{
            width: 40, height: 40, borderRadius: 10,
            background: `color-mix(in oklab, ${accent} 18%, transparent)`,
            border: `1px solid color-mix(in oklab, ${accent} 35%, transparent)`,
            color: accent,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0,
          }}>
            {IconC && <IconC size={20}/>}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 16, fontWeight: 700, letterSpacing: -0.3 }}>{title}</div>
            {subtitle && <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 2 }}>{subtitle}</div>}
          </div>
          <button style={{
            width: 32, height: 32, borderRadius: 8,
            background: 'transparent', border: '1px solid var(--line)',
            color: 'var(--ink-2)', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <I.x size={14}/>
          </button>
          {/* top accent glow */}
          <div style={{
            position: 'absolute', top: 0, left: '10%', right: '10%', height: 1,
            background: `linear-gradient(90deg, transparent, ${accent}, transparent)`,
            opacity: 0.6,
          }}/>
        </div>

        {/* Body */}
        <div style={{ padding: '20px 22px', overflow: 'auto', flex: 1 }}>
          {children}
        </div>

        {/* Footer */}
        {footer && (
          <div style={{
            padding: '14px 22px',
            borderTop: '1px solid var(--line)',
            display: 'flex', justifyContent: 'flex-end', gap: 10,
            background: 'rgba(0,0,0,0.25)',
          }}>
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

function FooterBtn({ children, primary, accent = 'var(--mc-green)' }) {
  return (
    <button style={{
      padding: '9px 18px', borderRadius: 9,
      fontSize: 13, fontWeight: 600,
      cursor: 'pointer',
      ...(primary ? {
        background: accent, color: '#072010',
        border: '1px solid ' + accent,
        boxShadow: `0 0 20px color-mix(in oklab, ${accent} 45%, transparent)`,
      } : {
        background: 'transparent', color: 'var(--ink-1)',
        border: '1px solid var(--line)',
      }),
    }}>{children}</button>
  );
}

// ─── Modal 1: New Instance ───────────────────────────────────────────

function ModalNewInstance() {
  const loaders = [
    { id: 'vanilla',  name: 'Vanilla',   color: '#9aa4ae', desc: 'Unmodded Minecraft' },
    { id: 'fabric',   name: 'Fabric',    color: '#c9b88c', desc: 'Lightweight, fast startup' },
    { id: 'forge',    name: 'Forge',     color: '#5a7fb3', desc: 'Largest mod ecosystem' },
    { id: 'neoforge', name: 'NeoForge',  color: '#e08548', desc: 'Modern Forge fork' },
    { id: 'quilt',    name: 'Quilt',     color: '#c16fa3', desc: 'Fabric-compatible' },
  ];
  return (
    <ModalShell
      title="New Instance"
      subtitle="Spin up a fresh Minecraft profile. Pick version and loader, we'll do the rest."
      icon={I.plus}
      width={740}
      footer={<><FooterBtn>Cancel</FooterBtn><FooterBtn primary>Create Instance</FooterBtn></>}
    >
      {/* Name */}
      <Label>Instance name</Label>
      <InputRow placeholder="My New Instance" value="Dragon Survival v2"/>

      {/* Version + loader row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 16 }}>
        <div>
          <Label>Minecraft version</Label>
          <VersionPicker/>
        </div>
        <div>
          <Label>Java</Label>
          <SelectRow value="Java 21 (bundled)" hint="Auto-matched to version"/>
        </div>
      </div>

      {/* Loader cards */}
      <Label style={{ marginTop: 18 }}>Mod loader</Label>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 8 }}>
        {loaders.map((l, i) => (
          <div key={l.id} style={{
            padding: 12, borderRadius: 10,
            border: i === 1 ? `1.5px solid ${l.color}` : '1px solid var(--line)',
            background: i === 1 ? `color-mix(in oklab, ${l.color} 10%, transparent)` : 'rgba(255,255,255,0.02)',
            cursor: 'pointer',
            position: 'relative',
          }}>
            <div style={{
              width: 28, height: 28, borderRadius: 7, marginBottom: 8,
              background: `linear-gradient(135deg, ${l.color}, color-mix(in oklab, ${l.color} 60%, #000))`,
              boxShadow: i === 1 ? `0 0 12px ${l.color}80` : 'none',
            }}/>
            <div style={{ fontSize: 12, fontWeight: 600 }}>{l.name}</div>
            <div style={{ fontSize: 10, color: 'var(--ink-3)', marginTop: 2, lineHeight: 1.3 }}>{l.desc}</div>
            {i === 1 && (
              <div style={{ position: 'absolute', top: 6, right: 6, color: l.color }}>
                <I.check size={12}/>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Quick-start templates */}
      <div style={{ marginTop: 18, padding: 14, borderRadius: 12,
                    background: 'rgba(34,255,132,0.04)',
                    border: '1px dashed color-mix(in oklab, var(--mc-green) 20%, transparent)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--mc-green)' }}>Quick start from template</div>
            <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>Curated setups for common playstyles</div>
          </div>
          <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>OPTIONAL</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          {[
            { icon: I.sword, label: 'Performance', mods: 24 },
            { icon: I.pickaxe, label: 'Tech & Auto', mods: 86 },
            { icon: I.shield, label: 'Adventure', mods: 45 },
            { icon: I.image, label: 'Shaders + RP', mods: 12 },
          ].map((t, i) => {
            const IC = t.icon;
            return (
              <div key={i} style={{
                flex: 1, padding: '10px 10px', borderRadius: 8,
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid var(--line)',
                display: 'flex', flexDirection: 'column', gap: 6, cursor: 'pointer',
              }}>
                <IC size={14} style={{ color: 'var(--ink-2)' }}/>
                <div style={{ fontSize: 11, fontWeight: 600 }}>{t.label}</div>
                <div style={{ fontSize: 10, color: 'var(--ink-3)' }}>{t.mods} mods</div>
              </div>
            );
          })}
        </div>
      </div>
    </ModalShell>
  );
}

function Label({ children, style }) {
  return <div style={{ fontSize: 10, fontWeight: 600, letterSpacing: 1, color: 'var(--ink-3)',
    textTransform: 'uppercase', marginBottom: 6, fontFamily: 'var(--mono)', ...style }}>{children}</div>;
}
function InputRow({ value, placeholder, icon }) {
  const IC = icon;
  return (
    <div style={{ position: 'relative' }}>
      {IC && <IC size={14} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--ink-3)' }}/>}
      <input defaultValue={value} placeholder={placeholder} style={{
        width: '100%', padding: IC ? '10px 12px 10px 34px' : '10px 12px',
        background: 'rgba(0,0,0,0.3)', border: '1px solid var(--line)',
        borderRadius: 9, color: 'var(--ink-0)', fontSize: 13,
        fontFamily: 'var(--sans)', outline: 'none', boxSizing: 'border-box',
      }}/>
    </div>
  );
}
function SelectRow({ value, hint }) {
  return (
    <div style={{
      padding: '10px 12px', background: 'rgba(0,0,0,0.3)',
      border: '1px solid var(--line)', borderRadius: 9,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer',
    }}>
      <div>
        <div style={{ fontSize: 13, color: 'var(--ink-0)' }}>{value}</div>
        {hint && <div style={{ fontSize: 10, color: 'var(--ink-3)', marginTop: 1 }}>{hint}</div>}
      </div>
      <I.chevDown size={14} style={{ color: 'var(--ink-3)' }}/>
    </div>
  );
}
function VersionPicker() {
  return (
    <div style={{
      padding: '10px 12px', background: 'rgba(0,0,0,0.3)',
      border: '1px solid var(--line)', borderRadius: 9,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{ fontSize: 13, color: 'var(--ink-0)', fontFamily: 'var(--mono)' }}>1.21.4</div>
        <div style={{ fontSize: 10, padding: '2px 6px', borderRadius: 4,
          background: 'color-mix(in oklab, var(--mc-green) 18%, transparent)',
          color: 'var(--mc-green)', fontWeight: 600 }}>LATEST RELEASE</div>
      </div>
      <I.chevDown size={14} style={{ color: 'var(--ink-3)' }}/>
    </div>
  );
}

// ─── Modal 2: Import ─────────────────────────────────────────────────

function ModalImport() {
  const recents = [
    { name: 'Better MC [FABRIC] v27', size: '512 MB', source: 'CurseForge', time: '2h ago' },
    { name: 'Fabulously Optimized', size: '84 MB', source: '.mrpack', time: 'yesterday' },
    { name: 'All the Mods 10', size: '1.2 GB', source: 'CurseForge', time: '3d ago' },
  ];
  return (
    <ModalShell
      title="Import Instance"
      subtitle="From a modpack file, CurseForge URL, or backup archive."
      icon={I.download}
      accent="var(--cyan)"
      width={720}
      footer={<><FooterBtn>Cancel</FooterBtn><FooterBtn primary accent="var(--cyan)">Import</FooterBtn></>}
    >
      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, padding: 4, borderRadius: 10,
                    background: 'rgba(0,0,0,0.3)', border: '1px solid var(--line)',
                    marginBottom: 18 }}>
        {['From file', 'From URL', 'Restore backup'].map((t, i) => (
          <div key={t} style={{
            flex: 1, padding: '8px 12px', borderRadius: 7, textAlign: 'center',
            fontSize: 12, fontWeight: 600,
            cursor: 'pointer',
            background: i === 0 ? 'color-mix(in oklab, var(--cyan) 14%, transparent)' : 'transparent',
            color: i === 0 ? 'var(--cyan)' : 'var(--ink-2)',
            border: i === 0 ? '1px solid color-mix(in oklab, var(--cyan) 30%, transparent)' : '1px solid transparent',
          }}>{t}</div>
        ))}
      </div>

      {/* Drop zone */}
      <div style={{
        padding: '34px 20px', borderRadius: 14,
        border: '2px dashed color-mix(in oklab, var(--cyan) 40%, transparent)',
        background: 'radial-gradient(ellipse at center, rgba(56,224,255,0.09), transparent 70%)',
        textAlign: 'center',
        position: 'relative',
      }}>
        {/* floating file type icons */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: 12, marginBottom: 14 }}>
          {['.zip', '.mrpack', '.mcpack'].map((ext, i) => (
            <div key={ext} style={{
              width: 60, height: 70, borderRadius: 8,
              background: 'linear-gradient(180deg, rgba(40,46,42,0.9), rgba(26,30,28,0.9))',
              border: '1px solid var(--line)',
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
              position: 'relative',
              transform: `rotate(${[-5, 0, 5][i]}deg) translateY(${[4, 0, 4][i]}px)`,
              boxShadow: '0 6px 20px rgba(0,0,0,0.4)',
            }}>
              <div style={{ fontSize: 10, fontFamily: 'var(--mono)', color: 'var(--cyan)',
                  fontWeight: 700, letterSpacing: 0.5 }}>{ext}</div>
              <div style={{ position: 'absolute', bottom: 8, width: 24, height: 2,
                background: 'var(--cyan)', opacity: 0.4, borderRadius: 1 }}/>
              <div style={{ position: 'absolute', bottom: 14, width: 16, height: 2,
                background: 'var(--cyan)', opacity: 0.25, borderRadius: 1 }}/>
            </div>
          ))}
        </div>
        <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>Drop file here</div>
        <div style={{ fontSize: 12, color: 'var(--ink-3)' }}>
          or <span style={{ color: 'var(--cyan)', textDecoration: 'underline', cursor: 'pointer' }}>browse your files</span> · max 4 GB
        </div>
      </div>

      {/* Recent imports */}
      <div style={{ marginTop: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
          <Label style={{ marginBottom: 0 }}>Recent imports</Label>
          <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>LAST 7 DAYS</div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {recents.map((r, i) => (
            <div key={i} style={{
              padding: '10px 12px', borderRadius: 8,
              background: 'rgba(255,255,255,0.02)', border: '1px solid var(--line)',
              display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <div style={{ width: 32, height: 32, borderRadius: 7,
                background: 'color-mix(in oklab, var(--cyan) 14%, transparent)',
                color: 'var(--cyan)', display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0 }}>
                <I.folder size={14}/>
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.name}</div>
                <div style={{ fontSize: 10, color: 'var(--ink-3)', marginTop: 2 }}>
                  {r.source} · {r.size} · {r.time}
                </div>
              </div>
              <button style={{ background: 'transparent', border: '1px solid var(--line)',
                color: 'var(--ink-2)', padding: '5px 10px', borderRadius: 6, fontSize: 11, cursor: 'pointer' }}>
                Reimport
              </button>
            </div>
          ))}
        </div>
      </div>
    </ModalShell>
  );
}

// ─── Modal 3: Join Server ────────────────────────────────────────────

function ModalJoinServer() {
  const saved = [
    { name: 'Hypixel',        addr: 'mc.hypixel.net',    players: '47,218', ping: 24,  motd: 'Largest MC server',  icon: '#ffc93a' },
    { name: "Drew's Survival", addr: '192.168.1.42:25565',players: '3/8',    ping: 8,   motd: 'Private · 1.21.4',   icon: '#22ff84', online: true },
    { name: 'MineVille',      addr: 'play.mineville.org', players: '2,834',  ping: 42,  motd: 'Factions · Skyblock', icon: '#9747ff' },
    { name: 'CubeCraft',      addr: 'play.cubecraft.net', players: '12,901', ping: 38,  motd: 'Minigames',          icon: '#38e0ff' },
  ];
  return (
    <ModalShell
      title="Join Server"
      subtitle="Paste an address, pick a saved server, or hop into Realms."
      icon={I.server}
      accent="var(--amber)"
      width={760}
      footer={<><FooterBtn>Cancel</FooterBtn><FooterBtn primary accent="var(--amber)">Connect</FooterBtn></>}
    >
      {/* Address bar */}
      <Label>Server address</Label>
      <div style={{ display: 'flex', gap: 8 }}>
        <div style={{ flex: 1, position: 'relative' }}>
          <I.globe size={14} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--amber)' }}/>
          <input defaultValue="mc.hypixel.net" style={{
            width: '100%', padding: '11px 12px 11px 34px',
            background: 'rgba(0,0,0,0.3)', border: '1px solid color-mix(in oklab, var(--amber) 22%, var(--line))',
            borderRadius: 9, color: 'var(--ink-0)', fontSize: 13,
            fontFamily: 'var(--mono)', outline: 'none', boxSizing: 'border-box',
          }}/>
        </div>
        <button style={{
          padding: '11px 14px', borderRadius: 9,
          background: 'rgba(255,255,255,0.04)', border: '1px solid var(--line)',
          color: 'var(--ink-1)', fontSize: 12, fontWeight: 600,
          display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer',
        }}>
          <I.zap size={13}/>
          Test
        </button>
      </div>

      {/* Instance picker */}
      <div style={{ marginTop: 14, padding: '10px 12px', borderRadius: 9,
                    background: 'rgba(255,255,255,0.02)', border: '1px solid var(--line)',
                    display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>Launch with:</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 10px',
                      borderRadius: 6, background: 'rgba(34,255,132,0.08)',
                      border: '1px solid color-mix(in oklab, var(--mc-green) 22%, transparent)' }}>
          <div style={{ width: 16, height: 16, borderRadius: 3,
            background: 'linear-gradient(135deg, #5d3e1e, #3a2612)' }}/>
          <div style={{ fontSize: 11, fontWeight: 600 }}>Dragon Survival v2</div>
          <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>1.21.4</div>
        </div>
        <div style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--cyan)', cursor: 'pointer' }}>Change</div>
      </div>

      {/* Saved servers */}
      <div style={{ marginTop: 22, display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
        <Label style={{ marginBottom: 0 }}>Saved servers</Label>
        <div style={{ fontSize: 11, color: 'var(--amber)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}>
          <I.plus size={12}/> Add server
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {saved.map((s, i) => (
          <div key={i} style={{
            padding: '11px 12px', borderRadius: 9,
            background: i === 1 ? 'color-mix(in oklab, var(--mc-green) 8%, rgba(255,255,255,0.02))' : 'rgba(255,255,255,0.02)',
            border: i === 1 ? '1px solid color-mix(in oklab, var(--mc-green) 22%, transparent)' : '1px solid var(--line)',
            display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer',
          }}>
            <div style={{
              width: 36, height: 36, borderRadius: 7, flexShrink: 0,
              background: `linear-gradient(135deg, ${s.icon}, color-mix(in oklab, ${s.icon} 55%, #000))`,
              position: 'relative',
            }}>
              {s.online && <div style={{
                position: 'absolute', bottom: -2, right: -2, width: 10, height: 10, borderRadius: '50%',
                background: 'var(--mc-green)', border: '2px solid #181c1a',
                boxShadow: '0 0 8px var(--mc-green)',
              }}/>}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{s.name}</div>
                <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>{s.addr}</div>
              </div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>{s.motd}</div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 3 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                <PingBars ping={s.ping}/>
                <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>{s.ping}ms</div>
              </div>
              <div style={{ fontSize: 10, color: 'var(--ink-2)', fontFamily: 'var(--mono)' }}>{s.players}</div>
            </div>
          </div>
        ))}
      </div>
    </ModalShell>
  );
}

function PingBars({ ping }) {
  const bars = ping < 30 ? 4 : ping < 60 ? 3 : ping < 120 ? 2 : 1;
  const color = ping < 30 ? 'var(--mc-green)' : ping < 60 ? 'var(--amber)' : '#ff6b6b';
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 1 }}>
      {[5, 7, 9, 11].map((h, i) => (
        <div key={i} style={{
          width: 2, height: h,
          background: i < bars ? color : 'var(--line)',
          borderRadius: 0.5,
        }}/>
      ))}
    </div>
  );
}

// ─── Modal 4: Co-op Sync ─────────────────────────────────────────────

function ModalCoopSync() {
  const friends = [
    { name: 'pix_mcrft', tag: 'Playing Better MC', sub: '1.20.1 · Fabric · 86 mods', online: true, avatar: '#e08548', status: 'In Nether' },
    { name: 'Drew_builds', tag: 'Playing All the Mods 10', sub: '1.21.1 · NeoForge · 412 mods', online: true, avatar: '#5a7fb3', status: 'In Overworld' },
    { name: 'stonebreaker', tag: 'Idle in launcher', sub: 'Vanilla 1.21.4', online: true, avatar: '#c16fa3', status: 'Browsing' },
  ];
  return (
    <ModalShell
      title="Co-op Sync"
      subtitle="Mirror a friend's instance, match mods and shaders, then join their world."
      icon={I.users}
      accent="var(--violet)"
      width={720}
      footer={<><FooterBtn>Cancel</FooterBtn><FooterBtn primary accent="var(--violet)">Sync & join</FooterBtn></>}
    >
      {/* Stat bar */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 18 }}>
        {[
          { label: 'Friends online', val: '3', color: 'var(--mc-green)' },
          { label: 'Instances shared', val: '12', color: 'var(--violet)' },
          { label: 'Avg sync time', val: '38s', color: 'var(--cyan)' },
        ].map((s, i) => (
          <div key={i} style={{
            padding: '10px 12px', borderRadius: 9,
            background: 'rgba(255,255,255,0.02)', border: '1px solid var(--line)',
          }}>
            <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)', letterSpacing: 0.5 }}>
              {s.label.toUpperCase()}
            </div>
            <div style={{ fontSize: 20, fontWeight: 700, color: s.color, marginTop: 4 }}>{s.val}</div>
          </div>
        ))}
      </div>

      <Label>Online now</Label>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {friends.map((f, i) => (
          <div key={i} style={{
            padding: '12px 14px', borderRadius: 11,
            background: i === 0 ? 'color-mix(in oklab, var(--violet) 9%, rgba(255,255,255,0.02))' : 'rgba(255,255,255,0.02)',
            border: i === 0 ? '1px solid color-mix(in oklab, var(--violet) 28%, transparent)' : '1px solid var(--line)',
            display: 'flex', alignItems: 'center', gap: 14,
          }}>
            {/* avatar */}
            <div style={{ position: 'relative', flexShrink: 0 }}>
              <div style={{
                width: 44, height: 44, borderRadius: 10,
                background: `linear-gradient(135deg, ${f.avatar}, color-mix(in oklab, ${f.avatar} 50%, #000))`,
                boxShadow: i === 0 ? `0 0 14px color-mix(in oklab, ${f.avatar} 45%, transparent)` : 'none',
                position: 'relative',
              }}>
                {/* pixel face hint */}
                <div style={{ position: 'absolute', top: 12, left: 10, width: 6, height: 6, background: '#1a1a1a', borderRadius: 1 }}/>
                <div style={{ position: 'absolute', top: 12, right: 10, width: 6, height: 6, background: '#1a1a1a', borderRadius: 1 }}/>
                <div style={{ position: 'absolute', top: 24, left: 12, right: 12, height: 3, background: '#1a1a1a', borderRadius: 1 }}/>
              </div>
              {f.online && <div style={{
                position: 'absolute', bottom: -2, right: -2, width: 12, height: 12, borderRadius: '50%',
                background: 'var(--mc-green)', border: '2px solid #181c1a',
                boxShadow: '0 0 8px var(--mc-green)',
              }}/>}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ fontSize: 13, fontWeight: 700 }}>{f.name}</div>
                <div style={{ fontSize: 9, padding: '2px 6px', borderRadius: 3,
                  background: 'rgba(34,255,132,0.12)', color: 'var(--mc-green)',
                  fontFamily: 'var(--mono)', fontWeight: 600 }}>{f.status.toUpperCase()}</div>
              </div>
              <div style={{ fontSize: 12, color: 'var(--ink-1)', marginTop: 3 }}>{f.tag}</div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 1, fontFamily: 'var(--mono)' }}>{f.sub}</div>
            </div>
            {i === 0 ? (
              <button style={{
                padding: '8px 14px', borderRadius: 8,
                background: 'var(--violet)', color: '#fff',
                border: '1px solid var(--violet)',
                fontSize: 12, fontWeight: 600, cursor: 'pointer',
                boxShadow: '0 0 14px color-mix(in oklab, var(--violet) 40%, transparent)',
                display: 'flex', alignItems: 'center', gap: 6,
              }}>
                <I.refresh size={12}/> Sync
              </button>
            ) : (
              <button style={{
                padding: '7px 12px', borderRadius: 8,
                background: 'transparent', color: 'var(--ink-1)',
                border: '1px solid var(--line)',
                fontSize: 12, fontWeight: 600, cursor: 'pointer',
              }}>
                Mirror
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Sync preview */}
      <div style={{
        marginTop: 18, padding: 14, borderRadius: 11,
        background: 'linear-gradient(135deg, rgba(151,71,255,0.08), rgba(56,224,255,0.04))',
        border: '1px solid color-mix(in oklab, var(--violet) 22%, transparent)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
          <I.refresh size={13} style={{ color: 'var(--violet)' }}/>
          <div style={{ fontSize: 12, fontWeight: 600 }}>Sync plan for <span style={{ color: 'var(--violet)' }}>pix_mcrft</span></div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
          {[
            { label: 'Mods', add: 12, skip: 74 },
            { label: 'Shaders', add: 1, skip: 0 },
            { label: 'Resource packs', add: 2, skip: 1 },
            { label: 'Configs', add: 8, skip: 0 },
          ].map((p, i) => (
            <div key={i} style={{ padding: '8px 10px', borderRadius: 7,
              background: 'rgba(0,0,0,0.3)', border: '1px solid var(--line)' }}>
              <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)', letterSpacing: 0.5 }}>
                {p.label.toUpperCase()}
              </div>
              <div style={{ fontSize: 13, fontWeight: 700, marginTop: 3 }}>
                <span style={{ color: 'var(--mc-green)' }}>+{p.add}</span>
                {p.skip > 0 && <span style={{ color: 'var(--ink-3)', fontSize: 10, marginLeft: 4, fontWeight: 500 }}>· {p.skip} kept</span>}
              </div>
            </div>
          ))}
        </div>
      </div>
    </ModalShell>
  );
}

Object.assign(window, { ModalShell, ModalNewInstance, ModalImport, ModalJoinServer, ModalCoopSync });
