// screen-home.jsx — library / home screen
function ScreenHome() {
  const [viewMode, setViewMode] = React.useState('grid'); // 'grid' | 'list' | 'table'

  const instances = [
    { name: 'Aether Legacy', version: '1.20.1 · Fabric', loader: 'Fabric', mc: '1.20.1', biome: 'end', seed: 3, playtime: '24h', lastPlayed: '12m ago', mods: 87, playing: true, color: 'violet' },
    { name: 'Vanilla Survival', version: '1.20.4 · Vanilla', loader: 'Vanilla', mc: '1.20.4', biome: 'forest', seed: 1, playtime: '156h', lastPlayed: '2d ago', mods: 0, color: 'green' },
    { name: 'Create: Above & Beyond', version: '1.16.5 · Forge', loader: 'Forge', mc: '1.16.5', biome: 'desert', seed: 5, playtime: '42h', lastPlayed: '5d ago', mods: 214, color: 'amber' },
    { name: 'RLCraft Extreme', version: '1.12.2 · Forge', loader: 'Forge', mc: '1.12.2', biome: 'nether', seed: 2, playtime: '8h', lastPlayed: '3w ago', mods: 171, color: 'pink' },
    { name: 'SkyFactory 4', version: '1.12.2 · Forge', loader: 'Forge', mc: '1.12.2', biome: 'ocean', seed: 8, playtime: '67h', lastPlayed: '1w ago', mods: 198, color: 'cyan' },
    { name: 'Cherry Grove Peaceful', version: '1.20.4 · Vanilla', loader: 'Vanilla', mc: '1.20.4', biome: 'cherry', seed: 4, playtime: '3h', lastPlayed: '1mo ago', mods: 0, color: 'pink' },
  ];
  const featured = instances[0];

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, background: 'var(--bg-0)' }}>
      <TitleBar title="Library" subtitle="6 instances · 300h total playtime">
        <div style={{ position: 'relative' }}>
          <I.search size={14} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--ink-3)' }}/>
          <input className="input" placeholder="Search instances…" style={{ width: 240, paddingLeft: 34 }}/>
        </div>
        <button className="btn-icon"><I.refresh size={16}/></button>
        <button className="btn-icon"><I.bell size={16}/></button>
        <button className="btn-primary"><I.plus size={14}/> New Instance</button>
      </TitleBar>

      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 28px 40px' }}>
        {/* Hero — currently playing */}
        <div style={{ position: 'relative', height: 260, borderRadius: 20, overflow: 'hidden', marginBottom: 28,
                      boxShadow: '0 20px 40px -20px rgba(0,0,0,0.8)' }}>
          <Scene biome={featured.biome} seed={featured.seed}/>
          <Particles count={12}/>
          {/* Overlay content */}
          <div style={{
            position: 'absolute', inset: 0,
            background: 'linear-gradient(90deg, rgba(8,9,10,0.92) 0%, rgba(8,9,10,0.6) 45%, transparent 80%)',
            display: 'flex', alignItems: 'flex-end', padding: 32,
          }}>
            <div style={{ maxWidth: 500 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                <span className="chip green"><span className="pulse-dot" style={{ width: 6, height: 6 }}/> NOW PLAYING</span>
                <span className="chip violet">FABRIC 0.14.21</span>
                <span className="chip">MC 1.20.1</span>
              </div>
              <div style={{ fontSize: 40, fontWeight: 800, letterSpacing: -1, lineHeight: 1, marginBottom: 8 }}>
                {featured.name}
              </div>
              <div style={{ fontSize: 13, color: 'var(--ink-2)', marginBottom: 20, lineHeight: 1.5 }}>
                Climb the floating islands, battle Slider bosses, uncover a continent hanging in the void.
                <span style={{ color: 'var(--mc-green)', marginLeft: 6 }}>87 mods</span> · last played 12 minutes ago
              </div>
              <div style={{ display: 'flex', gap: 10 }}>
                <button className="btn-primary" style={{ padding: '14px 24px', fontSize: 15 }}>
                  <I.play size={14}/> Resume Session
                </button>
                <button className="btn-icon" title="Open Folder" style={{ width: 42, height: 42 }}><I.folder size={16}/></button>
                <button className="btn-icon" title="Configure" style={{ width: 42, height: 42 }}><I.settings size={16}/></button>
                <button className="btn-icon" title="More" style={{ width: 42, height: 42 }}><I.more size={16}/></button>
              </div>
            </div>
          </div>
          {/* Stats */}
          <div style={{ position: 'absolute', top: 24, right: 24, display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'flex-end' }}>
            <div style={{
              fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-2)',
              padding: '6px 10px', background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(12px)',
              borderRadius: 6, border: '1px solid rgba(255,255,255,0.08)',
              display: 'flex', alignItems: 'center', gap: 6,
            }}>
              <I.cpu size={12}/> 2.1 GB / 6 GB · 58 FPS
            </div>
          </div>
        </div>

        {/* Quick actions */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 32 }}>
          {[
            { icon: I.plus, label: 'New Instance', sub: 'From modpack, curseforge, or scratch', color: 'var(--mc-green)' },
            { icon: I.download, label: 'Import', sub: '.zip, .mrpack, CurseForge', color: 'var(--cyan)' },
            { icon: I.server, label: 'Join Server', sub: 'Realms · hosted · friends', color: 'var(--amber)' },
            { icon: I.users, label: 'Co-op Sync', sub: '3 friends online now', color: 'var(--violet)' },
          ].map((a, i) => {
            const IconC = a.icon;
            return (
              <div key={i} className="card" style={{ padding: '16px 18px', cursor: 'pointer', display: 'flex', gap: 14, alignItems: 'center' }}>
                <div style={{
                  width: 40, height: 40, borderRadius: 10, flexShrink: 0,
                  background: `color-mix(in oklab, ${a.color} 18%, transparent)`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: a.color, border: `1px solid color-mix(in oklab, ${a.color} 30%, transparent)`,
                }}>
                  <IconC size={18}/>
                </div>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{a.label}</div>
                  <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>{a.sub}</div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Section title */}
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 14, gap: 12 }}>
          <div style={{ fontSize: 16, fontWeight: 700, letterSpacing: -0.3 }}>Your Instances</div>
          <div style={{ flex: 1 }}/>
          <div style={{ display: 'flex', gap: 6 }}>
            <button className="tab active" style={{ padding: '6px 12px', fontSize: 12 }}>Recent</button>
            <button className="tab" style={{ padding: '6px 12px', fontSize: 12 }}>Pinned</button>
            <button className="tab" style={{ padding: '6px 12px', fontSize: 12 }}>Modded</button>
            <button className="tab" style={{ padding: '6px 12px', fontSize: 12 }}>Vanilla</button>
          </div>
          <ViewModeToggle mode={viewMode} onChange={setViewMode}/>
        </div>

        {/* Instance list — switches layout */}
        {viewMode === 'grid'    && <InstanceGrid instances={instances}/>}
        {viewMode === 'compact' && <InstanceCompact instances={instances}/>}
        {viewMode === 'table'   && <InstanceTable instances={instances}/>}
      </div>
    </div>
  );
}

/* ---- View mode toggle ---- */
function ViewModeToggle({ mode, onChange }) {
  const opts = [
    { id: 'grid',    icon: I.grid,  label: 'Grid' },
    { id: 'compact', icon: I.list,  label: 'Compact' },
    { id: 'table',   icon: I.table, label: 'Table' },
  ];
  return (
    <div style={{
      display: 'flex', padding: 3, gap: 2,
      background: 'rgba(255,255,255,0.04)',
      border: '1px solid var(--line)',
      borderRadius: 10,
    }}>
      {opts.map(o => {
        const IconC = o.icon;
        const active = mode === o.id;
        return (
          <button key={o.id} onClick={() => onChange(o.id)} title={o.label + ' view'}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '6px 10px', fontSize: 11, fontWeight: 600,
              border: 'none', borderRadius: 7, cursor: 'pointer',
              background: active ? 'color-mix(in oklab, var(--mc-green) 18%, transparent)' : 'transparent',
              color: active ? 'var(--mc-green)' : 'var(--ink-2)',
              boxShadow: active ? 'inset 0 0 0 1px color-mix(in oklab, var(--mc-green) 40%, transparent)' : 'none',
              fontFamily: 'inherit',
            }}>
            <IconC size={13}/>
            <span>{o.label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* ---- Grid view (original) ---- */
function InstanceGrid({ instances }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
      {instances.map((inst, i) => (
        <div key={i} className="card" style={{ cursor: 'pointer' }}>
          <div style={{ position: 'relative', height: 140 }}>
            <Scene biome={inst.biome} seed={inst.seed}/>
            {inst.playing && (
              <div style={{ position: 'absolute', top: 10, left: 10, zIndex: 2 }}>
                <span className="chip green"><span className="pulse-dot" style={{ width: 5, height: 5 }}/> PLAYING</span>
              </div>
            )}
            <div style={{ position: 'absolute', top: 10, right: 10, zIndex: 2 }}>
              <button className="btn-icon" style={{ width: 28, height: 28, background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)' }}>
                <I.more size={14}/>
              </button>
            </div>
            <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, transparent 55%, rgba(0,0,0,0.7) 100%)' }}/>
            <div style={{ position: 'absolute', bottom: 10, left: 12, right: 12, display: 'flex', alignItems: 'flex-end', zIndex: 2 }}>
              <div style={{ minWidth: 0, flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 2 }}>{inst.name}</div>
                <div style={{ fontSize: 10, color: 'var(--ink-2)', fontFamily: 'var(--mono)' }}>{inst.version}</div>
              </div>
              <button className="btn-primary" style={{ padding: '8px 12px', fontSize: 12 }}>
                <I.play size={11}/> Play
              </button>
            </div>
          </div>
          <div style={{ padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 10, fontSize: 11, color: 'var(--ink-3)' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><I.clock size={11}/> {inst.playtime}</span>
            <span>·</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><I.box size={11}/> {inst.mods} mods</span>
            <div style={{ flex: 1 }}/>
            <span className={`chip ${inst.color}`} style={{ fontSize: 9, padding: '2px 6px' }}>
              {inst.version.split(' · ')[1]}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---- Compact view — grid of minimal cards: name, mc version, loader, play + more ---- */
function InstanceCompact({ instances }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
      {instances.map((inst, i) => (
        <div key={i} className="card" style={{
          padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 8, cursor: 'pointer',
        }}>
          {/* Row 1: name + playing dot + overflow */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, minWidth: 0 }}>
            <div style={{
              fontSize: 12, fontWeight: 700, letterSpacing: -0.2,
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1,
            }}>
              {inst.name}
            </div>
            {inst.playing && (
              <span className="pulse-dot" style={{ width: 6, height: 6, flexShrink: 0 }}/>
            )}
            <button className="btn-icon" style={{ width: 22, height: 22, flexShrink: 0 }}><I.more size={12}/></button>
          </div>
          {/* Row 2: mc version + loader chip + inline play */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>
            <span>{inst.mc}</span>
            <span style={{ opacity: 0.5 }}>·</span>
            <span className={`chip ${inst.color}`} style={{ fontSize: 9, padding: '1px 6px' }}>{inst.loader}</span>
            <div style={{ flex: 1 }}/>
            <button className="btn-primary" style={{
              padding: '4px 8px', fontSize: 10, gap: 4,
            }}>
              <I.play size={9}/> Play
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---- unused but retained as reference ---- */
function InstanceList({ instances }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      {instances.map((inst, i) => (
        <div key={i} className="card" style={{ display: 'flex', alignItems: 'stretch', cursor: 'pointer', overflow: 'hidden' }}>
          {/* Thumbnail */}
          <div style={{ position: 'relative', width: 160, flexShrink: 0 }}>
            <Scene biome={inst.biome} seed={inst.seed}/>
            {inst.playing && (
              <div style={{ position: 'absolute', top: 8, left: 8 }}>
                <span className="chip green" style={{ fontSize: 9, padding: '2px 6px' }}>
                  <span className="pulse-dot" style={{ width: 4, height: 4 }}/> PLAYING
                </span>
              </div>
            )}
          </div>
          {/* Body */}
          <div style={{ flex: 1, padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 16, minWidth: 0 }}>
            <div style={{ minWidth: 0, flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                <div style={{ fontSize: 14, fontWeight: 700, letterSpacing: -0.2 }}>{inst.name}</div>
                <span className={`chip ${inst.color}`} style={{ fontSize: 9, padding: '2px 6px' }}>{inst.loader}</span>
              </div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>
                Minecraft {inst.mc} · last played {inst.lastPlayed}
              </div>
            </div>
            {/* Stats cluster */}
            <div style={{ display: 'flex', gap: 18, fontSize: 11, color: 'var(--ink-2)' }}>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontFamily: 'var(--mono)', fontWeight: 600, color: 'var(--ink-1)' }}>{inst.playtime}</div>
                <div style={{ fontSize: 9, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.05 }}>playtime</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontFamily: 'var(--mono)', fontWeight: 600, color: 'var(--ink-1)' }}>{inst.mods}</div>
                <div style={{ fontSize: 9, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.05 }}>mods</div>
              </div>
            </div>
            {/* Actions */}
            <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
              <button className="btn-primary" style={{ padding: '8px 14px', fontSize: 12 }}>
                <I.play size={11}/> Play
              </button>
              <button className="btn-icon" style={{ width: 32, height: 32 }}><I.more size={14}/></button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---- Table view — dense tabular ---- */
function InstanceTable({ instances }) {
  const th = {
    textAlign: 'left', padding: '10px 14px',
    fontSize: 10, fontWeight: 600, letterSpacing: 0.06, textTransform: 'uppercase',
    color: 'var(--ink-3)',
    borderBottom: '1px solid var(--line)',
  };
  const td = {
    padding: '12px 14px', fontSize: 12, color: 'var(--ink-1)',
    borderBottom: '1px solid color-mix(in oklab, var(--line) 60%, transparent)',
    verticalAlign: 'middle',
  };
  return (
    <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th style={{ ...th, width: 36 }}></th>
            <th style={th}>Instance</th>
            <th style={th}>Loader</th>
            <th style={th}>MC Version</th>
            <th style={{ ...th, textAlign: 'right' }}>Mods</th>
            <th style={{ ...th, textAlign: 'right' }}>Playtime</th>
            <th style={th}>Last Played</th>
            <th style={{ ...th, width: 120 }}></th>
          </tr>
        </thead>
        <tbody>
          {instances.map((inst, i) => (
            <tr key={i} style={{ cursor: 'pointer' }}>
              <td style={{ ...td, paddingRight: 0 }}>
                <div style={{
                  width: 24, height: 24, borderRadius: 6, overflow: 'hidden',
                  position: 'relative', boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.08)',
                }}>
                  <Scene biome={inst.biome} seed={inst.seed}/>
                </div>
              </td>
              <td style={td}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontWeight: 600 }}>{inst.name}</span>
                  {inst.playing && (
                    <span className="chip green" style={{ fontSize: 9, padding: '1px 6px' }}>
                      <span className="pulse-dot" style={{ width: 4, height: 4 }}/> playing
                    </span>
                  )}
                </div>
              </td>
              <td style={td}>
                <span className={`chip ${inst.color}`} style={{ fontSize: 9, padding: '2px 7px' }}>{inst.loader}</span>
              </td>
              <td style={{ ...td, fontFamily: 'var(--mono)', color: 'var(--ink-2)', fontSize: 11 }}>{inst.mc}</td>
              <td style={{ ...td, textAlign: 'right', fontFamily: 'var(--mono)', fontSize: 11,
                           color: inst.mods ? 'var(--ink-1)' : 'var(--ink-3)' }}>
                {inst.mods || '—'}
              </td>
              <td style={{ ...td, textAlign: 'right', fontFamily: 'var(--mono)', fontSize: 11 }}>{inst.playtime}</td>
              <td style={{ ...td, color: 'var(--ink-3)', fontSize: 11 }}>{inst.lastPlayed}</td>
              <td style={{ ...td, textAlign: 'right' }}>
                <div style={{ display: 'inline-flex', gap: 4 }}>
                  <button className="btn-primary" style={{ padding: '6px 10px', fontSize: 11 }}>
                    <I.play size={10}/> Play
                  </button>
                  <button className="btn-icon" style={{ width: 26, height: 26 }}><I.more size={12}/></button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

Object.assign(window, { ScreenHome });
