// screen-instance.jsx — instance detail with mods list, screenshots, logs
function ScreenInstance() {
  const [tab, setTab] = React.useState('overview');
  const [installing, setInstalling] = React.useState(true);
  const [progress, setProgress] = React.useState(62);

  React.useEffect(() => {
    if (!installing) return;
    const t = setInterval(() => setProgress(p => p >= 100 ? 100 : p + 0.6), 100);
    return () => clearInterval(t);
  }, [installing]);

  const mods = [
    { name: 'Sodium', author: 'JellySquid', ver: '0.5.8', cat: 'Performance', color: 'cyan', on: true },
    { name: 'Iris Shaders', author: 'coderbot', ver: '1.7.1', cat: 'Graphics', color: 'violet', on: true },
    { name: 'Lithium', author: 'CaffeineMC', ver: '0.12.1', cat: 'Performance', color: 'cyan', on: true },
    { name: 'Fabric API', author: 'FabricMC', ver: '0.92.0', cat: 'Library', color: 'amber', on: true },
    { name: 'Xaero\'s Minimap', author: 'xaero96', ver: '24.1.0', cat: 'HUD', color: 'green', on: true },
    { name: 'JEI', author: 'mezz', ver: '15.2.0', cat: 'Utility', color: 'amber', on: true },
    { name: 'Mod Menu', author: 'Prospector', ver: '7.2.2', cat: 'Utility', color: 'amber', on: false },
    { name: 'Continuity', author: 'PepperCode1', ver: '3.0.0', cat: 'Graphics', color: 'violet', on: true },
  ];

  const logLines = [
    { t: '18:42:03', lvl: 'INFO', txt: 'Loading Fabric Loader 0.15.7' },
    { t: '18:42:04', lvl: 'INFO', txt: 'Found 87 mods to load' },
    { t: '18:42:04', lvl: 'INFO', txt: 'Injecting mixin patches...' },
    { t: '18:42:05', lvl: 'WARN', txt: 'Mod `create` registered legacy recipe handler' },
    { t: '18:42:06', lvl: 'INFO', txt: 'Built registry snapshot (3,214 entries)' },
    { t: '18:42:07', lvl: 'INFO', txt: 'Loading world: Aether_Dimensions' },
    { t: '18:42:08', lvl: 'INFO', txt: 'Chunks generated: 892 · Entities: 1,204' },
    { t: '18:42:09', lvl: 'INFO', txt: 'Ready · 58 FPS · 2.1 GB used' },
  ];

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, background: 'var(--bg-0)' }}>
      {/* Hero */}
      <div style={{ position: 'relative', height: 230, flexShrink: 0 }}>
        <Scene biome="end" seed={3}/>
        <Particles count={18} color="var(--violet)"/>
        <div style={{ position: 'absolute', inset: 0,
          background: 'linear-gradient(180deg, rgba(8,9,10,0.3) 0%, rgba(8,9,10,0.85) 85%, var(--bg-0) 100%)' }}/>
        <div style={{ position: 'absolute', top: 16, left: 24, right: 24, display: 'flex', gap: 10 }}>
          <button className="btn-icon" style={{ background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(10px)' }}>
            <I.chevRight size={14} style={{ transform: 'rotate(180deg)' }}/>
          </button>
          <div style={{ flex: 1 }}/>
          <button className="btn-icon" style={{ background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(10px)' }}><I.heart size={14}/></button>
          <button className="btn-icon" style={{ background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(10px)' }}><I.external size={14}/></button>
          <button className="btn-icon" style={{ background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(10px)' }}><I.more size={14}/></button>
        </div>
        <div style={{ position: 'absolute', left: 28, right: 28, bottom: 0, display: 'flex', alignItems: 'flex-end', gap: 20 }}>
          <div style={{
            width: 110, height: 110, borderRadius: 18, flexShrink: 0,
            transform: 'translateY(40px)', boxShadow: '0 20px 40px -10px rgba(0,0,0,0.8), 0 0 0 3px var(--bg-0)',
            overflow: 'hidden', position: 'relative',
          }}>
            <Scene biome="end" seed={3}/>
          </div>
          <div style={{ paddingBottom: 18, flex: 1, minWidth: 0 }}>
            <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
              <span className="chip green"><span className="pulse-dot" style={{ width: 5, height: 5 }}/> LAUNCHED</span>
              <span className="chip violet">FABRIC 0.14.21</span>
              <span className="chip">MC 1.20.1</span>
              <span className="chip amber">87 MODS</span>
            </div>
            <div style={{ fontSize: 32, fontWeight: 800, letterSpacing: -0.6, lineHeight: 1 }}>Aether Legacy</div>
            <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 6, fontFamily: 'var(--mono)' }}>
              /instances/aether-legacy · 4.8 GB · last saved 02:14
            </div>
          </div>
          <div style={{ paddingBottom: 18, display: 'flex', gap: 8 }}>
            <button className="btn-ghost"><I.pause size={13}/> Pause</button>
            <button className="btn-primary" style={{ padding: '11px 22px' }}>
              <I.play size={12}/> Running · 12m
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ padding: '52px 28px 0', display: 'flex', gap: 4, borderBottom: '1px solid var(--line)' }}>
        {['overview', 'mods', 'worlds', 'screenshots', 'logs', 'settings'].map(t => (
          <button key={t}
            onClick={() => setTab(t)}
            style={{
              padding: '10px 16px', fontSize: 13, fontWeight: 500,
              background: 'transparent', border: 'none', cursor: 'pointer',
              color: tab === t ? 'var(--mc-green)' : 'var(--ink-2)',
              borderBottom: tab === t ? '2px solid var(--mc-green)' : '2px solid transparent',
              marginBottom: -1, textTransform: 'capitalize', letterSpacing: -0.1,
            }}>
            {t}
          </button>
        ))}
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '22px 28px 40px' }}>
        {tab === 'overview' && (
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 18 }}>
            <div>
              <div className="card" style={{ padding: 18, marginBottom: 16 }}>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 10 }}>About</div>
                <div style={{ fontSize: 12, color: 'var(--ink-2)', lineHeight: 1.6 }}>
                  A re-imagining of the classic Aether mod — soar between floating isles, battle Slider bosses,
                  and uncover the secrets of a continent suspended in the void.
                </div>
              </div>
              {/* Install progress */}
              {installing && progress < 100 && (
                <div className="card" style={{ padding: 18, marginBottom: 16 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
                    <I.download size={14} style={{ color: 'var(--mc-green)' }}/>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>Syncing mod updates</div>
                    <div style={{ flex: 1 }}/>
                    <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--mc-green)' }}>{Math.round(progress)}%</div>
                  </div>
                  <div className="progress"><div className="progress-fill" style={{ width: `${progress}%` }}/></div>
                  <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 8, fontFamily: 'var(--mono)' }}>
                    Downloading iris-mc1.20.1-1.7.1.jar · 12.4 MB/s
                  </div>
                </div>
              )}
              {/* Screenshots preview */}
              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 10 }}>Screenshots</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
                {['end','nether','mushroom','ocean','cherry','snow'].map((b,i) => (
                  <div key={i} style={{ height: 100, borderRadius: 10, overflow: 'hidden', position: 'relative' }}>
                    <Scene biome={b} seed={i*9}/>
                    <div style={{ position: 'absolute', bottom: 6, left: 8, fontSize: 9, fontFamily: 'var(--mono)', color: 'rgba(255,255,255,0.7)' }}>
                      2026-04-{10+i}_18.0{i}.png
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div>
              {/* Stats */}
              <div className="card" style={{ padding: 18, marginBottom: 14 }}>
                <div style={{ fontSize: 12, color: 'var(--ink-3)', marginBottom: 12, fontFamily: 'var(--mono)', letterSpacing: 0.5 }}>SESSION</div>
                {[
                  { k: 'Playtime', v: '12 min', c: 'var(--mc-green)' },
                  { k: 'Total', v: '24h 12m', c: 'var(--ink-0)' },
                  { k: 'Memory', v: '2.1 / 6 GB', c: 'var(--cyan)' },
                  { k: 'Framerate', v: '58 fps', c: 'var(--amber)' },
                  { k: 'Tick time', v: '18.2 ms', c: 'var(--ink-0)' },
                ].map(s => (
                  <div key={s.k} style={{ display: 'flex', padding: '8px 0', borderBottom: '1px solid var(--line)', fontSize: 12 }}>
                    <div style={{ color: 'var(--ink-2)', flex: 1 }}>{s.k}</div>
                    <div style={{ fontFamily: 'var(--mono)', fontWeight: 600, color: s.c }}>{s.v}</div>
                  </div>
                ))}
              </div>
              <div className="card" style={{ padding: 18 }}>
                <div style={{ fontSize: 12, color: 'var(--ink-3)', marginBottom: 12, fontFamily: 'var(--mono)', letterSpacing: 0.5 }}>PLAYING WITH</div>
                {[
                  { n: 'pixelpete', c: '#ff5ec8' },
                  { n: 'cavesworn', c: '#47d9ff' },
                  { n: 'sundayknight', c: '#ffb545' },
                ].map(u => (
                  <div key={u.n} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 0' }}>
                    <div style={{ width: 24, height: 24, borderRadius: 6, background: u.c, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: '#000' }}>
                      {u.n.slice(0,2).toUpperCase()}
                    </div>
                    <div style={{ fontSize: 12 }}>{u.n}</div>
                    <div style={{ flex: 1 }}/>
                    <span className="pulse-dot" style={{ width: 6, height: 6 }}/>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {tab === 'mods' && (
          <div>
            <div style={{ display: 'flex', gap: 10, marginBottom: 14 }}>
              <input className="input" placeholder="Filter mods…" style={{ flex: 1 }}/>
              <button className="btn-ghost"><I.filter size={13}/> Category</button>
              <button className="btn-primary"><I.plus size={12}/> Add Mod</button>
            </div>
            <div className="card" style={{ padding: 0 }}>
              {mods.map((m, i) => (
                <div key={i} style={{
                  display: 'flex', alignItems: 'center', gap: 14,
                  padding: '12px 16px',
                  borderBottom: i === mods.length - 1 ? 'none' : '1px solid var(--line)',
                  transition: 'background 0.1s',
                }}>
                  <div style={{
                    width: 32, height: 32, borderRadius: 8,
                    background: `color-mix(in oklab, var(--${m.color === 'green' ? 'mc-green' : m.color}) 14%, transparent)`,
                    border: `1px solid color-mix(in oklab, var(--${m.color === 'green' ? 'mc-green' : m.color}) 28%, transparent)`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                  }}>
                    <I.box size={14} style={{ color: m.color === 'green' ? 'var(--mc-green)' : `var(--${m.color})` }}/>
                  </div>
                  <div style={{ minWidth: 0, flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 8 }}>
                      {m.name}
                      <span className={`chip ${m.color}`} style={{ fontSize: 9, padding: '1px 6px' }}>{m.cat}</span>
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2, fontFamily: 'var(--mono)' }}>
                      by {m.author} · v{m.ver}
                    </div>
                  </div>
                  <div className={`toggle ${m.on ? 'on' : ''}`}/>
                  <button className="btn-icon" style={{ width: 28, height: 28 }}><I.more size={13}/></button>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === 'logs' && (
          <div className="card" style={{ padding: 16, background: '#05060700', border: '1px solid var(--line)', fontFamily: 'var(--mono)', fontSize: 11.5, lineHeight: 1.7 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10, paddingBottom: 10, borderBottom: '1px solid var(--line)' }}>
              <I.terminal size={14} style={{ color: 'var(--mc-green)' }}/>
              <div style={{ fontSize: 12, fontWeight: 600 }}>latest.log</div>
              <div style={{ flex: 1 }}/>
              <span className="chip green"><span className="pulse-dot" style={{ width: 5, height: 5 }}/> LIVE</span>
              <button className="btn-ghost" style={{ padding: '5px 10px', fontSize: 11 }}><I.download size={11}/> Export</button>
            </div>
            {logLines.map((l, i) => (
              <div key={i} style={{ display: 'flex', gap: 12 }}>
                <span style={{ color: 'var(--ink-4)' }}>{l.t}</span>
                <span style={{ width: 50, color: l.lvl === 'WARN' ? 'var(--amber)' : l.lvl === 'ERROR' ? '#ff5e5e' : 'var(--mc-green)' }}>[{l.lvl}]</span>
                <span style={{ color: 'var(--ink-1)' }}>{l.txt}</span>
              </div>
            ))}
            <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
              <span style={{ color: 'var(--ink-4)' }}>18:42:10</span>
              <span style={{ width: 50, color: 'var(--mc-green)' }}>[INFO]</span>
              <span style={{ color: 'var(--ink-1)' }}>Awaiting player input</span>
              <span className="caret"/>
            </div>
          </div>
        )}

        {tab === 'screenshots' && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
            {['end','cherry','nether','ocean','forest','desert','snow','mushroom','end'].map((b,i) => (
              <div key={i} className="card" style={{ padding: 0, overflow: 'hidden' }}>
                <div style={{ height: 160, position: 'relative' }}>
                  <Scene biome={b} seed={i*11+7}/>
                </div>
                <div style={{ padding: '10px 12px', fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <I.image size={11}/>
                  <span>2026-04-{10+i}_18.0{i}.png</span>
                  <div style={{ flex: 1 }}/>
                  <span>2.1 MB</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === 'worlds' && (() => {
          const worlds = [
            { name: 'Aether Hub',       biome: 'end',      seed: '-4827193047281',  mode: 'Survival', diff: 'Hard',     size: '1.4 GB', played: '48h 12m', last: '02:14 today',  badges: ['pinned','cloud'], version: '1.20.1' },
            { name: 'Creative Sandbox', biome: 'cherry',   seed: '8821094572',      mode: 'Creative', diff: 'Peaceful', size: '412 MB', played: '9h 04m',  last: 'Yesterday',    badges: ['cloud'],          version: '1.20.1' },
            { name: 'SkyBlock Classic', biome: 'ocean',    seed: '12345',           mode: 'Survival', diff: 'Normal',   size: '284 MB', played: '22h 47m', last: '3 days ago',   badges: ['backed-up'],      version: '1.20.1' },
            { name: 'Nether Outpost',   biome: 'nether',   seed: '-918273645',      mode: 'Hardcore', diff: 'Hard',     size: '2.1 GB', played: '104h 31m',last: 'Last week',    badges: ['pinned'],         version: '1.20.1' },
            { name: 'Pixel Town',       biome: 'forest',   seed: '7391047',         mode: 'Survival', diff: 'Normal',   size: '896 MB', played: '31h 18m', last: '2 weeks ago',  badges: [],                 version: '1.19.4' },
            { name: 'Desert Expedition',biome: 'desert',   seed: '-2837461',        mode: 'Adventure',diff: 'Hard',     size: '644 MB', played: '14h 22m', last: 'Apr 8, 2026',  badges: ['backed-up'],      version: '1.20.1' },
          ];
          const modeColor = { Survival:'green', Creative:'cyan', Hardcore:'amber', Adventure:'violet' };
          return (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
                <div style={{ position: 'relative', flex: 1, maxWidth: 280 }}>
                  <I.search size={12} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--ink-3)' }}/>
                  <input placeholder="Search worlds…" style={{
                    width: '100%', background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 8,
                    padding: '7px 10px 7px 28px', color: 'var(--ink-0)', fontSize: 12, outline: 'none', fontFamily: 'inherit',
                  }}/>
                </div>
                <div style={{ display: 'flex', gap: 4, padding: 3, background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 8 }}>
                  <button className="seg-btn active" style={{ padding: '5px 10px', fontSize: 11 }}>All</button>
                  <button className="seg-btn" style={{ padding: '5px 10px', fontSize: 11 }}>Singleplayer</button>
                  <button className="seg-btn" style={{ padding: '5px 10px', fontSize: 11 }}>Backups</button>
                </div>
                <div style={{ flex: 1 }}/>
                <button className="btn-ghost" style={{ fontSize: 11 }}><I.upload size={11}/> Import</button>
                <button className="btn-ghost" style={{ fontSize: 11 }}><I.plus size={11}/> New world</button>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
                {worlds.map((w, i) => (
                  <div key={i} className="card" style={{ padding: 0, overflow: 'hidden', display: 'flex', position: 'relative' }}>
                    <div style={{ width: 128, height: 128, flexShrink: 0, position: 'relative', borderRight: '1px solid var(--line)' }}>
                      <Scene biome={w.biome} seed={w.seed.length * 3 + i}/>
                      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(135deg, transparent 55%, rgba(8,9,10,0.65) 100%)' }}/>
                      {w.badges.includes('pinned') && (
                        <div style={{ position: 'absolute', top: 6, left: 6, width: 20, height: 20, borderRadius: 5, background: 'rgba(8,9,10,0.7)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--green)' }}>
                          <I.pin size={10}/>
                        </div>
                      )}
                      <div style={{ position: 'absolute', bottom: 6, right: 6, fontSize: 9, fontFamily: 'var(--mono)', color: 'rgba(255,255,255,0.85)', background: 'rgba(8,9,10,0.6)', padding: '2px 5px', borderRadius: 3, letterSpacing: 0.3 }}>
                        {w.version}
                      </div>
                    </div>
                    <div style={{ flex: 1, padding: '12px 14px', minWidth: 0, display: 'flex', flexDirection: 'column' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                        <div style={{ fontSize: 14, fontWeight: 600, letterSpacing: -0.2, flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{w.name}</div>
                        {w.badges.includes('cloud') && <I.cloud size={11} style={{ color: 'var(--cyan)', flexShrink: 0 }}/>}
                        {w.badges.includes('backed-up') && <I.shield size={11} style={{ color: 'var(--ink-3)', flexShrink: 0 }}/>}
                      </div>
                      <div style={{ display: 'flex', gap: 4, marginBottom: 8, flexWrap: 'wrap' }}>
                        <span className={`chip ${modeColor[w.mode]}`} style={{ fontSize: 9 }}>{w.mode.toUpperCase()}</span>
                        <span className="chip" style={{ fontSize: 9 }}>{w.diff.toUpperCase()}</span>
                      </div>
                      <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)', marginBottom: 4, display: 'flex', alignItems: 'center', gap: 5 }}>
                        <I.hash size={9}/>
                        <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{w.seed}</span>
                      </div>
                      <div style={{ display: 'flex', gap: 12, fontSize: 10, color: 'var(--ink-2)', fontFamily: 'var(--mono)', marginTop: 'auto' }}>
                        <span><span style={{ color: 'var(--ink-3)' }}>play</span> {w.played}</span>
                        <span><span style={{ color: 'var(--ink-3)' }}>size</span> {w.size}</span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 8, paddingTop: 8, borderTop: '1px solid var(--line)' }}>
                        <div style={{ fontSize: 10, color: 'var(--ink-3)', flex: 1 }}>Saved {w.last}</div>
                        <button className="btn-icon" style={{ width: 24, height: 24 }} title="Open folder"><I.folder size={11}/></button>
                        <button className="btn-icon" style={{ width: 24, height: 24 }} title="More"><I.more size={11}/></button>
                        <button className="btn-primary" style={{ padding: '5px 10px', fontSize: 10 }}>
                          <I.play size={9}/> Play
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })()}

        {tab === 'settings' && (() => {
          const Row = ({ label, hint, children }) => (
            <div style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '14px 0', borderBottom: '1px solid var(--line)' }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12.5, color: 'var(--ink-0)', marginBottom: hint ? 3 : 0 }}>{label}</div>
                {hint && <div style={{ fontSize: 11, color: 'var(--ink-3)', lineHeight: 1.4 }}>{hint}</div>}
              </div>
              <div style={{ flexShrink: 0, display: 'flex', alignItems: 'center', gap: 8 }}>{children}</div>
            </div>
          );
          const Toggle = ({ on = true }) => (
            <div style={{ width: 30, height: 18, borderRadius: 10, background: on ? 'var(--mc-green)' : 'var(--bg-2)', position: 'relative', border: '1px solid ' + (on ? 'var(--mc-green)' : 'var(--line)'), cursor: 'pointer' }}>
              <div style={{ position: 'absolute', top: 1, left: on ? 13 : 1, width: 14, height: 14, borderRadius: '50%', background: on ? '#0a1f12' : 'var(--ink-2)', transition: 'all 120ms' }}/>
            </div>
          );
          const Select = ({ value }) => (
            <button style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 6, padding: '5px 9px', fontSize: 11.5, color: 'var(--ink-0)', fontFamily: 'var(--mono)', cursor: 'pointer', minWidth: 120, justifyContent: 'space-between' }}>
              <span>{value}</span>
              <I.chevDown size={10} style={{ color: 'var(--ink-3)' }}/>
            </button>
          );
          const SectionHeader = ({ icon: Icon, title, desc, color = 'var(--mc-green)' }) => (
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, marginBottom: 4 }}>
              <div style={{ width: 28, height: 28, borderRadius: 7, background: 'var(--bg-1)', border: '1px solid var(--line)', display: 'flex', alignItems: 'center', justifyContent: 'center', color, flexShrink: 0 }}>
                <Icon size={13}/>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600, letterSpacing: -0.1 }}>{title}</div>
                <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>{desc}</div>
              </div>
            </div>
          );
          return (
            <div style={{ display: 'grid', gridTemplateColumns: '180px 1fr', gap: 28 }}>
              {/* Side nav */}
              <div style={{ position: 'sticky', top: 0, alignSelf: 'flex-start' }}>
                {[
                  { k: 'java',     lbl: 'Java & Memory', ic: I.cpu,     active: true },
                  { k: 'window',   lbl: 'Window',        ic: I.layout   || I.image },
                  { k: 'launch',   lbl: 'Launch Args',   ic: I.terminal || I.code || I.hash },
                  { k: 'version',  lbl: 'Game Version',  ic: I.tag },
                  { k: 'paths',    lbl: 'Paths & Files', ic: I.folder },
                  { k: 'advanced', lbl: 'Advanced',      ic: I.settings },
                  { k: 'danger',   lbl: 'Danger Zone',   ic: I.trash, color: 'var(--red)' || '#ff5a7a' },
                ].map(item => (
                  <div key={item.k} style={{
                    display: 'flex', alignItems: 'center', gap: 9, padding: '8px 10px', borderRadius: 7,
                    fontSize: 12, marginBottom: 2, cursor: 'pointer',
                    background: item.active ? 'rgba(34,255,132,0.08)' : 'transparent',
                    color: item.active ? 'var(--mc-green)' : 'var(--ink-2)',
                  }}>
                    <item.ic size={12}/>
                    <span>{item.lbl}</span>
                  </div>
                ))}
                <div style={{ marginTop: 18, padding: 12, background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 8 }}>
                  <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)', letterSpacing: 0.5, marginBottom: 6 }}>INHERITED</div>
                  <div style={{ fontSize: 11, color: 'var(--ink-2)', lineHeight: 1.5 }}>
                    4 settings inherited from <span style={{ color: 'var(--mc-green)' }}>Global defaults</span>. Override anything by toggling it here.
                  </div>
                </div>
              </div>

              {/* Main */}
              <div>
                {/* Java & memory */}
                <div style={{ marginBottom: 28 }}>
                  <SectionHeader icon={I.cpu} title="Java & Memory" desc="Runtime selection and heap allocation for this instance."/>
                  <div className="card" style={{ padding: '0 18px', marginTop: 14 }}>
                    <Row label="Java runtime" hint="Auto-detected from your system installations.">
                      <Select value="Temurin 17.0.9"/>
                    </Row>
                    <Row label="Allocated memory" hint={`${6} GB of 16 GB available · Minecraft recommends 4–8 GB for modded.`}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10, width: 280 }}>
                        <div style={{ flex: 1, position: 'relative', height: 6, background: 'var(--bg-2)', borderRadius: 3 }}>
                          <div style={{ position: 'absolute', inset: 0, width: '37.5%', background: 'var(--mc-green)', borderRadius: 3, boxShadow: '0 0 8px rgba(34,255,132,0.5)' }}/>
                          <div style={{ position: 'absolute', left: '37.5%', top: -4, width: 14, height: 14, borderRadius: '50%', background: 'var(--mc-green)', transform: 'translateX(-50%)', boxShadow: '0 0 0 3px var(--bg-0)' }}/>
                        </div>
                        <div style={{ fontFamily: 'var(--mono)', fontSize: 12, fontWeight: 600, color: 'var(--mc-green)', minWidth: 42, textAlign: 'right' }}>6 GB</div>
                      </div>
                    </Row>
                    <Row label="Garbage collector" hint="G1GC is recommended for most modpacks. Use ZGC for pause-sensitive gameplay.">
                      <Select value="G1GC"/>
                    </Row>
                    <Row label="Use system Java instead of bundled">
                      <Toggle on={false}/>
                    </Row>
                    <div style={{ padding: '14px 0' }}>
                      <div style={{ fontSize: 11, color: 'var(--ink-3)', marginBottom: 6, fontFamily: 'var(--mono)' }}>JVM ARGUMENTS</div>
                      <div style={{
                        background: 'var(--bg-0)', border: '1px solid var(--line)', borderRadius: 6,
                        padding: 10, fontFamily: 'var(--mono)', fontSize: 11, lineHeight: 1.6, color: 'var(--ink-1)',
                        maxHeight: 72, overflow: 'hidden', position: 'relative',
                      }}>
                        <span style={{ color: 'var(--mc-green)' }}>-XX:+UseG1GC</span> <span style={{ color: 'var(--ink-2)' }}>-XX:+ParallelRefProcEnabled</span>{' '}
                        <span style={{ color: 'var(--amber)' }}>-XX:MaxGCPauseMillis=200</span>{' '}
                        <span style={{ color: 'var(--ink-2)' }}>-XX:+UnlockExperimentalVMOptions -XX:G1NewSizePercent=30</span>{' '}
                        <span style={{ color: 'var(--cyan)' }}>-Dfml.ignoreInvalidMinecraftCertificates=true</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Window */}
                <div style={{ marginBottom: 28 }}>
                  <SectionHeader icon={I.image} title="Window" desc="How Minecraft appears when this instance launches."/>
                  <div className="card" style={{ padding: '0 18px', marginTop: 14 }}>
                    <Row label="Launch mode">
                      <div style={{ display: 'flex', gap: 2, padding: 2, background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 6 }}>
                        {['Windowed', 'Borderless', 'Fullscreen'].map((m,i) => (
                          <div key={m} style={{
                            padding: '4px 10px', fontSize: 11, borderRadius: 4, cursor: 'pointer',
                            background: i === 0 ? 'var(--bg-2)' : 'transparent',
                            color: i === 0 ? 'var(--ink-0)' : 'var(--ink-3)',
                          }}>{m}</div>
                        ))}
                      </div>
                    </Row>
                    <Row label="Resolution">
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <input defaultValue="1920" style={{ width: 72, background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 6, padding: '5px 8px', fontSize: 11.5, color: 'var(--ink-0)', fontFamily: 'var(--mono)', textAlign: 'center', outline: 'none' }}/>
                        <span style={{ color: 'var(--ink-3)', fontSize: 11 }}>×</span>
                        <input defaultValue="1080" style={{ width: 72, background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 6, padding: '5px 8px', fontSize: 11.5, color: 'var(--ink-0)', fontFamily: 'var(--mono)', textAlign: 'center', outline: 'none' }}/>
                      </div>
                    </Row>
                    <Row label="Hide launcher while playing" hint="Minimize Lodestone until you quit the game.">
                      <Toggle on={true}/>
                    </Row>
                    <Row label="Quit launcher after game exits">
                      <Toggle on={false}/>
                    </Row>
                  </div>
                </div>

                {/* Game version */}
                <div style={{ marginBottom: 28 }}>
                  <SectionHeader icon={I.tag} title="Game Version" desc="Change Minecraft or mod-loader versions. Requires rebuild."/>
                  <div className="card" style={{ padding: '0 18px', marginTop: 14 }}>
                    <Row label="Minecraft">
                      <Select value="1.20.1"/>
                    </Row>
                    <Row label="Mod loader">
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span className="chip violet" style={{ fontSize: 10 }}>FABRIC</span>
                        <Select value="0.14.21"/>
                      </div>
                    </Row>
                    <Row label="Include snapshots and pre-releases">
                      <Toggle on={false}/>
                    </Row>
                  </div>
                </div>

                {/* Advanced */}
                <div style={{ marginBottom: 28 }}>
                  <SectionHeader icon={I.settings} title="Advanced" desc="Power-user options. Change with care."/>
                  <div className="card" style={{ padding: '0 18px', marginTop: 14 }}>
                    <Row label="Environment variables" hint="Passed to the JVM process at launch.">
                      <button className="btn-ghost" style={{ fontSize: 11 }}>3 set · Edit</button>
                    </Row>
                    <Row label="Pre-launch hook" hint="Run a shell command before the game starts.">
                      <button className="btn-ghost" style={{ fontSize: 11 }}><I.plus size={10}/> Add script</button>
                    </Row>
                    <Row label="Verbose logging" hint="Emit DEBUG-level output to the console.">
                      <Toggle on={true}/>
                    </Row>
                    <Row label="Skip integrity check on launch">
                      <Toggle on={false}/>
                    </Row>
                  </div>
                </div>

                {/* Danger zone */}
                <div>
                  <SectionHeader icon={I.trash} title="Danger Zone" desc="Destructive actions. These cannot be undone." color="#ff5a7a"/>
                  <div className="card" style={{ padding: 18, marginTop: 14, borderColor: 'rgba(255,90,122,0.2)' }}>
                    {[
                      { t: 'Reinstall game files', d: 'Redownload vanilla Minecraft jars for this version. Mods and worlds are preserved.', btn: 'Reinstall' },
                      { t: 'Reset settings to defaults', d: 'Revert this instance back to global defaults.', btn: 'Reset' },
                      { t: 'Delete instance',  d: 'Permanently remove this instance and all of its worlds, mods, and screenshots.', btn: 'Delete', danger: true },
                    ].map((r,i,arr) => (
                      <div key={r.t} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '12px 0', borderBottom: i < arr.length - 1 ? '1px solid var(--line)' : 'none' }}>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: 12.5, marginBottom: 3, color: r.danger ? '#ff5a7a' : 'var(--ink-0)' }}>{r.t}</div>
                          <div style={{ fontSize: 11, color: 'var(--ink-3)', lineHeight: 1.4 }}>{r.d}</div>
                        </div>
                        <button style={{
                          padding: '6px 12px', fontSize: 11, borderRadius: 6, cursor: 'pointer',
                          background: r.danger ? 'rgba(255,90,122,0.1)' : 'var(--bg-1)',
                          border: '1px solid ' + (r.danger ? 'rgba(255,90,122,0.3)' : 'var(--line)'),
                          color: r.danger ? '#ff5a7a' : 'var(--ink-1)',
                        }}>{r.btn}</button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          );
        })()}
      </div>
    </div>
  );
}

Object.assign(window, { ScreenInstance });
