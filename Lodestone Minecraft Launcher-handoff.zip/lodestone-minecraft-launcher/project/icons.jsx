// icons.jsx — small outline icon set
const Icon = ({ d, size = 18, fill = "none", strokeWidth = 1.6, style }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor"
       strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" style={style}>
    {d}
  </svg>
);

const I = {
  play:     (p) => <Icon {...p} fill="currentColor" strokeWidth={0} d={<path d="M7 5v14l12-7L7 5z"/>}/>,
  pause:    (p) => <Icon {...p} d={<><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></>}/>,
  home:     (p) => <Icon {...p} d={<path d="M3 11l9-8 9 8v10a1 1 0 01-1 1h-5v-7h-6v7H4a1 1 0 01-1-1V11z"/>}/>,
  compass:  (p) => <Icon {...p} d={<><circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5 5-2z" fill="currentColor" stroke="none"/></>}/>,
  box:      (p) => <Icon {...p} d={<><path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/></>}/>,
  grid:     (p) => <Icon {...p} d={<><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></>}/>,
  list:     (p) => <Icon {...p} d={<><path d="M8 6h13M8 12h13M8 18h13"/><circle cx="4" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="18" r="1" fill="currentColor" stroke="none"/></>}/>,
  table:    (p) => <Icon {...p} d={<><rect x="3" y="4" width="18" height="16" rx="1.5"/><path d="M3 10h18M3 16h18M10 4v16"/></>}/>,
  server:   (p) => <Icon {...p} d={<><rect x="3" y="4" width="18" height="7" rx="1.5"/><rect x="3" y="13" width="18" height="7" rx="1.5"/><circle cx="7" cy="7.5" r="0.6" fill="currentColor"/><circle cx="7" cy="16.5" r="0.6" fill="currentColor"/></>}/>,
  settings: (p) => <Icon {...p} d={<><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 01-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09a1.65 1.65 0 00-1-1.51 1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></>}/>,
  search:   (p) => <Icon {...p} d={<><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></>}/>,
  download: (p) => <Icon {...p} d={<><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></>}/>,
  plus:     (p) => <Icon {...p} d={<><path d="M12 5v14M5 12h14"/></>}/>,
  filter:   (p) => <Icon {...p} d={<path d="M22 3H2l8 9.46V19l4 2v-8.54L22 3z"/>}/>,
  bell:     (p) => <Icon {...p} d={<><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></>}/>,
  chevRight:(p) => <Icon {...p} d={<path d="M9 18l6-6-6-6"/>}/>,
  chevDown: (p) => <Icon {...p} d={<path d="M6 9l6 6 6-6"/>}/>,
  user:     (p) => <Icon {...p} d={<><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-7 8-7s8 3 8 7"/></>}/>,
  clock:    (p) => <Icon {...p} d={<><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>}/>,
  globe:    (p) => <Icon {...p} d={<><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18"/></>}/>,
  x:        (p) => <Icon {...p} d={<><path d="M18 6L6 18M6 6l12 12"/></>}/>,
  check:    (p) => <Icon {...p} d={<path d="M20 6L9 17l-5-5"/>}/>,
  star:     (p) => <Icon {...p} d={<path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>}/>,
  trash:    (p) => <Icon {...p} d={<><path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/></>}/>,
  folder:   (p) => <Icon {...p} d={<path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2v11z"/>}/>,
  cpu:      (p) => <Icon {...p} d={<><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 1v3M15 1v3M9 20v3M15 20v3M20 9h3M20 14h3M1 9h3M1 14h3"/></>}/>,
  zap:      (p) => <Icon {...p} d={<path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>}/>,
  users:    (p) => <Icon {...p} d={<><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></>}/>,
  lock:     (p) => <Icon {...p} d={<><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></>}/>,
  refresh:  (p) => <Icon {...p} d={<><path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></>}/>,
  more:     (p) => <Icon {...p} d={<><circle cx="12" cy="5" r="1.2" fill="currentColor"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/><circle cx="12" cy="19" r="1.2" fill="currentColor"/></>}/>,
  external: (p) => <Icon {...p} d={<><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><path d="M15 3h6v6M10 14L21 3"/></>}/>,
  heart:    (p) => <Icon {...p} d={<path d="M20.84 4.6a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.07a5.5 5.5 0 00-7.78 7.78l1.06 1.07L12 21.23l7.78-7.78 1.06-1.07a5.5 5.5 0 000-7.78z"/>}/>,
  terminal: (p) => <Icon {...p} d={<><polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/></>}/>,
  image:    (p) => <Icon {...p} d={<><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></>}/>,
  tag:      (p) => <Icon {...p} d={<><path d="M20.59 13.41L13.42 20.59a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><circle cx="7" cy="7" r="1" fill="currentColor"/></>}/>,
  shield:   (p) => <Icon {...p} d={<path d="M12 2l9 4v6c0 5-4 9-9 10-5-1-9-5-9-10V6l9-4z"/>}/>,
  pickaxe:  (p) => <Icon {...p} d={<><path d="M14 4l-4 4m-6 6l4 4m2-10l8 8m-8-8a6 6 0 018.5 8.5L14 4z"/></>}/>,
  sword:    (p) => <Icon {...p} d={<><path d="M14.5 17.5L3 6V3h3l11.5 11.5M13 19l6-6M16 16l4 4M19 21l2-2"/></>}/>,
  pin:      (p) => <Icon {...p} d={<><path d="M12 17v5"/><path d="M9 10.76a2 2 0 01-.83 1.62L5 14.63V16h14v-1.37l-3.17-2.25a2 2 0 01-.83-1.62V5H9v5.76z"/><path d="M7 5h10"/></>}/>,
  cloud:    (p) => <Icon {...p} d={<path d="M18 10h-1.26A8 8 0 109 20h9a5 5 0 000-10z"/>}/>,
  hash:     (p) => <Icon {...p} d={<><path d="M4 9h16M4 15h16M10 3L8 21M16 3l-2 18"/></>}/>,
  hardDrive:(p) => <Icon {...p} d={<><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M2 12h20"/><path d="M6 16h.01M10 16h.01"/></>}/>,
  copy:     (p) => <Icon {...p} d={<><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></>}/>,
  upload:   (p) => <Icon {...p} d={<><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><path d="M17 8l-5-5-5 5"/><path d="M12 3v12"/></>}/>,
  signal:   (p) => <Icon {...p} d={<><path d="M2 20h.01M6 16a6 6 0 016 6M6 12a10 10 0 0110 10M6 8a14 14 0 0114 14"/></>}/>,
  wifi:     (p) => <Icon {...p} d={<><path d="M5 12.55a11 11 0 0114 0M8.5 16a6 6 0 017 0M2 8.82a15 15 0 0120 0"/><line x1="12" y1="20" x2="12.01" y2="20"/></>}/>,
  headset:  (p) => <Icon {...p} d={<><path d="M3 14v-3a9 9 0 0118 0v3"/><path d="M21 19a2 2 0 01-2 2h-1v-7h3v5zM3 19a2 2 0 002 2h1v-7H3v5z"/></>}/>,
  gamepad:  (p) => <Icon {...p} d={<><line x1="6" y1="11" x2="10" y2="11"/><line x1="8" y1="9" x2="8" y2="13"/><line x1="15" y1="12" x2="15.01" y2="12"/><line x1="18" y1="10" x2="18.01" y2="10"/><path d="M17.32 5H6.68a4 4 0 00-3.978 3.59L2 14a3 3 0 003 3h.1a4 4 0 003.8-3h6.2a4 4 0 003.8 3H19a3 3 0 003-3l-.7-5.41A4 4 0 0017.32 5z"/></>}/>,
  message:  (p) => <Icon {...p} d={<path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>}/>,
  pkg:      (p) => <Icon {...p} d={<><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/><path d="M3.27 6.96L12 12.01l8.73-5.05M12 22.08V12"/></>}/>,
};

Object.assign(window, { Icon, I });
