// skin-browser.jsx — 3D skin browser for the Accounts pane
// Pure CSS 3D — each body part is a cube built from 6 faces.
// Outer "overlay" cubes are slightly larger and represent hat/jacket/sleeve/pant layers.

// ── Core 3D cube ───────────────────────────────────────────────
function Cube({ w, h, d, colors, overlay, showOverlay, overlayColors, transform, style }) {
  // colors: { front, back, left, right, top, bottom }
  const face = (bg, transform) => (
    <div style={{
      position: 'absolute', left: '50%', top: '50%',
      width: w, height: h, marginLeft: -w/2, marginTop: -h/2,
      background: bg,
      transform,
      backfaceVisibility: 'hidden',
      boxShadow: 'inset 0 0 0 0.5px rgba(0,0,0,0.25)',
    }}/>
  );
  const faceD = (bg, transform, fw, fh) => (
    <div style={{
      position: 'absolute', left: '50%', top: '50%',
      width: fw, height: fh, marginLeft: -fw/2, marginTop: -fh/2,
      background: bg, transform,
      backfaceVisibility: 'hidden',
      boxShadow: 'inset 0 0 0 0.5px rgba(0,0,0,0.25)',
    }}/>
  );

  const innerFaces = (
    <>
      {face(colors.front,  `translateZ(${d/2}px)`)}
      {face(colors.back,   `translateZ(${-d/2}px) rotateY(180deg)`)}
      {faceD(colors.left,  `translateX(${-w/2}px) rotateY(-90deg)`, d, h)}
      {faceD(colors.right, `translateX(${w/2}px) rotateY(90deg)`,   d, h)}
      {faceD(colors.top,   `translateY(${-h/2}px) rotateX(90deg)`,  w, d)}
      {faceD(colors.bottom,`translateY(${h/2}px) rotateX(-90deg)`,  w, d)}
    </>
  );

  const oW = w + 1.2, oH = h + 1.2, oD = d + 1.2;
  const overlayFaces = overlay && showOverlay ? (
    <>
      <div style={{ position: 'absolute', left: '50%', top: '50%', width: oW, height: oH, marginLeft: -oW/2, marginTop: -oH/2, background: overlayColors.front, transform: `translateZ(${oD/2}px)` }}/>
      <div style={{ position: 'absolute', left: '50%', top: '50%', width: oW, height: oH, marginLeft: -oW/2, marginTop: -oH/2, background: overlayColors.back, transform: `translateZ(${-oD/2}px) rotateY(180deg)` }}/>
      <div style={{ position: 'absolute', left: '50%', top: '50%', width: oD, height: oH, marginLeft: -oD/2, marginTop: -oH/2, background: overlayColors.left, transform: `translateX(${-oW/2}px) rotateY(-90deg)` }}/>
      <div style={{ position: 'absolute', left: '50%', top: '50%', width: oD, height: oH, marginLeft: -oD/2, marginTop: -oH/2, background: overlayColors.right, transform: `translateX(${oW/2}px) rotateY(90deg)` }}/>
      <div style={{ position: 'absolute', left: '50%', top: '50%', width: oW, height: oD, marginLeft: -oW/2, marginTop: -oD/2, background: overlayColors.top, transform: `translateY(${-oH/2}px) rotateX(90deg)` }}/>
      <div style={{ position: 'absolute', left: '50%', top: '50%', width: oW, height: oD, marginLeft: -oW/2, marginTop: -oD/2, background: overlayColors.bottom, transform: `translateY(${oH/2}px) rotateX(-90deg)` }}/>
    </>
  ) : null;

  return (
    <div style={{ position: 'absolute', transformStyle: 'preserve-3d', transform, ...style }}>
      {innerFaces}
      {overlayFaces}
    </div>
  );
}

// ── Character rig ──
// animTime: ms, used to drive limb swing for walk/run/sneak/swim
function Character({ skin, rotation = 0, size = 1, overlays = { hat: true, jacket: true, sleeves: true, pants: true }, anim = 'default', animTime = 0 }) {
  const u = 8 * size;
  // Animation deltas: per-limb rotation in deg + global body offset/tilt
  const t = animTime / 1000;
  let legSwing = 0, armSwing = 0, bodyTilt = 0, bodyY = 0, armOut = 0, headTilt = 0;
  if (anim === 'walking') {
    legSwing = Math.sin(t * 5) * 25;
    armSwing = Math.sin(t * 5 + Math.PI) * 22;
    bodyY = Math.abs(Math.sin(t * 10)) * -1.5;
  } else if (anim === 'running') {
    legSwing = Math.sin(t * 8) * 45;
    armSwing = Math.sin(t * 8 + Math.PI) * 55;
    bodyTilt = 18;
    bodyY = Math.abs(Math.sin(t * 16)) * -3;
  } else if (anim === 'sneaking') {
    legSwing = Math.sin(t * 3) * 10;
    armSwing = Math.sin(t * 3 + Math.PI) * 8;
    bodyTilt = 25;
    bodyY = u * 1.5;
    headTilt = -10;
  } else if (anim === 'swimming') {
    legSwing = Math.sin(t * 6) * 18;
    armSwing = Math.sin(t * 6) * 60;
    armOut = 20;
    bodyTilt = 80;  // nearly horizontal
    bodyY = -u * 0.5;
  } else if (anim === 'tpose') {
    armOut = 90;
  }

  return (
    <div style={{
      position: 'relative', width: u*10, height: u*36,
      transformStyle: 'preserve-3d',
      transform: `rotateX(${-8 + bodyTilt * 0.3}deg) rotateY(${rotation}deg) translateY(${bodyY}px) rotateZ(${bodyTilt * 0.2}deg)`,
      transition: anim === 'default' || anim === 'tpose' ? 'transform 0.25s' : 'transform 0.05s linear',
    }}>
      {/* Head */}
      <Cube w={u*8} h={u*8} d={u*8} colors={skin.head} overlay
            overlayColors={skin.hat} showOverlay={overlays.hat}
            transform={`translate3d(${u*5}px, ${u*4}px, 0) rotateX(${headTilt}deg)`}/>
      {/* Body */}
      <Cube w={u*8} h={u*12} d={u*4} colors={skin.body} overlay
            overlayColors={skin.jacket} showOverlay={overlays.jacket}
            transform={`translate3d(${u*5}px, ${u*14}px, 0)`}/>
      {/* Left arm — pivot from shoulder */}
      <div style={{ position: 'absolute', left: u*3, top: u*8, width: u*4, height: u*12,
                    transformStyle: 'preserve-3d',
                    transform: `rotateZ(${armOut}deg) rotateX(${armSwing}deg)`,
                    transformOrigin: `${u*2}px ${u*2}px` }}>
        <Cube w={u*4} h={u*12} d={u*4} colors={skin.armL} overlay
              overlayColors={skin.sleeveL} showOverlay={overlays.sleeves}
              transform={`translate3d(${u*2}px, ${u*6}px, 0)`}/>
      </div>
      {/* Right arm */}
      <div style={{ position: 'absolute', left: u*7, top: u*8, width: u*4, height: u*12,
                    transformStyle: 'preserve-3d',
                    transform: `rotateZ(${-armOut}deg) rotateX(${-armSwing}deg)`,
                    transformOrigin: `${u*2}px ${u*2}px` }}>
        <Cube w={u*4} h={u*12} d={u*4} colors={skin.armR} overlay
              overlayColors={skin.sleeveR} showOverlay={overlays.sleeves}
              transform={`translate3d(${u*2}px, ${u*6}px, 0)`}/>
      </div>
      {/* Left leg */}
      <div style={{ position: 'absolute', left: u*5, top: u*20, width: u*4, height: u*12,
                    transformStyle: 'preserve-3d',
                    transform: `rotateX(${legSwing}deg)`,
                    transformOrigin: `${u*2}px ${u*0.5}px` }}>
        <Cube w={u*4} h={u*12} d={u*4} colors={skin.legL} overlay
              overlayColors={skin.pantL} showOverlay={overlays.pants}
              transform={`translate3d(${u*2}px, ${u*6}px, 0)`}/>
      </div>
      {/* Right leg */}
      <div style={{ position: 'absolute', left: u*9, top: u*20, width: u*4, height: u*12,
                    transformStyle: 'preserve-3d',
                    transform: `rotateX(${-legSwing}deg)`,
                    transformOrigin: `${u*2}px ${u*0.5}px` }}>
        <Cube w={u*4} h={u*12} d={u*4} colors={skin.legR} overlay
              overlayColors={skin.pantR} showOverlay={overlays.pants}
              transform={`translate3d(${u*2}px, ${u*6}px, 0)`}/>
      </div>
    </div>
  );
}

// ── Skin palettes (hand-tuned so they read as distinct outfits) ──
const SKIN_PALETTES = [
  { // Ocean Runner (current)
    id: 'ocean', name: 'Ocean Runner', model: 'Slim', date: 'Mar 14', current: true,
    accent: '#47d9ff',
    colors: mkSkin({ skin: '#e8b890', hair: '#1e3a8a', shirt: '#47d9ff', pants: '#1b4b8a', overlay: '#9ff2ff' }),
  },
  { id: 'pixel-knight', name: 'Pixel Knight', model: 'Classic', date: 'Mar 02',
    accent: '#9ca3af',
    colors: mkSkin({ skin: '#e8c89a', hair: '#3a3a3a', shirt: '#6b7280', pants: '#374151', overlay: '#d1d5db' }),
  },
  { id: 'miner', name: 'Deep Miner', model: 'Classic', date: 'Feb 19',
    accent: '#ffb545',
    colors: mkSkin({ skin: '#d4a272', hair: '#2a1a0e', shirt: '#8b5a2b', pants: '#3f2a14', overlay: '#ffb545' }),
  },
  { id: 'ender', name: 'Ender Mage', model: 'Slim', date: 'Feb 04',
    accent: '#9747ff',
    colors: mkSkin({ skin: '#1a0f1e', hair: '#9747ff', shirt: '#2a1040', pants: '#140020', overlay: '#d9b2ff' }),
  },
  { id: 'redstone', name: 'Redstone Engineer', model: 'Classic', date: 'Jan 22',
    accent: '#ff5e5e',
    colors: mkSkin({ skin: '#d49c7c', hair: '#2a0a0a', shirt: '#d12525', pants: '#4a1212', overlay: '#ff6b6b' }),
  },
  { id: 'forest', name: 'Forest Ranger', model: 'Slim', date: 'Jan 08',
    accent: '#22ff84',
    colors: mkSkin({ skin: '#c49568', hair: '#3e2612', shirt: '#2f6b3a', pants: '#254a1e', overlay: '#56c074' }),
  },
  { id: 'arctic', name: 'Arctic Scout', model: 'Classic', date: 'Dec 28',
    accent: '#e0f7ff',
    colors: mkSkin({ skin: '#f2d4b0', hair: '#f4f4f4', shirt: '#dff5ff', pants: '#6a8fb5', overlay: '#ffffff' }),
  },
  { id: 'nether', name: 'Nether Champion', model: 'Classic', date: 'Dec 10',
    accent: '#ff6b3d',
    colors: mkSkin({ skin: '#8b1a14', hair: '#ff8c3d', shirt: '#3a0604', pants: '#1a0202', overlay: '#ffb545' }),
  },
];

function mkSkin({ skin, hair, shirt, pants, overlay }) {
  // Add subtle face shading per direction
  const shade = (c, amt) => `color-mix(in oklab, ${c} ${100-amt}%, black ${amt}%)`;
  const headFaces = {
    front: hair, back: hair, left: shade(hair, 10), right: shade(hair, 10),
    top: shade(hair, 5), bottom: skin,
  };
  // Face on front (skin + eyes)
  headFaces.front = `linear-gradient(to bottom,
    ${hair} 0%, ${hair} 38%,
    ${skin} 38%, ${skin} 100%)`;
  const bodyFaces = { front: shirt, back: shade(shirt, 10), left: shade(shirt, 15), right: shade(shirt, 15), top: shade(shirt, 5), bottom: shade(pants, 10) };
  const armFaces  = { front: shirt, back: shade(shirt, 10), left: shade(shirt, 15), right: shade(shirt, 15), top: shade(skin, 0), bottom: skin };
  const legFaces  = { front: pants, back: shade(pants, 10), left: shade(pants, 15), right: shade(pants, 15), top: shade(pants, 5), bottom: shade(pants, 20) };
  const ovl = (c) => ({ front: c, back: c, left: shade(c, 10), right: shade(c, 10), top: shade(c, 5), bottom: shade(c, 5) });
  const transparentOvl = ovl('rgba(255,255,255,0.14)');
  return {
    head: headFaces, body: bodyFaces,
    armL: armFaces, armR: armFaces, legL: legFaces, legR: legFaces,
    hat: ovl(overlay),
    jacket: transparentOvl,
    sleeveL: transparentOvl, sleeveR: transparentOvl,
    pantL: transparentOvl, pantR: transparentOvl,
  };
}

// ── Overlay pictogram glyphs (hat / jacket / sleeves / pants) ──
// Blocky 8×8-ish Minecraft-style silhouettes so they read as clothing items.
const OverlayGlyph = {
  hat: ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 14 14" fill="none">
      {/* crown */}
      <rect x="3" y="3" width="8" height="4" fill="currentColor"/>
      {/* brim */}
      <rect x="1" y="7" width="12" height="2" fill="currentColor"/>
    </svg>
  ),
  jacket: ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 14 14" fill="none">
      {/* collar / shoulders */}
      <path d="M3 3 L5 3 L5 5 L9 5 L9 3 L11 3 L13 5 L13 12 L1 12 L1 5 Z" fill="currentColor"/>
      {/* open seam */}
      <rect x="6.5" y="5" width="1" height="7" fill="#05070a"/>
    </svg>
  ),
  sleeves: ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 14 14" fill="none">
      {/* left sleeve */}
      <rect x="1" y="4" width="3" height="7" fill="currentColor"/>
      {/* torso gap */}
      <rect x="5" y="4" width="4" height="7" fill="currentColor" opacity="0.25"/>
      {/* right sleeve */}
      <rect x="10" y="4" width="3" height="7" fill="currentColor"/>
    </svg>
  ),
  pants: ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 14 14" fill="none">
      <rect x="2" y="2" width="10" height="3" fill="currentColor"/>
      <rect x="2" y="5" width="4" height="7" fill="currentColor"/>
      <rect x="8" y="5" width="4" height="7" fill="currentColor"/>
    </svg>
  ),
};

// ── Pose pictogram glyphs (default / tpose / walking / running / sneaking / swimming) ──
// Tiny stick-figure silhouettes — quickly readable at 16px.
const PoseGlyph = {
  default: ({ size = 16 }) => (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round">
      <circle cx="8" cy="3" r="1.6" fill="currentColor"/>
      <path d="M8 5 L8 10"/>
      <path d="M6 7 L8 6.5 L10 7"/>
      <path d="M8 10 L6.5 14"/>
      <path d="M8 10 L9.5 14"/>
    </svg>
  ),
  tpose: ({ size = 16 }) => (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round">
      <circle cx="8" cy="3" r="1.6" fill="currentColor"/>
      <path d="M8 5 L8 10"/>
      <path d="M1 6.5 L15 6.5"/>
      <path d="M8 10 L6.5 14"/>
      <path d="M8 10 L9.5 14"/>
    </svg>
  ),
  walking: ({ size = 16 }) => (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round">
      <circle cx="8" cy="3" r="1.6" fill="currentColor"/>
      <path d="M8 5 L8 10"/>
      <path d="M5.5 8 L8 6.5 L10.5 7.5"/>
      <path d="M8 10 L5.5 14"/>
      <path d="M8 10 L10.5 13"/>
    </svg>
  ),
  running: ({ size = 16 }) => (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round">
      <circle cx="9" cy="3" r="1.6" fill="currentColor"/>
      {/* tilted body */}
      <path d="M9 5 L7 10"/>
      {/* arms swung fwd/back */}
      <path d="M4.5 6 L7 7 L10 5.5"/>
      {/* legs mid-stride */}
      <path d="M7 10 L4 12"/>
      <path d="M7 10 L11 14"/>
      {/* speed lines */}
      <path d="M1.5 5 L3.5 5"/>
      <path d="M1 8 L3 8"/>
    </svg>
  ),
  sneaking: ({ size = 16 }) => (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round">
      <circle cx="6" cy="6" r="1.6" fill="currentColor"/>
      {/* crouched body leaning fwd */}
      <path d="M6 8 L9 10"/>
      <path d="M5 9 L7.5 9.5"/>
      <path d="M9 10 L7 14"/>
      <path d="M9 10 L11 14"/>
    </svg>
  ),
  swimming: ({ size = 16 }) => (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round">
      {/* horizontal body */}
      <circle cx="3.5" cy="7" r="1.4" fill="currentColor"/>
      <path d="M5 7 L12 7"/>
      {/* arm forward */}
      <path d="M3 5 L6 3"/>
      {/* legs kicking */}
      <path d="M12 7 L14 5"/>
      <path d="M12 7 L14 9.5"/>
      {/* wave */}
      <path d="M1 12 Q4 11 7 12 T13 12" opacity="0.6"/>
    </svg>
  ),
};

// ── Main viewer (big, draggable) ──
function SkinViewer({ skin, overlays, setOverlays }) {
  const [drag, setDrag] = React.useState(null);
  const [rot, setRot] = React.useState(-20);
  const [auto, setAuto] = React.useState(true);
  const [anim, setAnim] = React.useState('default');
  const [animTime, setAnimTime] = React.useState(0);

  // Spin
  React.useEffect(() => {
    if (!auto || drag) return;
    let raf, last = performance.now();
    const tick = (t) => {
      const dt = (t - last) / 1000; last = t;
      setRot(r => r + dt * 18);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [auto, drag]);

  // Pose clock — only runs for animated poses
  React.useEffect(() => {
    if (anim === 'default' || anim === 'tpose') { setAnimTime(0); return; }
    let raf, start = performance.now();
    const tick = (t) => {
      setAnimTime(t - start);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [anim]);

  const toggleOverlay = (k) => (e) => {
    e.stopPropagation();
    setOverlays(o => ({ ...o, [k]: !o[k] }));
  };

  const FloatBtn = ({ active, title, onClick, children }) => (
    <button
      onClick={onClick}
      onMouseDown={(e) => e.stopPropagation()}
      title={title}
      style={{
        width: 34, height: 34, borderRadius: 8,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: active ? 'rgba(34,255,132,0.14)' : 'rgba(8,10,14,0.72)',
        color: active ? 'var(--mc-green)' : 'var(--ink-2)',
        border: active ? '1px solid rgba(34,255,132,0.5)' : '1px solid rgba(255,255,255,0.08)',
        backdropFilter: 'blur(8px)',
        cursor: 'pointer',
        boxShadow: active ? '0 0 14px rgba(34,255,132,0.25), 0 2px 6px rgba(0,0,0,0.4)' : '0 2px 6px rgba(0,0,0,0.4)',
        transition: 'all 0.15s',
      }}>
      {children}
    </button>
  );

  const poses = [
    { id: 'default',  label: 'Default' },
    { id: 'tpose',    label: 'T-pose' },
    { id: 'walking',  label: 'Walking' },
    { id: 'running',  label: 'Running' },
    { id: 'sneaking', label: 'Sneaking' },
    { id: 'swimming', label: 'Swimming' },
  ];
  const overlayItems = [
    { k: 'hat',     label: 'Hat' },
    { k: 'jacket',  label: 'Jacket' },
    { k: 'sleeves', label: 'Sleeves' },
    { k: 'pants',   label: 'Pants' },
  ];

  return (
    <div
      onMouseDown={(e) => { setAuto(false); setDrag({ x: e.clientX, r: rot }); }}
      onMouseMove={(e) => { if (drag) setRot(drag.r + (e.clientX - drag.x) * 0.6); }}
      onMouseUp={() => setDrag(null)}
      onMouseLeave={() => setDrag(null)}
      style={{
        position: 'relative', height: 360,
        background: 'radial-gradient(ellipse at 50% 70%, rgba(34,255,132,0.14) 0%, transparent 60%), #05070a',
        border: '1px solid var(--line)',
        borderRadius: 14,
        overflow: 'hidden',
        cursor: drag ? 'grabbing' : 'grab',
        perspective: 900,
      }}>
      {/* grid floor */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `linear-gradient(rgba(34,255,132,0.08) 1px, transparent 1px),
                          linear-gradient(90deg, rgba(34,255,132,0.08) 1px, transparent 1px)`,
        backgroundSize: '24px 24px',
        maskImage: 'radial-gradient(ellipse at 50% 80%, rgba(0,0,0,0.6) 0%, transparent 70%)',
        WebkitMaskImage: 'radial-gradient(ellipse at 50% 80%, rgba(0,0,0,0.6) 0%, transparent 70%)',
      }}/>
      {/* Character */}
      <div style={{
        position: 'absolute', left: '50%', top: '50%',
        transform: 'translate(-50%, -50%)',
        transformStyle: 'preserve-3d',
      }}>
        <Character skin={skin} rotation={rot} size={1} overlays={overlays} anim={anim} animTime={animTime}/>
      </div>
      {/* shadow */}
      <div style={{
        position: 'absolute', left: '50%', bottom: 36,
        transform: 'translateX(-50%)',
        width: 120, height: 14, borderRadius: '50%',
        background: 'radial-gradient(ellipse, rgba(0,0,0,0.6), transparent 70%)',
        filter: 'blur(2px)',
      }}/>

      {/* ── Left rail · overlay toggles ── */}
      <div style={{
        position: 'absolute', top: 14, left: 14,
        display: 'flex', flexDirection: 'column', gap: 8,
      }}
           onMouseDown={(e) => e.stopPropagation()}>
        <div style={{ fontSize: 9, color: 'var(--ink-3)', fontFamily: 'var(--mono)', letterSpacing: 1.2, marginBottom: 2, paddingLeft: 2 }}>
          LAYERS
        </div>
        {overlayItems.map(({ k, label }) => {
          const Glyph = OverlayGlyph[k];
          return (
            <FloatBtn key={k} active={overlays[k]} onClick={toggleOverlay(k)} title={`${label} · ${overlays[k] ? 'on' : 'off'}`}>
              <Glyph size={14}/>
            </FloatBtn>
          );
        })}
      </div>

      {/* ── Right rail · pose radio ── */}
      <div style={{
        position: 'absolute', top: 14, right: 14,
        display: 'flex', flexDirection: 'column', gap: 8,
      }}
           onMouseDown={(e) => e.stopPropagation()}>
        <div style={{ fontSize: 9, color: 'var(--ink-3)', fontFamily: 'var(--mono)', letterSpacing: 1.2, marginBottom: 2, textAlign: 'right', paddingRight: 2 }}>
          POSE
        </div>
        {poses.map(p => {
          const Glyph = PoseGlyph[p.id];
          return (
            <FloatBtn key={p.id} active={anim === p.id} onClick={(e) => { e.stopPropagation(); setAnim(p.id); }} title={p.label}>
              <Glyph size={16}/>
            </FloatBtn>
          );
        })}
      </div>

      {/* auto-spin toggle — pinned bottom right */}
      <button className="btn-icon" onClick={(e) => { e.stopPropagation(); setAuto(a => !a); }}
              onMouseDown={(e) => e.stopPropagation()}
              style={{ position: 'absolute', bottom: 12, right: 14, width: 30, height: 30,
                       background: auto ? 'rgba(34,255,132,0.12)' : 'rgba(8,10,14,0.72)',
                       color: auto ? 'var(--mc-green)' : 'var(--ink-2)',
                       borderColor: auto ? 'rgba(34,255,132,0.4)' : 'rgba(255,255,255,0.08)',
                       backdropFilter: 'blur(8px)' }}>
        <I.refresh size={12}/>
      </button>
      <div style={{ position: 'absolute', bottom: 14, left: 14, fontSize: 10, color: 'var(--ink-3)',
                    fontFamily: 'var(--mono)', letterSpacing: 1 }}>
        DRAG TO ROTATE · {Math.round(((rot % 360)+360) % 360)}°
      </div>
    </div>
  );
}

// ── Small preview (grid card) ──
function SkinThumb({ skin, overlays, selected, onClick }) {
  const [rot, setRot] = React.useState(0);
  const [hover, setHover] = React.useState(false);
  React.useEffect(() => {
    if (!hover) return;
    let raf, last = performance.now();
    const tick = (t) => { const dt = (t-last)/1000; last = t; setRot(r => r + dt * 60); raf = requestAnimationFrame(tick); };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [hover]);
  return (
    <div
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      onClick={onClick}
      style={{
        position: 'relative', height: 130,
        background: `radial-gradient(ellipse at 50% 75%, ${skin._accent || 'rgba(34,255,132,0.12)'} 0%, transparent 60%), #05070a`,
        border: selected ? '1px solid var(--mc-green)' : '1px solid var(--line)',
        boxShadow: selected ? '0 0 0 3px rgba(34,255,132,0.12)' : 'none',
        borderRadius: 10, overflow: 'hidden', cursor: 'pointer',
        perspective: 600,
      }}>
      <div style={{
        position: 'absolute', left: '50%', top: '50%',
        transform: 'translate(-50%, -50%) scale(0.32)',
        transformStyle: 'preserve-3d',
      }}>
        <Character skin={skin} rotation={hover ? rot : -15} size={1} overlays={overlays}/>
      </div>
      {selected && (
        <div style={{ position: 'absolute', top: 6, right: 6,
                      width: 18, height: 18, borderRadius: '50%',
                      background: 'var(--mc-green)', color: '#062814',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      boxShadow: '0 0 10px var(--mc-green-glow)' }}>
          <I.check size={11} strokeWidth={3}/>
        </div>
      )}
    </div>
  );
}

// ── Section ──
function SkinBrowser() {
  const [selected, setSelected] = React.useState('ocean');
  const [overlays, setOverlays] = React.useState({ hat: true, jacket: true, sleeves: true, pants: true });
  const current = SKIN_PALETTES.find(s => s.id === selected) || SKIN_PALETTES[0];

  return (
    <div className="card" style={{ padding: 22, marginBottom: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: 16 }}>
        <div>
          <div style={{ fontSize: 14, fontWeight: 600 }}>Skin browser</div>
          <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 2 }}>
            {SKIN_PALETTES.length} saved skins · syncs to all online instances
          </div>
        </div>
        <div style={{ flex: 1 }}/>
        <button className="btn-ghost" style={{ padding: '6px 10px', fontSize: 11 }}><I.folder size={12}/> Open folder</button>
      </div>

      {/* Big viewer + info */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 260px', gap: 14, marginBottom: 18 }}>
        <SkinViewer skin={current.colors} overlays={overlays} setOverlays={setOverlays}/>
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)', letterSpacing: 1.2, marginBottom: 6 }}>
            SELECTED · {current.current ? 'IN USE' : 'PREVIEWING'}
          </div>
          <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: -0.3, marginBottom: 2 }}>{current.name}</div>
          <div style={{ fontSize: 11, color: 'var(--ink-3)', marginBottom: 14 }}>{current.model} model · uploaded {current.date}</div>

          {/* Quick stats */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 14 }}>
            <div style={{ padding: '10px 12px', background: 'rgba(255,255,255,0.03)', border: '1px solid var(--line)', borderRadius: 8 }}>
              <div style={{ fontSize: 9, color: 'var(--ink-3)', fontFamily: 'var(--mono)', letterSpacing: 1 }}>RESOLUTION</div>
              <div style={{ fontSize: 13, fontWeight: 700, marginTop: 2 }}>64×64</div>
            </div>
            <div style={{ padding: '10px 12px', background: 'rgba(255,255,255,0.03)', border: '1px solid var(--line)', borderRadius: 8 }}>
              <div style={{ fontSize: 9, color: 'var(--ink-3)', fontFamily: 'var(--mono)', letterSpacing: 1 }}>ACCENT</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 2 }}>
                <div style={{ width: 14, height: 14, borderRadius: 4, background: current.accent, boxShadow: `0 0 8px ${current.accent}80` }}/>
                <div style={{ fontSize: 11, fontFamily: 'var(--mono)', fontWeight: 600 }}>{current.accent}</div>
              </div>
            </div>
          </div>

          <div style={{ fontSize: 10, color: 'var(--ink-3)', marginBottom: 14, lineHeight: 1.5 }}>
            Toggle <span style={{ color: 'var(--mc-green)' }}>overlay layers</span> on the left of the viewer · pick a <span style={{ color: 'var(--mc-green)' }}>pose</span> on the right.
          </div>

          <div style={{ display: 'flex', gap: 6, marginTop: 'auto' }}>
            {current.current
              ? <button className="btn-ghost" style={{ flex: 1, justifyContent: 'center' }}><I.check size={12}/> Active</button>
              : <button className="btn-primary" style={{ flex: 1, justifyContent: 'center' }}>Apply skin</button>}
            <button className="btn-icon" style={{ width: 34, height: 34 }}><I.more size={14}/></button>
          </div>
        </div>
      </div>

      {/* Saved grid */}
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: 10 }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--ink-2)' }}>Library</div>
        <div style={{ flex: 1 }}/>
        <div style={{ fontSize: 10, color: 'var(--ink-4)', fontFamily: 'var(--mono)' }}>HOVER TO SPIN</div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10 }}>
        {SKIN_PALETTES.map(s => (
          <div key={s.id}>
            <SkinThumb skin={{...s.colors, _accent: `color-mix(in oklab, ${s.accent} 40%, transparent)`}}
                       overlays={overlays}
                       selected={selected === s.id}
                       onClick={() => setSelected(s.id)}/>
            <div style={{ fontSize: 11, fontWeight: 600, marginTop: 6,
                          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.name}</div>
            <div style={{ fontSize: 10, color: 'var(--ink-4)', fontFamily: 'var(--mono)' }}>{s.model} · {s.date}</div>
          </div>
        ))}
        {/* Upload slot */}
        <div style={{
          height: 130, borderRadius: 10, border: '2px dashed var(--line-strong)',
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          gap: 6, cursor: 'pointer', color: 'var(--ink-3)',
        }}>
          <I.plus size={18}/>
          <div style={{ fontSize: 11, fontWeight: 600 }}>Upload skin</div>
          <div style={{ fontSize: 9, color: 'var(--ink-4)', fontFamily: 'var(--mono)' }}>.PNG · 64×64</div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { SkinBrowser });
