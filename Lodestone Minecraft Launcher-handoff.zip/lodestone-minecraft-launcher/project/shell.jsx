// shell.jsx — sidebar, header, and the synthetic "minecraft scene" background
// ──────────────────────────────────────────────────────────────

// Synthetic voxel-ish scene cover. No external imagery — pure CSS + SVG.
// `biome` picks a color palette; `seed` shifts the terrain silhouette.
function Scene({ biome = 'forest', seed = 0, style, children }) {
  // Deterministic pseudo-random from seed
  const r = (i) => {
    const x = Math.sin((seed + 1) * 9301 + i * 49297) * 233280;
    return x - Math.floor(x);
  };
  // Build a jagged skyline silhouette
  const cols = 18;
  const heights = Array.from({length: cols}, (_, i) => 30 + r(i) * 55);
  const skyline = heights.map((h, i) => {
    const x = (i / (cols - 1)) * 100;
    return `${x}% ${100 - h}%`;
  });
  const hillPath = `polygon(0% 100%, ${skyline.join(', ')}, 100% 100%)`;

  // Sun / moon position
  const sunX = 15 + r(99) * 70;
  const sunY = 18 + r(100) * 20;

  return (
    <div className={`biome-${biome}`} style={{ position: 'relative', overflow: 'hidden', width: '100%', height: '100%', ...style }}>
      {/* Sun/moon */}
      <div style={{
        position: 'absolute', left: `${sunX}%`, top: `${sunY}%`,
        width: 60, height: 60, borderRadius: '50%',
        background: biome === 'nether' ? '#ffd98a' : biome === 'end' ? '#fff' : '#fff2b8',
        boxShadow: biome === 'nether' ? '0 0 60px #ff9b5a' : '0 0 60px rgba(255,242,184,0.5)',
        opacity: 0.9,
      }}/>
      {/* Back hills */}
      <div style={{
        position: 'absolute', inset: 0,
        clipPath: `polygon(0% 100%, 0% 60%, 12% 58%, 22% 65%, 34% 52%, 48% 58%, 62% 50%, 76% 56%, 88% 48%, 100% 54%, 100% 100%)`,
        background: 'linear-gradient(180deg, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0.5) 100%)',
        opacity: 0.55,
      }}/>
      {/* Front terrain */}
      <div style={{
        position: 'absolute', inset: 0,
        clipPath: hillPath,
        background: biome === 'nether'
          ? 'linear-gradient(180deg, #5a1e18 0%, #2a0a08 100%)'
          : biome === 'end'
          ? 'linear-gradient(180deg, #3a2a5a 0%, #0f0a1a 100%)'
          : biome === 'ocean'
          ? 'linear-gradient(180deg, #0e3566 0%, #02111f 100%)'
          : biome === 'desert'
          ? 'linear-gradient(180deg, #8a5e28 0%, #3e2912 100%)'
          : biome === 'snow'
          ? 'linear-gradient(180deg, #d8e5f5 0%, #4a6a8a 100%)'
          : biome === 'cherry'
          ? 'linear-gradient(180deg, #7c2a5a 0%, #2a0a1e 100%)'
          : 'linear-gradient(180deg, #2a5a34 0%, #0e2414 100%)',
      }}/>
      {/* Grass strip */}
      {biome !== 'nether' && biome !== 'end' && biome !== 'ocean' && (
        <div style={{
          position: 'absolute', inset: 0,
          clipPath: hillPath,
          background: `linear-gradient(180deg,
            transparent 0%, transparent calc(100% - 100px),
            ${biome==='desert'?'#c48b3a':biome==='snow'?'#e8f0fa':biome==='cherry'?'#d86bac':'#3faa5a'} calc(100% - 100px),
            ${biome==='desert'?'#c48b3a':biome==='snow'?'#e8f0fa':biome==='cherry'?'#d86bac':'#3faa5a'} calc(100% - 96px),
            transparent calc(100% - 96px))`,
        }}/>
      )}
      {/* Pixel grid overlay for "voxel" feel */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `linear-gradient(90deg, rgba(0,0,0,0.18) 1px, transparent 1px),
                          linear-gradient(0deg, rgba(0,0,0,0.18) 1px, transparent 1px)`,
        backgroundSize: '16px 16px',
        opacity: 0.35, pointerEvents: 'none',
      }}/>
      {/* Gentle vignette */}
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.5) 100%)', pointerEvents: 'none' }}/>
      {children}
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// Sidebar — vertical icon rail
function Sidebar({ active = 'home', onNav }) {
  const items = [
    { id: 'home',    icon: I.home,    label: 'Library' },
    { id: 'browse',  icon: I.compass, label: 'Discover' },
    { id: 'worlds',  icon: I.globe,   label: 'Worlds' },
    { id: 'servers', icon: I.server,  label: 'Servers' },
    { id: 'friends', icon: I.users,   label: 'Friends' },
  ];
  return (
    <div style={{
      width: 68, flexShrink: 0,
      background: 'var(--bg-1)',
      borderRight: '1px solid var(--line)',
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      padding: '18px 0', gap: 6, position: 'relative',
    }}>
      {/* Logo — Lodestone block */}
      <div style={{ marginBottom: 14, position: 'relative' }}>
        {/* glow halo */}
        <div style={{
          position: 'absolute', inset: -6, borderRadius: 14,
          background: 'radial-gradient(circle, rgba(34,255,132,0.45) 0%, transparent 70%)',
          filter: 'blur(8px)', pointerEvents: 'none',
        }}/>
        <img src="lodestone-logo.svg" alt="Lodestone" width={40} height={40}
             style={{
               position: 'relative', display: 'block',
               filter: 'drop-shadow(0 0 6px rgba(34,255,132,0.5))',
             }}/>
      </div>
      <div className="div-line" style={{ width: 32, marginBottom: 4 }}/>
      {items.map(it => {
        const IconComp = it.icon;
        return (
          <div key={it.id}
               className={`nav-item ${active === it.id ? 'active' : ''}`}
               onClick={() => onNav && onNav(it.id)}
               title={it.label}>
            <IconComp size={20}/>
          </div>
        );
      })}
      <div style={{ flex: 1 }}/>
      <div className="nav-item" title="Downloads">
        <I.download size={20}/>
      </div>
      <div className="nav-item" title="Settings">
        <I.settings size={20}/>
      </div>
      {/* User avatar */}
      <div style={{
        width: 40, height: 40, borderRadius: 10,
        marginTop: 8,
        background: 'linear-gradient(135deg, #22ff84 0%, #0a5c33 100%)',
        border: '2px solid rgba(34,255,132,0.6)',
        boxShadow: '0 0 16px var(--mc-green-glow)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 14, fontWeight: 800, color: '#062814', cursor: 'pointer',
        position: 'relative',
      }}>
        EN
        <div style={{
          position: 'absolute', bottom: -1, right: -1,
          width: 10, height: 10, borderRadius: '50%',
          background: 'var(--mc-green)', border: '2px solid var(--bg-1)',
        }}/>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// Header — title + search + actions
function TitleBar({ title, subtitle, children }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 16,
      padding: '18px 28px', borderBottom: '1px solid var(--line)',
      background: 'rgba(8,9,10,0.7)', backdropFilter: 'blur(20px)',
      position: 'relative', zIndex: 10,
    }}>
      <div>
        <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: -0.3 }}>{title}</div>
        {subtitle && <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 2 }}>{subtitle}</div>}
      </div>
      <div style={{ flex: 1 }}/>
      {children}
    </div>
  );
}

// Window chrome — three buttons
function WindowChrome() {
  return (
    <div style={{
      position: 'absolute', top: 0, left: 0, right: 0,
      height: 32, zIndex: 50,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 12px',
      pointerEvents: 'none',
    }}>
      <div style={{ display: 'flex', gap: 8, pointerEvents: 'auto' }}>
        <div style={{ width: 11, height: 11, borderRadius: '50%', background: '#ff5f57', border: '1px solid rgba(0,0,0,0.2)' }}/>
        <div style={{ width: 11, height: 11, borderRadius: '50%', background: '#febc2e', border: '1px solid rgba(0,0,0,0.2)' }}/>
        <div style={{ width: 11, height: 11, borderRadius: '50%', background: '#28c840', border: '1px solid rgba(0,0,0,0.2)' }}/>
      </div>
      <div style={{
        fontSize: 11, color: 'var(--ink-3)',
        fontFamily: 'var(--mono)', letterSpacing: 0.3,
      }}>LODESTONE · v2.1.4</div>
      <div style={{ width: 50 }}/>
    </div>
  );
}

// Particle drift field
function Particles({ count = 18, color = 'var(--mc-green)' }) {
  const particles = Array.from({length: count}, (_, i) => i);
  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden' }}>
      {particles.map(i => {
        const delay = (i * 0.37) % 12;
        const dur = 8 + (i * 0.7) % 6;
        const left = (i * 17.3) % 100;
        const size = 1 + (i % 3);
        return (
          <div key={i} style={{
            position: 'absolute',
            left: `${left}%`, bottom: -10,
            width: size, height: size,
            borderRadius: '50%',
            background: color,
            boxShadow: `0 0 ${4+size}px ${color}`,
            opacity: 0.6,
            animation: `drift ${dur}s linear ${delay}s infinite`,
          }}/>
        );
      })}
      <style>{`
        @keyframes drift {
          0% { transform: translateY(0) translateX(0); opacity: 0; }
          10% { opacity: 0.7; }
          90% { opacity: 0.7; }
          100% { transform: translateY(-110vh) translateX(30px); opacity: 0; }
        }
      `}</style>
    </div>
  );
}

Object.assign(window, { Scene, Sidebar, TitleBar, WindowChrome, Particles });
