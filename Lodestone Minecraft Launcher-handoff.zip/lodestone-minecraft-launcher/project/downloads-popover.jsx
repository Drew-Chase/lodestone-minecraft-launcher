// downloads-popover.jsx — the sidebar Downloads popover
function DownloadsPopover() {
  const active = [
    { name: 'All the Mods 9',     sub: '412 files · v0.2.60', prog: 0.68, speed: '14.2 MB/s', eta: '48s',  biome: 'end',    seed: 55, kind: 'modpack' },
    { name: 'Sodium',             sub: 'Fabric · 1.20.1',     prog: 0.92, speed: '8.1 MB/s',  eta: '3s',   kind: 'mod' },
  ];
  const queue = [
    { name: 'Distant Horizons',   sub: 'Fabric · 1.20.1',     biome: 'ocean', seed: 9, kind: 'mod' },
    { name: 'Fabulously Optimized', sub: 'Modpack · 87 mods', biome: 'forest', seed: 3, kind: 'modpack' },
    { name: 'Complementary Shaders',sub: 'Shader · v5.2',     kind: 'shader' },
  ];
  const completed = [
    { name: 'Iris Shaders',       sub: 'Installed · 2m ago',   kind: 'mod' },
    { name: 'Create: Astral',     sub: 'Installed · 14m ago',  biome: 'desert', seed: 31, kind: 'modpack' },
    { name: 'BSL Shaders',        sub: 'Installed · 1h ago',   kind: 'shader' },
  ];

  const totalSpeed = '22.3 MB/s';
  const totalProg = 0.74;

  return (
    <div style={{
      position: 'absolute',
      left: 76, bottom: 88,   // anchored next to the Downloads sidebar icon
      width: 380, maxHeight: 560,
      background: 'linear-gradient(180deg, var(--bg-2) 0%, var(--bg-1) 100%)',
      border: '1px solid var(--line-strong)',
      borderRadius: 14,
      boxShadow: '0 20px 60px rgba(0,0,0,0.6), 0 0 0 1px rgba(34,255,132,0.08), 0 0 40px rgba(34,255,132,0.05)',
      overflow: 'hidden',
      display: 'flex', flexDirection: 'column',
      zIndex: 200,
    }}>
      {/* Arrow tip pointing to sidebar icon */}
      <div style={{
        position: 'absolute', left: -7, bottom: 24, width: 14, height: 14,
        background: 'var(--bg-2)',
        borderLeft: '1px solid var(--line-strong)',
        borderBottom: '1px solid var(--line-strong)',
        transform: 'rotate(45deg)',
      }}/>

      {/* Header with aggregate progress */}
      <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--line)', background: 'rgba(0,0,0,0.25)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
          <I.download size={15} style={{ color: 'var(--mc-green)' }}/>
          <div style={{ fontSize: 13, fontWeight: 700 }}>Downloads</div>
          <span className="chip green" style={{ fontSize: 9, padding: '2px 7px' }}>
            <span className="pulse-dot" style={{ width: 5, height: 5 }}/> {active.length} ACTIVE
          </span>
          <div style={{ flex: 1 }}/>
          <button className="btn-icon" style={{ width: 26, height: 26 }} title="Pause all"><I.pause size={12}/></button>
          <button className="btn-icon" style={{ width: 26, height: 26 }} title="Settings"><I.settings size={12}/></button>
        </div>
        {/* Aggregate bar */}
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 5, fontFamily: 'var(--mono)', fontSize: 10 }}>
            <span style={{ color: 'var(--ink-2)' }}>{Math.round(totalProg*100)}%</span>
            <div style={{ flex: 1 }}/>
            <span style={{ color: 'var(--mc-green)', fontWeight: 700 }}>↓ {totalSpeed}</span>
            <span style={{ color: 'var(--ink-3)' }}>·</span>
            <span style={{ color: 'var(--ink-3)' }}>ETA 1m 12s</span>
          </div>
          <div style={{ height: 6, borderRadius: 3, background: 'rgba(255,255,255,0.05)', overflow: 'hidden', position: 'relative' }}>
            <div style={{
              width: `${totalProg*100}%`, height: '100%',
              background: 'linear-gradient(90deg, var(--mc-green) 0%, color-mix(in oklab, var(--mc-green) 60%, var(--cyan)) 100%)',
              boxShadow: '0 0 10px var(--mc-green-glow)',
            }}/>
            {/* moving shimmer */}
            <div style={{
              position: 'absolute', top: 0, bottom: 0, left: 0, width: 40,
              background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)',
              animation: 'dlShimmer 1.4s linear infinite',
              mixBlendMode: 'overlay',
            }}/>
          </div>
        </div>
        <style>{`@keyframes dlShimmer { 0% { transform: translateX(-40px); } 100% { transform: translateX(380px); } }`}</style>
      </div>

      {/* Body — scrollable */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '12px 12px' }}>
        {/* Active */}
        <DLSection label="DOWNLOADING" count={active.length}>
          {active.map((d,i) => (
            <DLActiveRow key={i} d={d}/>
          ))}
        </DLSection>

        {/* Queue */}
        <DLSection label="QUEUED" count={queue.length}>
          {queue.map((d,i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '8px 8px', borderRadius: 8,
            }}>
              <DLThumb kind={d.kind} biome={d.biome} seed={d.seed}/>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.name}</div>
                <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>{d.sub}</div>
              </div>
              <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>#{i+1}</div>
              <button className="btn-icon" style={{ width: 24, height: 24 }}><I.x size={11}/></button>
            </div>
          ))}
        </DLSection>

        {/* Completed */}
        <DLSection label="COMPLETED" count={completed.length}>
          {completed.map((d,i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '8px 8px', borderRadius: 8,
              opacity: 0.75,
            }}>
              <DLThumb kind={d.kind} biome={d.biome} seed={d.seed} done/>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.name}</div>
                <div style={{ fontSize: 10, color: 'var(--mc-green)', fontFamily: 'var(--mono)', display: 'flex', alignItems: 'center', gap: 4 }}>
                  <I.check size={9}/> {d.sub}
                </div>
              </div>
            </div>
          ))}
        </DLSection>
      </div>

      {/* Footer */}
      <div style={{ padding: '10px 14px', borderTop: '1px solid var(--line)', display: 'flex', alignItems: 'center', gap: 8, background: 'rgba(0,0,0,0.2)' }}>
        <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>
          2.4 GB today · 14.2 GB this week
        </div>
        <div style={{ flex: 1 }}/>
        <button className="btn-ghost" style={{ padding: '5px 10px', fontSize: 11 }}>Clear completed</button>
      </div>
    </div>
  );
}

function DLSection({ label, count, children }) {
  return (
    <div style={{ marginBottom: 12 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '0 8px', marginBottom: 4,
        fontSize: 9, fontFamily: 'var(--mono)', fontWeight: 700, letterSpacing: 1, color: 'var(--ink-3)' }}>
        <span>{label}</span>
        <span style={{ color: 'var(--ink-4)' }}>{count}</span>
        <div style={{ flex: 1, height: 1, background: 'var(--line)' }}/>
      </div>
      {children}
    </div>
  );
}

function DLActiveRow({ d }) {
  return (
    <div style={{
      padding: 10, borderRadius: 10,
      background: 'rgba(34,255,132,0.04)',
      border: '1px solid color-mix(in oklab, var(--mc-green) 20%, transparent)',
      marginBottom: 6,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
        <DLThumb kind={d.kind} biome={d.biome} seed={d.seed}/>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12, fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.name}</div>
          <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>{d.sub}</div>
        </div>
        <button className="btn-icon" style={{ width: 24, height: 24 }} title="Pause"><I.pause size={11}/></button>
        <button className="btn-icon" style={{ width: 24, height: 24 }} title="Cancel"><I.x size={11}/></button>
      </div>
      {/* Progress */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{ flex: 1, height: 4, borderRadius: 2, background: 'rgba(255,255,255,0.06)', overflow: 'hidden', position: 'relative' }}>
          <div style={{
            width: `${d.prog*100}%`, height: '100%',
            background: 'var(--mc-green)',
            boxShadow: '0 0 8px var(--mc-green-glow)',
          }}/>
        </div>
        <div style={{ fontSize: 10, fontFamily: 'var(--mono)', color: 'var(--ink-2)', fontWeight: 600, minWidth: 36, textAlign: 'right' }}>
          {Math.round(d.prog*100)}%
        </div>
      </div>
      <div style={{ display: 'flex', gap: 8, marginTop: 6, fontSize: 10, fontFamily: 'var(--mono)' }}>
        <span style={{ color: 'var(--mc-green)', fontWeight: 700 }}>↓ {d.speed}</span>
        <span style={{ color: 'var(--ink-4)' }}>·</span>
        <span style={{ color: 'var(--ink-3)' }}>ETA {d.eta}</span>
      </div>
    </div>
  );
}

function DLThumb({ kind, biome, seed, done }) {
  const color = done ? 'var(--mc-green)' : kind === 'mod' ? 'var(--cyan)' : kind === 'shader' ? 'var(--violet)' : 'var(--amber)';
  if (biome !== undefined && biome !== null) {
    return (
      <div style={{ width: 36, height: 36, borderRadius: 7, overflow: 'hidden', position: 'relative', flexShrink: 0 }}>
        <Scene biome={biome} seed={seed}/>
      </div>
    );
  }
  const Ic = kind === 'mod' ? I.box : kind === 'shader' ? I.image : I.pkg;
  return (
    <div style={{
      width: 36, height: 36, borderRadius: 7, flexShrink: 0,
      background: `color-mix(in oklab, ${color} 14%, var(--bg-3))`,
      border: `1px solid color-mix(in oklab, ${color} 30%, transparent)`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: color,
    }}>
      <Ic size={16}/>
    </div>
  );
}

Object.assign(window, { DownloadsPopover });
