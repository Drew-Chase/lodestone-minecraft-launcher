// screen-friends.jsx — social / friends
function ScreenFriends() {
  const friends = [
    { name: 'ShadowCrafter_92',   status: 'playing',  activity: 'Lodestone SMP',    inst: 'Aether Legacy',    streak: 12, color: '#22ff84', avatar: 'S', mutual: true  },
    { name: 'pixelpoet',          status: 'playing',  activity: 'Solo · Prominence',inst: 'Prominence II RPG', streak: 4,  color: '#ff5ec8', avatar: 'P', mutual: true  },
    { name: 'Maple_Mori',         status: 'playing',  activity: 'Cobblemon Server', inst: 'Cobblemon Official',streak: 27, color: '#ffb545', avatar: 'M', mutual: true  },
    { name: 'dustbrick',          status: 'online',   activity: 'In launcher',      inst: null,                streak: 0,  color: '#47d9ff', avatar: 'd', mutual: true  },
    { name: 'Ironhart',           status: 'online',   activity: 'Browsing mods',    inst: null,                streak: 0,  color: '#9747ff', avatar: 'I', mutual: true  },
    { name: 'moth_dev',           status: 'away',     activity: 'Idle · 12m',       inst: 'All the Mods 9',    streak: 2,  color: '#ffb545', avatar: 'm', mutual: false },
    { name: 'Notch_37',           status: 'offline',  activity: 'Last seen 2h ago', inst: null,                streak: 0,  color: '#7a8088', avatar: 'N', mutual: true  },
    { name: 'CaveRunner',         status: 'offline',  activity: 'Last seen 1d ago', inst: null,                streak: 0,  color: '#7a8088', avatar: 'C', mutual: true  },
    { name: 'red_panda',          status: 'offline',  activity: 'Last seen 3d ago', inst: null,                streak: 0,  color: '#7a8088', avatar: 'r', mutual: false },
  ];
  const requests = [
    { name: 'VoxelBird',   mutual: 3, avatar: 'V', color: '#47d9ff' },
    { name: 'enderseek',   mutual: 1, avatar: 'e', color: '#9747ff' },
  ];

  const online = friends.filter(f => f.status !== 'offline');
  const offline = friends.filter(f => f.status === 'offline');

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--bg-0)' }}>
      <TitleBar title="Friends" subtitle={`${online.length} online · ${friends.length} total`}>
        <div style={{ position: 'relative' }}>
          <I.search size={14} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--ink-3)' }}/>
          <input placeholder="Find friends…" className="input"
                 style={{ paddingLeft: 34, width: 240 }}/>
        </div>
        <button className="btn-ghost" style={{ padding: '9px 14px' }}>
          <I.users size={14}/> Invite to party
        </button>
        <button className="btn-primary" style={{ padding: '9px 14px' }}>
          <I.plus size={14}/> Add friend
        </button>
      </TitleBar>

      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 340px', gap: 0, minHeight: 0 }}>
        {/* Left — main list */}
        <div style={{ overflowY: 'auto', padding: '24px 28px', borderRight: '1px solid var(--line)' }}>
          {/* Friend requests banner */}
          {requests.length > 0 && (
            <div style={{
              marginBottom: 20, padding: '12px 16px', borderRadius: 12,
              background: 'color-mix(in oklab, var(--mc-green) 8%, var(--bg-2))',
              border: '1px solid color-mix(in oklab, var(--mc-green) 25%, transparent)',
              display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: 8,
                background: 'rgba(34,255,132,0.14)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: 'var(--mc-green)',
              }}>
                <I.user size={16}/>
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 700 }}>
                  {requests.length} pending friend request{requests.length===1?'':'s'}
                </div>
                <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 1 }}>
                  {requests.map(r => r.name).join(' · ')}
                </div>
              </div>
              <button className="btn-ghost" style={{ padding: '6px 12px', fontSize: 11 }}>
                Review
              </button>
            </div>
          )}

          {/* Online */}
          <SectionLabel count={online.length}>ONLINE</SectionLabel>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2, marginBottom: 28 }}>
            {online.map((f,i) => <FriendRow key={i} friend={f}/>)}
          </div>

          {/* Offline */}
          <SectionLabel count={offline.length}>OFFLINE</SectionLabel>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {offline.map((f,i) => <FriendRow key={i} friend={f}/>)}
          </div>
        </div>

        {/* Right — party panel */}
        <PartyPanel friends={friends.slice(0,3)}/>
      </div>
    </div>
  );
}

function SectionLabel({ children, count }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8,
      fontSize: 10, fontFamily: 'var(--mono)', fontWeight: 700,
      letterSpacing: 1, color: 'var(--ink-3)',
      marginBottom: 10,
    }}>
      <span>{children}</span>
      <span style={{ color: 'var(--ink-4)' }}>{count}</span>
      <div style={{ flex: 1, height: 1, background: 'var(--line)' }}/>
    </div>
  );
}

function FriendRow({ friend }) {
  const dotColor = friend.status === 'playing' ? 'var(--mc-green)'
                : friend.status === 'online'  ? 'var(--cyan)'
                : friend.status === 'away'    ? 'var(--amber)'
                : 'var(--ink-4)';
  const muted = friend.status === 'offline';
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '10px 12px', borderRadius: 10, cursor: 'pointer',
      transition: 'background 0.15s',
    }} onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,255,255,0.03)'}
       onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
      {/* Avatar */}
      <div style={{
        width: 38, height: 38, borderRadius: 8,
        background: `linear-gradient(135deg, ${friend.color} 0%, color-mix(in oklab, ${friend.color} 50%, #000) 100%)`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 15, fontWeight: 800, color: muted ? 'rgba(255,255,255,0.4)' : '#000',
        position: 'relative', flexShrink: 0,
        opacity: muted ? 0.4 : 1,
      }}>
        {friend.avatar}
        {/* status dot */}
        <div style={{
          position: 'absolute', bottom: -1, right: -1,
          width: 10, height: 10, borderRadius: '50%',
          background: dotColor,
          border: '2px solid var(--bg-0)',
          boxShadow: friend.status === 'playing' ? '0 0 6px var(--mc-green-glow)' : 'none',
        }}/>
      </div>
      {/* Name + status */}
      <div style={{ flex: 1, minWidth: 0, opacity: muted ? 0.6 : 1 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ fontSize: 13, fontWeight: 700 }}>{friend.name}</span>
          {friend.streak >= 10 && (
            <span style={{
              fontSize: 9, padding: '1px 5px', borderRadius: 3,
              background: 'rgba(255,181,69,0.14)', color: 'var(--amber)',
              fontFamily: 'var(--mono)', fontWeight: 700,
            }}>🔥 {friend.streak}d</span>
          )}
        </div>
        <div style={{ fontSize: 11, color: friend.status === 'playing' ? 'var(--mc-green)' : 'var(--ink-3)', display: 'flex', alignItems: 'center', gap: 6, marginTop: 1 }}>
          {friend.status === 'playing' && <I.play size={9} style={{ fill: 'var(--mc-green)' }}/>}
          <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{friend.activity}</span>
        </div>
      </div>
      {/* Actions */}
      {!muted && (
        <div style={{ display: 'flex', gap: 4 }}>
          <button className="btn-icon" style={{ width: 30, height: 30 }} title="Message"><I.message size={13}/></button>
          {friend.status === 'playing' && (
            <button className="btn-primary" style={{ padding: '6px 10px', fontSize: 11 }}>
              <I.zap size={10}/> Join
            </button>
          )}
          {friend.status !== 'playing' && (
            <button className="btn-ghost" style={{ padding: '6px 10px', fontSize: 11 }}>Invite</button>
          )}
        </div>
      )}
      {muted && (
        <button className="btn-icon" style={{ width: 30, height: 30 }}><I.more size={13}/></button>
      )}
    </div>
  );
}

function PartyPanel({ friends }) {
  return (
    <div style={{ padding: '24px 22px', display: 'flex', flexDirection: 'column', gap: 18 }}>
      {/* Party */}
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
          <div style={{ fontSize: 11, fontFamily: 'var(--mono)', fontWeight: 700, letterSpacing: 1, color: 'var(--ink-3)' }}>
            YOUR PARTY
          </div>
          <div style={{ flex: 1 }}/>
          <span className="chip green" style={{ fontSize: 9, padding: '2px 7px' }}>
            <span className="pulse-dot" style={{ width: 5, height: 5 }}/> LIVE
          </span>
        </div>
        <div className="card" style={{ padding: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: -4, marginBottom: 12 }}>
            {friends.map((f,i) => (
              <div key={i} style={{
                width: 36, height: 36, borderRadius: 8,
                background: `linear-gradient(135deg, ${f.color} 0%, color-mix(in oklab, ${f.color} 50%, #000) 100%)`,
                border: '2px solid var(--bg-2)',
                marginLeft: i === 0 ? 0 : -8,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 14, fontWeight: 800, color: '#000',
              }}>{f.avatar}</div>
            ))}
            <div style={{
              width: 36, height: 36, borderRadius: 8,
              background: 'rgba(255,255,255,0.04)', border: '2px dashed var(--line-strong)',
              marginLeft: -8, display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'var(--ink-3)',
            }}>
              <I.plus size={14}/>
            </div>
            <div style={{ flex: 1 }}/>
            <div style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>{friends.length}/10</div>
          </div>
          <div style={{ fontSize: 12, color: 'var(--ink-2)', lineHeight: 1.4, marginBottom: 10 }}>
            <strong style={{ color: 'var(--ink-0)' }}>ShadowCrafter_92</strong> + 2 others queued for <span style={{ color: 'var(--mc-green)' }}>Lodestone SMP</span>.
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <button className="btn-primary" style={{ padding: '7px 12px', fontSize: 11, flex: 1, justifyContent: 'center' }}>
              <I.play size={10}/> Launch as party
            </button>
            <button className="btn-icon" style={{ width: 30, height: 30 }} title="Voice"><I.headset size={13}/></button>
          </div>
        </div>
      </div>

      {/* Voice */}
      <div>
        <div style={{ fontSize: 11, fontFamily: 'var(--mono)', fontWeight: 700, letterSpacing: 1, color: 'var(--ink-3)', marginBottom: 10 }}>
          VOICE · CONNECTED
        </div>
        <div className="card" style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
          {friends.slice(0,3).map((f,i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{
                width: 22, height: 22, borderRadius: 5,
                background: `linear-gradient(135deg, ${f.color} 0%, color-mix(in oklab, ${f.color} 50%, #000) 100%)`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 10, fontWeight: 800, color: '#000',
              }}>{f.avatar}</div>
              <div style={{ fontSize: 12, flex: 1, fontWeight: 600 }}>{f.name}</div>
              <VoiceMeter active={i!==2}/>
            </div>
          ))}
        </div>
      </div>

      {/* Recent activity */}
      <div>
        <div style={{ fontSize: 11, fontFamily: 'var(--mono)', fontWeight: 700, letterSpacing: 1, color: 'var(--ink-3)', marginBottom: 10 }}>
          RECENT ACTIVITY
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, fontSize: 11, color: 'var(--ink-2)', lineHeight: 1.5 }}>
          <ActivityItem name="Maple_Mori" color="#ffb545" text="caught a shiny Eevee in Cobblemon" time="2m"/>
          <ActivityItem name="pixelpoet"  color="#ff5ec8" text="reached Vault Level 50" time="18m"/>
          <ActivityItem name="dustbrick"  color="#47d9ff" text="installed Create: Astral" time="1h"/>
          <ActivityItem name="Ironhart"   color="#9747ff" text="published a custom modpack" time="3h"/>
        </div>
      </div>
    </div>
  );
}

function VoiceMeter({ active }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 2, height: 10 }}>
      {[1,2,3,4,5].map(n => (
        <div key={n} style={{
          width: 2, height: active ? 3 + ((n*7)%9) : 2, borderRadius: 1,
          background: active ? 'var(--mc-green)' : 'var(--ink-4)',
          boxShadow: active ? '0 0 4px var(--mc-green-glow)' : 'none',
          transition: 'all 0.2s',
        }}/>
      ))}
    </div>
  );
}

function ActivityItem({ name, color, text, time }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
      <span style={{ color, fontWeight: 700 }}>{name}</span>
      <span style={{ flex: 1, color: 'var(--ink-2)' }}>{text}</span>
      <span style={{ color: 'var(--ink-4)', fontFamily: 'var(--mono)', fontSize: 10 }}>{time}</span>
    </div>
  );
}

Object.assign(window, { ScreenFriends });
