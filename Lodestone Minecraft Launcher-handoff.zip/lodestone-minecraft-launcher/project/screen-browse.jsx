// screen-browse.jsx — Discover / browse via Modrinth + CurseForge
// filterVariant: 'none' | 'popover' | 'drawer'
function ScreenBrowse({ filterVariant = 'none' } = {}) {
  const [tab, setTab] = React.useState('modpacks');
  const [source, setSource] = React.useState('all'); // all | modrinth | curseforge
  const [query, setQuery] = React.useState('');
  const [viewMode, setViewMode] = React.useState('grid'); // grid | compact | table
  const showPopover = filterVariant === 'popover';
  const showDrawer  = filterVariant === 'drawer';
  const tabs = [
    { id: 'modpacks', label: 'Modpacks', count: '4,218' },
    { id: 'mods', label: 'Mods', count: '89,432' },
    { id: 'resource', label: 'Resource Packs', count: '12,084' },
    { id: 'shaders', label: 'Shaders', count: '1,247' },
    { id: 'worlds', label: 'Worlds', count: '3,512' },
    { id: 'datapacks', label: 'Data Packs', count: '2,109' },
  ];

  const packs = [
    { name: 'Better MC · Fabric', author: 'SHEEPY',     src: 'modrinth',   dl: '18.2M', stars: 4.9, mods: 127, biome: 'forest', seed: 12, tags: ['ADVENTURE', 'FABRIC'], color: 'green', installed: true, desc: '120+ hand-picked mods for a richer vanilla-plus experience.' },
    { name: 'Prominence II RPG', author: 'Hypno',       src: 'curseforge', dl: '9.4M',  stars: 4.8, mods: 348, biome: 'nether', seed: 22, tags: ['RPG', 'FORGE'], color: 'pink',   desc: 'A sprawling RPG with 10 classes and a custom questline.' },
    { name: 'Create: Astral',    author: 'Laskyyy',     src: 'curseforge', dl: '7.1M',  stars: 4.9, mods: 184, biome: 'desert', seed: 31, tags: ['TECH', 'FABRIC'], color: 'amber', desc: 'Build factories in the sky. Skyblock meets Create automation.' },
    { name: 'Cobblemon Official',author: 'Cobblemon',   src: 'modrinth',   dl: '14.8M', stars: 4.7, mods: 62,  biome: 'cherry', seed: 44, tags: ['MONSTERS', 'FABRIC'], color: 'pink', desc: 'Catch, train, and battle 1500+ creatures in a pixelated world.' },
    { name: 'All the Mods 9',    author: 'ATM Team',    src: 'curseforge', dl: '22.6M', stars: 4.8, mods: 412, biome: 'end', seed: 55, tags: ['KITCHEN SINK', 'FORGE'], color: 'violet', desc: 'Nearly every mod worth playing, balanced into one huge pack.' },
    { name: 'Vault Hunters 3rd', author: 'Iskall85',    src: 'curseforge', dl: '11.3M', stars: 4.9, mods: 271, biome: 'ocean', seed: 66, tags: ['ROGUELIKE', 'FORGE'], color: 'cyan', desc: 'Descend procedural vaults for loot, gear, and boss fights.' },
    { name: 'Adrenaline',        author: 'jellysquid',  src: 'modrinth',   dl: '4.2M',  stars: 4.6, mods: 14,  biome: 'snow',   seed: 77, tags: ['PERFORMANCE', 'FABRIC'], color: 'cyan', desc: 'Sodium, Lithium and friends, pre-bundled for max FPS.' },
    { name: 'Medieval MC',       author: 'MedievalMC',  src: 'curseforge', dl: '3.8M',  stars: 4.5, mods: 156, biome: 'cherry', seed: 88, tags: ['MEDIEVAL', 'FORGE'], color: 'amber', desc: 'Castles, knights, and mounted combat in a low-magic world.' },
  ];
  const visible = packs.filter(p => source === 'all' || p.src === source)
                       .filter(p => !query || p.name.toLowerCase().includes(query.toLowerCase()) || p.author.toLowerCase().includes(query.toLowerCase()));

  // Glowing-underline tab
  const GlowTab = ({ id, label, count, active, onClick }) => (
    <button onClick={onClick}
      style={{
        background: 'transparent', border: 'none', cursor: 'pointer',
        padding: '10px 4px', margin: '0 14px 0 0',
        color: active ? '#fff' : 'var(--ink-2)',
        fontSize: 13, fontWeight: active ? 700 : 500,
        fontFamily: 'inherit', position: 'relative',
        letterSpacing: -0.1,
        transition: 'color 0.15s',
      }}
      onMouseEnter={(e) => !active && (e.currentTarget.style.color = '#fff')}
      onMouseLeave={(e) => !active && (e.currentTarget.style.color = 'var(--ink-2)')}>
      {label}
      <span style={{ marginLeft: 6, fontSize: 10, opacity: 0.55, fontFamily: 'var(--mono)', fontWeight: 500 }}>{count}</span>
      {/* Underline (always present so layout doesn't jump) */}
      <span style={{
        position: 'absolute', left: 0, right: 0, bottom: -1, height: 2,
        borderRadius: 2,
        background: active ? 'var(--mc-green)' : 'transparent',
        boxShadow: active ? '0 0 8px var(--mc-green), 0 0 14px var(--mc-green-glow)' : 'none',
        transition: 'all 0.2s ease',
      }}/>
    </button>
  );

  // Source segmented control
  const SourceBtn = ({ id, label, icon, color }) => {
    const on = source === id;
    return (
      <button onClick={() => setSource(id)}
        style={{
          display: 'inline-flex', alignItems: 'center', gap: 6,
          padding: '7px 12px', fontSize: 12, fontWeight: 600,
          background: on ? 'rgba(34,255,132,0.08)' : 'transparent',
          color: on ? '#fff' : 'var(--ink-2)',
          border: on ? '1px solid rgba(34,255,132,0.4)' : '1px solid transparent',
          borderRadius: 8, cursor: 'pointer', fontFamily: 'inherit',
          transition: 'all 0.15s',
        }}>
        {icon}
        {label}
      </button>
    );
  };

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, background: 'var(--bg-0)', position: 'relative' }}>
      <TitleBar title="Discover" subtitle="Search across Modrinth and CurseForge">
        <div style={{ position: 'relative' }}>
          <I.search size={14} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--ink-3)' }}/>
          <input className="input" value={query} onChange={e=>setQuery(e.target.value)}
                 placeholder="Search Modrinth + CurseForge…" style={{ width: 340, paddingLeft: 34 }}/>
          <kbd className="kbd" style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)' }}>⌘ K</kbd>
        </div>
        <div style={{ position: 'relative' }}>
          <button className="btn-icon"
            style={showPopover ? {
              background: 'rgba(34,255,132,0.12)',
              borderColor: 'rgba(34,255,132,0.5)',
              color: 'var(--mc-green)',
              boxShadow: '0 0 0 3px rgba(34,255,132,0.15)',
            } : undefined}>
            <I.filter size={16}/>
            <span style={{
              position: 'absolute', top: 4, right: 4,
              width: 7, height: 7, borderRadius: '50%',
              background: 'var(--mc-green)',
              boxShadow: '0 0 6px var(--mc-green)',
            }}/>
          </button>
          {showPopover && <FilterPopover/>}
        </div>
      </TitleBar>
      {showDrawer && <FilterDrawer/>}

      {/* Source toggle + tabs row */}
      <div style={{ padding: '16px 28px 0', borderBottom: '1px solid var(--line)' }}>
        {/* Source providers */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 10 }}>
          <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)', letterSpacing: 1, marginRight: 10 }}>SOURCE</div>
          <SourceBtn id="all" label="All providers"
            icon={<span style={{width:14,height:14,display:'inline-flex',alignItems:'center',justifyContent:'center',borderRadius:4,background:'linear-gradient(135deg,#22ff84,#ff8c5a)'}}/>}/>
          <SourceBtn id="modrinth" label="Modrinth"
            icon={<svg width="13" height="13" viewBox="0 0 10 10"><path d="M1 5a4 4 0 018-1M9 5a4 4 0 01-8 1M5 1.2V4M5 6v2.8" stroke="var(--mc-green)" strokeWidth="1.4" fill="none" strokeLinecap="round"/></svg>}/>
          <SourceBtn id="curseforge" label="CurseForge"
            icon={<svg width="13" height="13" viewBox="0 0 10 10"><path d="M5 1l1.2 2.5L9 4l-2 1.8L7.5 9 5 7.6 2.5 9 3 5.8 1 4l2.8-.5L5 1z" fill="#ff8c5a"/></svg>}/>
          <div style={{ flex: 1 }}/>
          <div style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)', display: 'flex', alignItems: 'center', gap: 6 }}>
            <span className="pulse-dot" style={{ width: 5, height: 5 }}/>
            API · 89 ms · cached
          </div>
        </div>
        {/* Glowing underline tabs */}
        <div style={{ display: 'flex', flexWrap: 'wrap' }}>
          {tabs.map(t => (
            <GlowTab key={t.id} id={t.id} label={t.label} count={t.count}
              active={tab === t.id} onClick={() => setTab(t.id)}/>
          ))}
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '20px 28px 40px' }}>
        {/* Featured banner */}
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 14, marginBottom: 24 }}>
          <div className="card" style={{ height: 220, padding: 0, position: 'relative', overflow: 'hidden' }}>
            <Scene biome="end" seed={55}/>
            <Particles count={15} color="var(--violet)"/>
            <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(90deg, rgba(8,9,10,0.9) 0%, transparent 65%)', display: 'flex', alignItems: 'flex-end', padding: 22 }}>
              <div>
                <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 8 }}>
                  <span className="chip violet">EDITOR'S PICK</span>
                  <SourceBadge src="curseforge"/>
                </div>
                <div style={{ fontSize: 26, fontWeight: 800, letterSpacing: -0.5 }}>All the Mods 9</div>
                <div style={{ fontSize: 12, color: 'var(--ink-2)', maxWidth: 360, margin: '6px 0 12px' }}>
                  Every mod worth playing, balanced into one huge pack. 400+ mods, 300 quests.
                </div>
                <button className="btn-primary"><I.download size={13}/> Install · 4.2 GB</button>
              </div>
            </div>
          </div>
          <div className="card" style={{ height: 220, padding: 0, position: 'relative', overflow: 'hidden' }}>
            <Scene biome="cherry" seed={44}/>
            <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(8,9,10,0.3) 0%, rgba(8,9,10,0.95) 100%)', display: 'flex', alignItems: 'flex-end', padding: 18 }}>
              <div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <span className="chip pink">NEW</span>
                  <SourceBadge src="modrinth"/>
                </div>
                <div style={{ fontSize: 18, fontWeight: 700, marginTop: 6 }}>Cobblemon 1.5</div>
                <div style={{ fontSize: 11, color: 'var(--ink-2)', marginTop: 4 }}>+213 new species · March 2026</div>
              </div>
            </div>
          </div>
        </div>

        {/* Filters row */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 18, flexWrap: 'wrap', alignItems: 'center' }}>
          <button className="select"><I.tag size={12}/> Category <I.chevDown size={11}/></button>
          <button className="select">Loader: All <I.chevDown size={11}/></button>
          <button className="select">Version: 1.20.x <I.chevDown size={11}/></button>
          <button className="select">Sort: Popular <I.chevDown size={11}/></button>
          <div style={{ flex: 1 }}/>
          <div style={{ fontSize: 12, color: 'var(--ink-3)', alignSelf: 'center' }}>
            {visible.length} result{visible.length!==1?'s':''} · {source === 'all' ? 'Modrinth + CurseForge' : source === 'modrinth' ? 'Modrinth' : 'CurseForge'}
          </div>
          <ViewModeToggle mode={viewMode} onChange={setViewMode}/>
        </div>

        {/* Results — switches layout */}
        {viewMode === 'grid'    && <BrowseGrid    items={visible}/>}
        {viewMode === 'compact' && <BrowseCompact items={visible}/>}
        {viewMode === 'table'   && <BrowseTable   items={visible}/>}
      </div>
    </div>
  );
}

Object.assign(window, { ScreenBrowse });

// ─── Source badge (module scope so view-mode components can use it) ──
function SourceBadge({ src }) {
  if (src === 'modrinth') {
    return (
      <span style={{
        display: 'inline-flex', alignItems: 'center', gap: 5,
        fontSize: 9, fontFamily: 'var(--mono)', fontWeight: 700, letterSpacing: 0.5,
        padding: '3px 7px', borderRadius: 999,
        background: 'rgba(34,255,132,0.12)', color: 'var(--mc-green)',
        border: '1px solid rgba(34,255,132,0.3)',
      }}>
        <svg width="9" height="9" viewBox="0 0 10 10"><path d="M1 5a4 4 0 018-1M9 5a4 4 0 01-8 1M5 1.2V4M5 6v2.8" stroke="currentColor" strokeWidth="1.4" fill="none" strokeLinecap="round"/></svg>
        MODRINTH
      </span>
    );
  }
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      fontSize: 9, fontFamily: 'var(--mono)', fontWeight: 700, letterSpacing: 0.5,
      padding: '3px 7px', borderRadius: 999,
      background: 'rgba(255,107,61,0.14)', color: '#ff8c5a',
      border: '1px solid rgba(255,107,61,0.3)',
    }}>
      <svg width="9" height="9" viewBox="0 0 10 10"><path d="M5 1l1.2 2.5L9 4l-2 1.8L7.5 9 5 7.6 2.5 9 3 5.8 1 4l2.8-.5L5 1z" fill="currentColor"/></svg>
      CURSEFORGE
    </span>
  );
}

// ─── Browse view modes ───────────────────────────────────────────────

function BrowseGrid({ items }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
      {items.map((p, i) => (
        <div key={i} className="card">
          <div style={{ position: 'relative', height: 130 }}>
            <Scene biome={p.biome} seed={p.seed}/>
            <div style={{ position: 'absolute', top: 8, left: 8, right: 8, display: 'flex', gap: 4, zIndex: 2, flexWrap: 'wrap' }}>
              {p.tags.map(t => <span key={t} className={`chip ${p.color}`} style={{ fontSize: 9, padding: '2px 6px' }}>{t}</span>)}
            </div>
            <div style={{ position: 'absolute', bottom: 8, left: 8, zIndex: 2 }}>
              <SourceBadge src={p.src}/>
            </div>
            {p.installed && (
              <div style={{ position: 'absolute', bottom: 8, right: 8, zIndex: 2,
                background: 'rgba(34,255,132,0.2)', border: '1px solid var(--mc-green)',
                borderRadius: 6, padding: '3px 8px', fontSize: 10, fontWeight: 700, color: 'var(--mc-green)',
                display: 'flex', alignItems: 'center', gap: 4, fontFamily: 'var(--mono)' }}>
                <I.check size={10}/> INSTALLED
              </div>
            )}
          </div>
          <div style={{ padding: '12px 14px 14px' }}>
            <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</div>
            <div style={{ fontSize: 10, color: 'var(--ink-3)', marginBottom: 8 }}>by {p.author}</div>
            <div style={{ fontSize: 11, color: 'var(--ink-2)', lineHeight: 1.45, marginBottom: 12, minHeight: 32,
                          display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
              {p.desc}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)', flexWrap: 'nowrap' }}>
              <span title="Downloads" style={{ display: 'flex', alignItems: 'center', gap: 3 }}><I.download size={11}/> {p.dl}</span>
              <span title="Included mods" style={{ display: 'flex', alignItems: 'center', gap: 3 }}><I.box size={11}/> {p.mods}</span>
              <span title="Rating" style={{ display: 'flex', alignItems: 'center', gap: 3, color: 'var(--amber)' }}>
                <I.star size={11} style={{ fill: 'currentColor' }}/> {p.stars}
              </span>
              <div style={{ flex: 1 }}/>
              {p.installed
                ? <button className="btn-ghost" style={{ padding: '6px 10px', fontSize: 11 }}>Open</button>
                : <button className="btn-primary" style={{ padding: '6px 10px', fontSize: 11 }}><I.download size={10}/> Install</button>}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function BrowseCompact({ items }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
      {items.map((p, i) => (
        <div key={i} className="card" style={{ padding: 0, display: 'flex', gap: 0, overflow: 'hidden', cursor: 'pointer' }}>
          <div style={{ position: 'relative', width: 92, flexShrink: 0 }}>
            <Scene biome={p.biome} seed={p.seed}/>
            {p.installed && (
              <div style={{ position: 'absolute', top: 6, left: 6, zIndex: 2,
                background: 'rgba(34,255,132,0.2)', border: '1px solid var(--mc-green)',
                borderRadius: 4, padding: '1px 5px', fontSize: 8, fontWeight: 700, color: 'var(--mc-green)',
                fontFamily: 'var(--mono)' }}>✓ INST</div>
            )}
          </div>
          <div style={{ flex: 1, minWidth: 0, padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: 4 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, minWidth: 0 }}>
              <div style={{ fontSize: 12, fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1, minWidth: 0 }}>
                {p.name}
              </div>
              <SourceBadge src={p.src}/>
            </div>
            <div style={{ fontSize: 10, color: 'var(--ink-3)' }}>by {p.author}</div>
            <div style={{ fontSize: 11, color: 'var(--ink-2)', lineHeight: 1.35,
                          display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
              {p.desc}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)', marginTop: 'auto' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 3 }}><I.download size={10}/> {p.dl}</span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 3 }}><I.box size={10}/> {p.mods}</span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 3, color: 'var(--amber)' }}>
                <I.star size={10} style={{ fill: 'currentColor' }}/> {p.stars}
              </span>
              <div style={{ flex: 1 }}/>
              {p.installed
                ? <button className="btn-ghost" style={{ padding: '4px 9px', fontSize: 10 }}>Open</button>
                : <button className="btn-primary" style={{ padding: '4px 9px', fontSize: 10 }}><I.download size={9}/> Install</button>}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function BrowseTable({ items }) {
  return (
    <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
      <div style={{
        display: 'grid',
        gridTemplateColumns: '2.5fr 0.9fr 0.7fr 0.6fr 0.6fr 0.6fr 110px',
        gap: 0,
        padding: '10px 14px',
        borderBottom: '1px solid var(--line)',
        fontSize: 10, fontWeight: 700, color: 'var(--ink-3)',
        fontFamily: 'var(--mono)', letterSpacing: 1,
        background: 'rgba(0,0,0,0.25)',
      }}>
        <div>NAME</div>
        <div>AUTHOR</div>
        <div>SOURCE</div>
        <div style={{ textAlign: 'right' }}>DOWNLOADS</div>
        <div style={{ textAlign: 'right' }}>MODS</div>
        <div style={{ textAlign: 'right' }}>RATING</div>
        <div></div>
      </div>
      {items.map((p, i) => (
        <div key={i} style={{
          display: 'grid',
          gridTemplateColumns: '2.5fr 0.9fr 0.7fr 0.6fr 0.6fr 0.6fr 110px',
          alignItems: 'center',
          gap: 0,
          padding: '10px 14px',
          borderBottom: i === items.length - 1 ? 'none' : '1px solid var(--line)',
          fontSize: 12,
          cursor: 'pointer',
          background: i % 2 === 1 ? 'rgba(255,255,255,0.015)' : 'transparent',
        }}>
          {/* Name cell with thumbnail + installed pill */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
            <div style={{ width: 32, height: 32, borderRadius: 6, overflow: 'hidden', flexShrink: 0, position: 'relative' }}>
              <Scene biome={p.biome} seed={p.seed}/>
            </div>
            <div style={{ minWidth: 0, flex: 1 }}>
              <div style={{ fontSize: 12, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 6, minWidth: 0 }}>
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</span>
                {p.installed && (
                  <span style={{ padding: '1px 5px', borderRadius: 3, fontSize: 8, fontWeight: 700,
                    background: 'rgba(34,255,132,0.16)', color: 'var(--mc-green)', fontFamily: 'var(--mono)',
                    border: '1px solid color-mix(in oklab, var(--mc-green) 30%, transparent)', flexShrink: 0 }}>
                    INSTALLED
                  </span>
                )}
              </div>
              <div style={{ fontSize: 10, color: 'var(--ink-3)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {p.desc}
              </div>
            </div>
          </div>
          <div style={{ fontSize: 11, color: 'var(--ink-2)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.author}</div>
          <div><SourceBadge src={p.src}/></div>
          <div style={{ textAlign: 'right', fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-2)' }}>{p.dl}</div>
          <div style={{ textAlign: 'right', fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-2)' }}>{p.mods}</div>
          <div style={{ textAlign: 'right', fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--amber)',
                        display: 'flex', alignItems: 'center', gap: 3, justifyContent: 'flex-end' }}>
            <I.star size={10} style={{ fill: 'currentColor' }}/> {p.stars}
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            {p.installed
              ? <button className="btn-ghost" style={{ padding: '5px 10px', fontSize: 10 }}>Open</button>
              : <button className="btn-primary" style={{ padding: '5px 10px', fontSize: 10 }}><I.download size={9}/> Install</button>}
          </div>
        </div>
      ))}
    </div>
  );
}

Object.assign(window, { BrowseGrid, BrowseCompact, BrowseTable });

// ─────────────────────────────────────────────────────────────
// Filter UIs — two explorations: anchored popover vs slide-in drawer.
// Both share the same sections so the user can compare density / ergonomics.

const FILTER_SECTIONS = {
  categories: ['Adventure', 'Magic', 'Tech', 'Exploration', 'Survival', 'Performance', 'Quests', 'Multiplayer'],
  loaders:    ['Fabric', 'Forge', 'NeoForge', 'Quilt', 'Vanilla'],
  versions:   ['1.20.4', '1.20.1', '1.19.4', '1.18.2', '1.16.5', '1.12.2'],
  environment:['Client', 'Server', 'Client & Server'],
};

function Pill({ children, active, onClick, accent }) {
  return (
    <button onClick={onClick} style={{
      padding: '6px 12px', fontSize: 11, fontWeight: 600,
      borderRadius: 999, cursor: 'pointer', fontFamily: 'inherit',
      background: active ? (accent || 'rgba(34,255,132,0.14)') : 'rgba(255,255,255,0.04)',
      color: active ? (accent ? '#fff' : 'var(--mc-green)') : 'var(--ink-2)',
      border: `1px solid ${active ? 'rgba(34,255,132,0.5)' : 'var(--line)'}`,
      transition: 'all 0.12s',
      whiteSpace: 'nowrap',
    }}>{children}</button>
  );
}

function FilterSectionLabel({ children, count }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      marginBottom: 10,
    }}>
      <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)', letterSpacing: 1.2, fontWeight: 600 }}>
        {children}
      </div>
      {count != null && (
        <div style={{ fontSize: 10, color: 'var(--mc-green)', fontFamily: 'var(--mono)' }}>{count} ACTIVE</div>
      )}
    </div>
  );
}

// ── Popover: anchored to the filter button, ~340px wide, bottom-right
function FilterPopover() {
  const [cats, setCats] = React.useState(['Adventure', 'Magic']);
  const [loaders, setLoaders] = React.useState(['Fabric']);
  const [version, setVersion] = React.useState('1.20.1');
  const toggle = (list, setList, v) => setList(list.includes(v) ? list.filter(x=>x!==v) : [...list, v]);
  return (
    <div style={{
      position: 'absolute', top: 'calc(100% + 10px)', right: 0, zIndex: 50,
      width: 360, maxHeight: 520, overflow: 'hidden',
      background: 'rgba(14,16,18,0.96)', backdropFilter: 'blur(24px)',
      border: '1px solid var(--line-strong)',
      borderRadius: 14,
      boxShadow: '0 24px 48px -12px rgba(0,0,0,0.6), 0 0 0 1px rgba(34,255,132,0.1)',
      display: 'flex', flexDirection: 'column',
    }}>
      {/* Little arrow pointer */}
      <div style={{
        position: 'absolute', top: -6, right: 14,
        width: 12, height: 12, background: 'rgba(14,16,18,0.96)',
        border: '1px solid var(--line-strong)', borderRight: 'none', borderBottom: 'none',
        transform: 'rotate(45deg)',
      }}/>
      {/* Header */}
      <div style={{ padding: '14px 16px 10px', borderBottom: '1px solid var(--line)',
                    display: 'flex', alignItems: 'center', gap: 10 }}>
        <I.filter size={14} style={{ color: 'var(--mc-green)' }}/>
        <div style={{ fontSize: 13, fontWeight: 700 }}>Filters</div>
        <span style={{ fontSize: 10, fontFamily: 'var(--mono)', color: 'var(--mc-green)',
                       background: 'rgba(34,255,132,0.12)', padding: '2px 6px', borderRadius: 4 }}>
          {cats.length + loaders.length + 1} applied
        </span>
        <div style={{ flex: 1 }}/>
        <button className="btn-ghost" style={{ padding: '4px 8px', fontSize: 11 }}>Clear</button>
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflowY: 'auto', padding: 16 }}>
        <FilterSectionLabel count={cats.length}>CATEGORIES</FilterSectionLabel>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 18 }}>
          {FILTER_SECTIONS.categories.map(c =>
            <Pill key={c} active={cats.includes(c)} onClick={() => toggle(cats, setCats, c)}>{c}</Pill>
          )}
        </div>

        <FilterSectionLabel count={loaders.length}>MOD LOADER</FilterSectionLabel>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 18 }}>
          {FILTER_SECTIONS.loaders.map(l =>
            <Pill key={l} active={loaders.includes(l)} onClick={() => toggle(loaders, setLoaders, l)}>{l}</Pill>
          )}
        </div>

        <FilterSectionLabel>MINECRAFT VERSION</FilterSectionLabel>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 14 }}>
          {FILTER_SECTIONS.versions.map(v =>
            <Pill key={v} active={version === v} onClick={() => setVersion(v)}>{v}</Pill>
          )}
        </div>
      </div>

      {/* Footer */}
      <div style={{ padding: 12, borderTop: '1px solid var(--line)', display: 'flex', gap: 8, alignItems: 'center' }}>
        <div style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>1,482 results</div>
        <div style={{ flex: 1 }}/>
        <button className="btn-ghost" style={{ padding: '7px 12px', fontSize: 12 }}>Cancel</button>
        <button className="btn-primary" style={{ padding: '7px 14px', fontSize: 12 }}>Apply filters</button>
      </div>
    </div>
  );
}

// ── Drawer: slides in from right side, full height
function FilterDrawer() {
  const [cats, setCats] = React.useState(['Adventure', 'Magic', 'Quests']);
  const [loaders, setLoaders] = React.useState(['Fabric', 'Quilt']);
  const [version, setVersion] = React.useState('1.20.1');
  const [env, setEnv] = React.useState('Client & Server');
  const toggle = (list, setList, v) => setList(list.includes(v) ? list.filter(x=>x!==v) : [...list, v]);
  return (
    <>
      {/* Scrim */}
      <div style={{
        position: 'absolute', inset: 0, zIndex: 40,
        background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(2px)',
      }}/>
      {/* Panel */}
      <div style={{
        position: 'absolute', top: 0, right: 0, bottom: 0, zIndex: 41,
        width: 420,
        background: 'var(--bg-1)',
        borderLeft: '1px solid var(--line-strong)',
        boxShadow: '-24px 0 60px -12px rgba(0,0,0,0.6)',
        display: 'flex', flexDirection: 'column',
      }}>
        {/* Header */}
        <div style={{ padding: '20px 22px 16px', borderBottom: '1px solid var(--line)',
                      display: 'flex', alignItems: 'center', gap: 10 }}>
          <I.filter size={16} style={{ color: 'var(--mc-green)' }}/>
          <div style={{ fontSize: 15, fontWeight: 700 }}>Refine results</div>
          <div style={{ flex: 1 }}/>
          <button className="btn-icon" style={{ width: 32, height: 32 }}><I.x size={14}/></button>
        </div>

        <div style={{ padding: '14px 22px', borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '4px 10px', borderRadius: 999,
            background: 'rgba(34,255,132,0.12)', color: 'var(--mc-green)',
            fontSize: 11, fontWeight: 700, fontFamily: 'var(--mono)',
          }}>
            <span className="pulse-dot" style={{ width: 5, height: 5 }}/>
            {cats.length + loaders.length + 2} FILTERS
          </div>
          <div style={{ flex: 1 }}/>
          <button className="btn-ghost" style={{ padding: '5px 10px', fontSize: 11 }}>Clear all</button>
        </div>

        {/* Body */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '20px 22px' }}>
          <div style={{ marginBottom: 24 }}>
            <FilterSectionLabel count={cats.length}>CATEGORIES</FilterSectionLabel>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7 }}>
              {FILTER_SECTIONS.categories.map(c =>
                <Pill key={c} active={cats.includes(c)} onClick={() => toggle(cats, setCats, c)}>{c}</Pill>
              )}
            </div>
          </div>

          <div style={{ marginBottom: 24 }}>
            <FilterSectionLabel count={loaders.length}>MOD LOADER</FilterSectionLabel>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7 }}>
              {FILTER_SECTIONS.loaders.map(l =>
                <Pill key={l} active={loaders.includes(l)} onClick={() => toggle(loaders, setLoaders, l)}>{l}</Pill>
              )}
            </div>
          </div>

          <div style={{ marginBottom: 24 }}>
            <FilterSectionLabel>MINECRAFT VERSION</FilterSectionLabel>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7 }}>
              {FILTER_SECTIONS.versions.map(v =>
                <Pill key={v} active={version === v} onClick={() => setVersion(v)}>{v}</Pill>
              )}
            </div>
          </div>

          <div style={{ marginBottom: 24 }}>
            <FilterSectionLabel>ENVIRONMENT</FilterSectionLabel>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7 }}>
              {FILTER_SECTIONS.environment.map(e =>
                <Pill key={e} active={env === e} onClick={() => setEnv(e)}>{e}</Pill>
              )}
            </div>
          </div>

          <div style={{ marginBottom: 20 }}>
            <FilterSectionLabel>MINIMUM RATING</FilterSectionLabel>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0' }}>
              {[1,2,3,4,5].map(n => (
                <I.star key={n} size={20} style={{
                  fill: n <= 4 ? 'var(--amber)' : 'transparent',
                  color: n <= 4 ? 'var(--amber)' : 'var(--ink-4)',
                  cursor: 'pointer',
                }}/>
              ))}
              <span style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)', marginLeft: 6 }}>4.0+</span>
            </div>
          </div>

          <div>
            <FilterSectionLabel>DOWNLOADS</FilterSectionLabel>
            <div style={{
              position: 'relative', height: 30, display: 'flex', alignItems: 'center',
            }}>
              <div style={{ position: 'absolute', left: 0, right: 0, height: 4, borderRadius: 2, background: 'var(--line)' }}/>
              <div style={{ position: 'absolute', left: '15%', right: '5%', height: 4, borderRadius: 2,
                            background: 'var(--mc-green)', boxShadow: '0 0 8px var(--mc-green-glow)' }}/>
              <div style={{ position: 'absolute', left: '15%', width: 14, height: 14, borderRadius: '50%',
                            background: '#fff', transform: 'translateX(-50%)',
                            boxShadow: '0 2px 6px rgba(0,0,0,0.5), 0 0 0 3px rgba(34,255,132,0.25)' }}/>
              <div style={{ position: 'absolute', left: '95%', width: 14, height: 14, borderRadius: '50%',
                            background: '#fff', transform: 'translateX(-50%)',
                            boxShadow: '0 2px 6px rgba(0,0,0,0.5), 0 0 0 3px rgba(34,255,132,0.25)' }}/>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, color: 'var(--ink-3)',
                          fontFamily: 'var(--mono)', marginTop: 6 }}>
              <span>100K</span><span>∞</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div style={{ padding: '14px 22px', borderTop: '1px solid var(--line)',
                      display: 'flex', alignItems: 'center', gap: 10,
                      background: 'rgba(0,0,0,0.3)' }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, color: 'var(--mc-green)' }}>1,482</div>
            <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>MATCHING PACKS</div>
          </div>
          <div style={{ flex: 1 }}/>
          <button className="btn-primary" style={{ padding: '10px 16px' }}>Show results</button>
        </div>
      </div>
    </>
  );
}

Object.assign(window, { FilterPopover, FilterDrawer });
