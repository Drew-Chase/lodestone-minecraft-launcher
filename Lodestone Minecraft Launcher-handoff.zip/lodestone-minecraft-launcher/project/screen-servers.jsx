// screen-servers.jsx — multiplayer server browser
function ScreenServers() {
  const servers = [
    { name: 'Lodestone SMP',         addr: 'play.lodestone.gg',       players: 2847, max: 5000, ping: 24,  ver: '1.20.1',  kind: 'Survival',     motd: 'Season 4 · Economy · McMMO · Land Claims', biome: 'forest', seed: 1,  fav: true,  auth: true  },
    { name: 'Hypixel Network',       addr: 'mc.hypixel.net',          players: 48219,max: 100000,ping: 58,  ver: '1.8-1.20',kind: 'Minigames',    motd: 'Bedwars · Skywars · Duels · SkyBlock',     biome: 'end',    seed: 4,  fav: true,  auth: true  },
    { name: 'CubeCraft Games',       addr: 'play.cubecraft.net',      players: 8104, max: 20000, ping: 71,  ver: '1.20.1',  kind: 'Minigames',    motd: 'Minerware · EggWars · Tower Defense',       biome: 'cherry', seed: 6,               auth: true  },
    { name: 'Origin Realms',         addr: 'play.originrealms.com',   players: 1420, max: 2000,  ping: 41,  ver: '1.20.1',  kind: 'Survival',     motd: 'Vanilla+ · Decor · Custom mobs',            biome: 'ocean',  seed: 10,              auth: true  },
    { name: 'Friend\u2019s Realm',   addr: 'realm://aether-3',        players: 2,    max: 10,    ping: 12,  ver: '1.20.4',  kind: 'Realm',        motd: 'Aether Legacy · Hard · Invited', biome: 'snow', seed: 13, fav: true },
    { name: 'ATM9 Public',           addr: 'atm9.lodestone.gg',       players: 184,  max: 250,   ping: 33,  ver: '1.20.1',  kind: 'Modded',       motd: 'All the Mods 9 · 412 mods · No grief',     biome: 'nether', seed: 18               },
    { name: 'Galactic Build Team',   addr: 'build.galactic.co',       players: 0,    max: 100,   ping: 0,   ver: '1.20.1',  kind: 'Creative',     motd: 'Offline · Maintenance until 18:00 UTC',     biome: 'desert', seed: 24, offline: true },
  ];
  const [tab, setTab] = React.useState('all');
  const tabs = [
    { id:'all', label:'All servers', count: servers.length },
    { id:'fav', label:'Favorites',   count: servers.filter(s=>s.fav).length },
    { id:'realm', label:'Realms',    count: servers.filter(s=>s.kind==='Realm').length },
    { id:'lan',  label:'LAN',        count: 0 },
  ];

  const filtered = tab === 'all' ? servers
    : tab === 'fav' ? servers.filter(s => s.fav)
    : tab === 'realm' ? servers.filter(s => s.kind === 'Realm')
    : [];

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--bg-0)' }}>
      <TitleBar title="Servers" subtitle={`${servers.filter(s=>!s.offline).length} online · ${servers.reduce((a,s)=>a+s.players,0).toLocaleString()} players currently playing`}>
        <div style={{ position: 'relative' }}>
          <I.search size={14} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--ink-3)' }}/>
          <input placeholder="Paste IP or search by name…" className="input"
                 style={{ paddingLeft: 34, width: 320 }}/>
        </div>
        <button className="btn-ghost" style={{ padding: '9px 14px' }}>
          <I.refresh size={14}/> Refresh
        </button>
        <button className="btn-primary" style={{ padding: '9px 14px' }}>
          <I.plus size={14}/> Add server
        </button>
      </TitleBar>

      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 28px' }}>
        {/* Tabs with glow underline (matches Discover pattern) */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20, borderBottom: '1px solid var(--line)' }}>
          <div style={{ display: 'flex', gap: 4 }}>
            {tabs.map(t => {
              const active = tab === t.id;
              return (
                <button key={t.id} onClick={()=>setTab(t.id)} style={{
                  position: 'relative', padding: '10px 14px', background: 'transparent', border: 'none',
                  cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 7,
                  color: active ? 'var(--ink-0)' : 'var(--ink-3)', fontSize: 13, fontWeight: 600,
                }}>
                  {t.label}
                  <span style={{ fontSize: 10, color: active ? 'var(--mc-green)' : 'var(--ink-4)', fontFamily: 'var(--mono)' }}>{t.count}</span>
                  {active && (
                    <span style={{
                      position: 'absolute', bottom: -1, left: 10, right: 10, height: 2, borderRadius: 2,
                      background: 'var(--mc-green)', boxShadow: '0 0 10px 2px var(--mc-green-glow)',
                    }}/>
                  )}
                </button>
              );
            })}
          </div>
          <div style={{ flex: 1 }}/>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>
            <span className="pulse-dot" style={{ width: 6, height: 6 }}/>
            LIVE · PINGING EVERY 10s
          </div>
        </div>

        {/* Server list */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {filtered.map((s,i) => (
            <div key={i} className="card" style={{
              padding: 0, display: 'flex', alignItems: 'stretch', overflow: 'hidden',
              cursor: 'pointer',
              opacity: s.offline ? 0.55 : 1,
            }}>
              {/* Icon tile */}
              <div style={{ width: 92, flexShrink: 0, position: 'relative' }}>
                <Scene biome={s.biome} seed={s.seed}/>
                {s.fav && (
                  <div style={{ position:'absolute', top: 8, left: 8, zIndex: 2,
                    background: 'rgba(0,0,0,0.6)', borderRadius: 6, padding: 4 }}>
                    <I.star size={12} style={{ color: 'var(--amber)', fill: 'var(--amber)' }}/>
                  </div>
                )}
              </div>
              {/* Middle content */}
              <div style={{ flex: 1, minWidth: 0, padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: 4 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontSize: 14, fontWeight: 800, letterSpacing: -0.3 }}>{s.name}</span>
                  {s.auth && (
                    <span style={{
                      fontSize: 9, padding: '1px 6px', borderRadius: 3,
                      background: 'rgba(34,255,132,0.14)', color: 'var(--mc-green)',
                      border: '1px solid rgba(34,255,132,0.3)',
                      fontFamily: 'var(--mono)', fontWeight: 700,
                      display: 'flex', alignItems: 'center', gap: 3,
                    }}>
                      <I.shield size={9}/> VERIFIED
                    </span>
                  )}
                  <span style={{
                    fontSize: 9, padding: '1px 6px', borderRadius: 3,
                    background: 'rgba(255,255,255,0.06)', color: 'var(--ink-2)',
                    fontFamily: 'var(--mono)', fontWeight: 700, letterSpacing: 0.3,
                  }}>{s.kind.toUpperCase()}</span>
                </div>
                <div style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span>{s.addr}</span>
                  <button className="btn-icon" style={{ width: 20, height: 20, border: 'none', background: 'transparent', color: 'var(--ink-3)' }}>
                    <I.copy size={10}/>
                  </button>
                  <span style={{ opacity: 0.5 }}>·</span>
                  <span>{s.ver}</span>
                </div>
                <div style={{ fontSize: 11, color: 'var(--ink-2)', marginTop: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {s.motd}
                </div>
              </div>
              {/* Right stats */}
              <div style={{ width: 200, flexShrink: 0, padding: '12px 16px',
                display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6,
                borderLeft: '1px solid var(--line)' }}>
                {s.offline ? (
                  <div style={{ fontSize: 11, color: '#ff6b6b', fontFamily: 'var(--mono)', fontWeight: 700 }}>● OFFLINE</div>
                ) : (
                  <>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                      <SignalBars ping={s.ping}/>
                      <span style={{ fontSize: 11, fontFamily: 'var(--mono)', color: s.ping < 40 ? 'var(--mc-green)' : s.ping < 80 ? 'var(--amber)' : '#ff8080', fontWeight: 700 }}>
                        {s.ping}ms
                      </span>
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--ink-2)', fontFamily: 'var(--mono)' }}>
                      <span style={{ fontWeight: 800, color: 'var(--ink-0)' }}>{s.players.toLocaleString()}</span>
                      <span style={{ color: 'var(--ink-4)' }}> / {s.max.toLocaleString()}</span>
                    </div>
                    {/* tiny capacity bar */}
                    <div style={{ width: 140, height: 3, borderRadius: 2, background: 'var(--line)', overflow: 'hidden' }}>
                      <div style={{ width: `${Math.min(100,(s.players/s.max)*100)}%`, height: '100%',
                        background: 'linear-gradient(90deg, var(--mc-green) 0%, color-mix(in oklab, var(--mc-green) 60%, var(--cyan)) 100%)',
                        boxShadow: '0 0 6px var(--mc-green-glow)' }}/>
                    </div>
                  </>
                )}
                <div style={{ flex: 1 }}/>
                <div style={{ display: 'flex', gap: 4, marginTop: 4 }}>
                  <button className="btn-icon" style={{ width: 28, height: 28 }}><I.more size={12}/></button>
                  <button disabled={s.offline} className="btn-primary" style={{ padding: '6px 12px', fontSize: 11, opacity: s.offline ? 0.4 : 1 }}>
                    <I.play size={10}/> Join
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function SignalBars({ ping }) {
  const bars = ping < 40 ? 4 : ping < 80 ? 3 : ping < 150 ? 2 : 1;
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 2, height: 12 }}>
      {[1,2,3,4].map(n => (
        <div key={n} style={{
          width: 3, height: 3 + n*2, borderRadius: 1,
          background: n <= bars ? (ping < 40 ? 'var(--mc-green)' : ping < 80 ? 'var(--amber)' : '#ff8080') : 'var(--ink-4)',
          boxShadow: n <= bars ? '0 0 4px currentColor' : 'none',
        }}/>
      ))}
    </div>
  );
}

Object.assign(window, { ScreenServers });
