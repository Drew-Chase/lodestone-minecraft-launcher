// screen-worlds.jsx — local worlds browser
function ScreenWorlds() {
  const worlds = [
    { name: 'Aether Kingdom',   inst: 'Aether Legacy',    biome: 'cherry',  seed: 3,  gamemode: 'Survival',  difficulty: 'Hard',    size: '412 MB', played: '84h',  last: '2h ago',  seedStr: '-8429174632', version: '1.20.1', backed: true,  pinned: true },
    { name: 'Skyfall',          inst: 'All the Mods 9',   biome: 'end',     seed: 7,  gamemode: 'Creative',  difficulty: 'Peaceful',size: '1.2 GB', played: '23h',  last: 'Yesterday', seedStr: '1993', version: '1.20.1', backed: true },
    { name: 'Redstone Lab',     inst: 'Vanilla Tweaked',  biome: 'desert',  seed: 11, gamemode: 'Creative',  difficulty: 'Peaceful',size: '86 MB',  played: '7h',   last: '3d ago',  seedStr: '42', version: '1.20.4' },
    { name: 'Spruce Village',   inst: 'Better MC',        biome: 'snow',    seed: 14, gamemode: 'Survival',  difficulty: 'Normal',  size: '248 MB', played: '61h',  last: '5d ago',  seedStr: '2048', version: '1.20.1', backed: true },
    { name: 'Deepslate Mines',  inst: 'Vault Hunters 3',  biome: 'ocean',   seed: 19, gamemode: 'Hardcore',  difficulty: 'Hard',    size: '903 MB', played: '142h', last: '1w ago',  seedStr: 'dwarven', version: '1.20.1', backed: true },
    { name: 'Crimson Expedition',inst: 'Prominence II RPG',biome: 'nether', seed: 27, gamemode: 'Survival',  difficulty: 'Hard',    size: '522 MB', played: '38h',  last: '2w ago',  seedStr: '666999', version: '1.20.1' },
  ];
  const [tab, setTab] = React.useState('all');
  const [mode, setMode] = React.useState('grid');

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--bg-0)' }}>
      <TitleBar title="Worlds" subtitle={`${worlds.length} worlds across 6 instances · 3.4 GB total`}>
        <div style={{ position: 'relative' }}>
          <I.search size={14} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--ink-3)' }}/>
          <input placeholder="Search worlds by name or seed…" className="input"
                 style={{ paddingLeft: 34, width: 320 }}/>
        </div>
        <button className="btn-ghost" style={{ padding: '9px 14px' }}>
          <I.upload size={14}/> Import world
        </button>
        <button className="btn-primary" style={{ padding: '9px 14px' }}>
          <I.plus size={14}/> New world
        </button>
      </TitleBar>

      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 28px' }}>
        {/* Filter row */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 }}>
          <div style={{ display: 'flex', gap: 4 }}>
            {[
              {id:'all', label:'All worlds', count: worlds.length},
              {id:'pinned', label:'Pinned', count: worlds.filter(w => w.pinned).length},
              {id:'survival', label:'Survival', count: worlds.filter(w => w.gamemode==='Survival').length},
              {id:'creative', label:'Creative', count: worlds.filter(w => w.gamemode==='Creative').length},
              {id:'hardcore', label:'Hardcore', count: worlds.filter(w => w.gamemode==='Hardcore').length},
            ].map(t => (
              <button key={t.id} onClick={()=>setTab(t.id)}
                style={{
                  background: tab===t.id ? 'var(--bg-3)' : 'transparent',
                  border: '1px solid '+(tab===t.id ? 'var(--line-strong)' : 'transparent'),
                  color: tab===t.id ? 'var(--ink-0)' : 'var(--ink-2)',
                  padding: '6px 12px', borderRadius: 8, fontSize: 12, fontWeight: 600,
                  cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
                }}>
                {t.label}
                <span style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>{t.count}</span>
              </button>
            ))}
          </div>
          <div style={{ flex: 1 }}/>
          <div style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)', letterSpacing: 0.5 }}>
            LAST PLAYED ↓
          </div>
          <WorldViewToggle mode={mode} onChange={setMode}/>
        </div>

        {/* Grid */}
        {mode==='grid' ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
            {worlds.map((w,i) => (
              <div key={i} className="card" style={{ cursor: 'pointer' }}>
                <div style={{ position: 'relative', height: 150 }}>
                  <Scene biome={w.biome} seed={w.seed}/>
                  {/* top row: pinned + backup */}
                  <div style={{ position: 'absolute', top: 10, left: 10, right: 10, display: 'flex', gap: 6, zIndex: 2 }}>
                    {w.pinned && (
                      <span className="chip green" style={{ fontSize: 9, padding: '2px 7px' }}>
                        <I.pin size={9}/> PINNED
                      </span>
                    )}
                    <div style={{ flex: 1 }}/>
                    {w.backed && (
                      <span style={{
                        fontSize: 9, padding: '3px 7px', borderRadius: 999,
                        background: 'rgba(71,217,255,0.14)', color: 'var(--cyan)',
                        border: '1px solid rgba(71,217,255,0.3)',
                        fontFamily: 'var(--mono)', fontWeight: 700, letterSpacing: 0.5,
                        display: 'flex', alignItems: 'center', gap: 4,
                      }}>
                        <I.shield size={9}/> BACKED UP
                      </span>
                    )}
                  </div>
                  <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, transparent 50%, rgba(0,0,0,0.8) 100%)' }}/>
                  <div style={{ position: 'absolute', bottom: 10, left: 12, right: 12, zIndex: 2 }}>
                    <div style={{ fontSize: 15, fontWeight: 800, letterSpacing: -0.3, marginBottom: 2 }}>{w.name}</div>
                    <div style={{ fontSize: 10, color: 'var(--ink-2)', fontFamily: 'var(--mono)' }}>
                      {w.inst} · {w.version}
                    </div>
                  </div>
                </div>
                {/* stat row */}
                <div style={{ padding: '11px 14px', display: 'flex', alignItems: 'center', gap: 10, fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>
                  <WorldMode gamemode={w.gamemode} difficulty={w.difficulty}/>
                  <div style={{ flex: 1 }}/>
                  <span title="Playtime" style={{ display:'flex', alignItems:'center', gap:3 }}><I.clock size={10}/> {w.played}</span>
                  <span title="Size" style={{ display:'flex', alignItems:'center', gap:3 }}><I.hardDrive size={10}/> {w.size}</span>
                </div>
                {/* seed + actions */}
                <div style={{ padding: '0 14px 12px', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <div style={{
                    flex: 1, minWidth: 0,
                    padding: '6px 9px', borderRadius: 6,
                    background: 'rgba(255,255,255,0.03)', border: '1px solid var(--line)',
                    fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)',
                    overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                  }}>
                    SEED · {w.seedStr}
                  </div>
                  <button className="btn-icon" style={{ width: 30, height: 30 }} title="Copy seed"><I.copy size={13}/></button>
                  <button className="btn-icon" style={{ width: 30, height: 30 }} title="More"><I.more size={13}/></button>
                  <button className="btn-primary" style={{ padding: '6px 12px', fontSize: 11 }}><I.play size={11}/> Load</button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
            {worlds.map((w,i) => (
              <div key={i} style={{
                display: 'grid', gridTemplateColumns: '54px 1fr 1.1fr 1fr 0.8fr 0.6fr 100px',
                alignItems: 'center', gap: 14,
                padding: '10px 14px', borderBottom: i===worlds.length-1 ? 'none' : '1px solid var(--line)',
                fontSize: 12, cursor: 'pointer',
                background: i%2 ? 'rgba(255,255,255,0.015)' : 'transparent',
              }}>
                <div style={{ width: 44, height: 44, borderRadius: 6, overflow:'hidden', position:'relative' }}>
                  <Scene biome={w.biome} seed={w.seed}/>
                </div>
                <div style={{ minWidth: 0 }}>
                  <div style={{ display:'flex', alignItems:'center', gap: 6, marginBottom: 2 }}>
                    {w.pinned && <I.pin size={10} style={{ color: 'var(--mc-green)' }}/>}
                    <span style={{ fontWeight: 700, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{w.name}</span>
                  </div>
                  <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>{w.inst}</div>
                </div>
                <WorldMode gamemode={w.gamemode} difficulty={w.difficulty}/>
                <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>
                  <div>SEED · {w.seedStr}</div>
                  <div style={{ marginTop: 2 }}>{w.version}</div>
                </div>
                <div style={{ fontSize: 11, color: 'var(--ink-2)', fontFamily: 'var(--mono)' }}>
                  {w.played} · {w.size}
                </div>
                <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>{w.last}</div>
                <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                  <button className="btn-icon" style={{ width: 28, height: 28 }}><I.more size={12}/></button>
                  <button className="btn-primary" style={{ padding: '5px 11px', fontSize: 11 }}><I.play size={10}/> Load</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function WorldMode({ gamemode, difficulty }) {
  const color = gamemode === 'Hardcore' ? '#ff5e5e' : gamemode === 'Creative' ? 'var(--cyan)' : 'var(--mc-green)';
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      fontSize: 10, fontFamily: 'var(--mono)', fontWeight: 700, letterSpacing: 0.3,
    }}>
      <span style={{ width: 6, height: 6, borderRadius: '50%', background: color, boxShadow: `0 0 6px ${color}` }}/>
      <span style={{ color: 'var(--ink-2)' }}>{gamemode.toUpperCase()}</span>
      <span style={{ color: 'var(--ink-4)' }}>·</span>
      <span style={{ color: 'var(--ink-3)' }}>{difficulty.toUpperCase()}</span>
    </span>
  );
}

function WorldViewToggle({ mode, onChange }) {
  return (
    <div style={{ display:'flex', padding: 3, gap: 2, background: 'rgba(255,255,255,0.04)', border:'1px solid var(--line)', borderRadius: 10 }}>
      {[{id:'grid', i:I.grid},{id:'table', i:I.table}].map(o => {
        const Ic = o.i;
        const active = mode === o.id;
        return (
          <button key={o.id} onClick={()=>onChange(o.id)}
            style={{
              padding: '6px 10px', border: 'none', borderRadius: 7, cursor: 'pointer',
              background: active ? 'color-mix(in oklab, var(--mc-green) 18%, transparent)' : 'transparent',
              color: active ? 'var(--mc-green)' : 'var(--ink-2)',
              boxShadow: active ? 'inset 0 0 0 1px color-mix(in oklab, var(--mc-green) 40%, transparent)' : 'none',
            }}>
            <Ic size={13}/>
          </button>
        );
      })}
    </div>
  );
}

Object.assign(window, { ScreenWorlds });
