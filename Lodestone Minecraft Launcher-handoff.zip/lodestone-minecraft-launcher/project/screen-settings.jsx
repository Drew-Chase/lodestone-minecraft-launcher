// screen-settings.jsx — global settings, one artboard per tab
function ScreenSettings({ section = 'appearance' } = {}) {
  const sections = [
    { id: 'general',    icon: I.settings, label: 'General' },
    { id: 'account',    icon: I.user,     label: 'Accounts' },
    { id: 'java',       icon: I.cpu,      label: 'Java & Memory' },
    { id: 'appearance', icon: I.image,    label: 'Appearance' },
    { id: 'network',    icon: I.globe,    label: 'Network' },
    { id: 'privacy',    icon: I.lock,     label: 'Privacy' },
  ];
  const titleMap = {
    general:    { title: 'General',       subtitle: 'Startup, defaults and downloads' },
    account:    { title: 'Accounts',      subtitle: 'Microsoft and offline profiles' },
    java:       { title: 'Java & Memory', subtitle: 'Runtimes, heap allocation, JVM args' },
    appearance: { title: 'Appearance',    subtitle: 'Make Lodestone yours' },
    network:    { title: 'Network',       subtitle: 'Downloads, proxies, concurrency' },
    privacy:    { title: 'Privacy',       subtitle: 'Telemetry and data controls' },
  };

  return (
    <div style={{ flex: 1, display: 'flex', minWidth: 0, background: 'var(--bg-0)' }}>
      {/* Left sub-nav */}
      <div style={{ width: 220, borderRight: '1px solid var(--line)', padding: '24px 14px', flexShrink: 0 }}>
        <div style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)', letterSpacing: 1, marginBottom: 10, paddingLeft: 10 }}>
          SETTINGS
        </div>
        {sections.map(s => {
          const IconC = s.icon;
          const active = section === s.id;
          return (
            <div key={s.id} style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '9px 12px', borderRadius: 8, cursor: 'pointer',
              background: active ? 'rgba(34,255,132,0.08)' : 'transparent',
              color: active ? 'var(--mc-green)' : 'var(--ink-2)',
              fontSize: 13, marginBottom: 2, transition: 'all 0.12s',
              borderLeft: active ? '2px solid var(--mc-green)' : '2px solid transparent',
            }}>
              <IconC size={15}/> {s.label}
            </div>
          );
        })}
      </div>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <TitleBar title={titleMap[section].title} subtitle={titleMap[section].subtitle}>
          <button className="btn-ghost"><I.refresh size={13}/> Reset</button>
          <button className="btn-primary">Save changes</button>
        </TitleBar>

        <div style={{ flex: 1, overflowY: 'auto', padding: '28px 32px 40px', maxWidth: 820 }}>
          {section === 'general'    && <GeneralPane/>}
          {section === 'account'    && <AccountsPane/>}
          {section === 'java'       && <JavaPane/>}
          {section === 'appearance' && <AppearancePane/>}
          {section === 'network'    && <NetworkPane/>}
          {section === 'privacy'    && <PrivacyPane/>}
        </div>
      </div>
    </div>
  );
}

// ── Reusable rows ──
function SettingCard({ title, desc, children }) {
  return (
    <div className="card" style={{ padding: 22, marginBottom: 16 }}>
      {title && <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>{title}</div>}
      {desc && <div style={{ fontSize: 12, color: 'var(--ink-3)', marginBottom: 16 }}>{desc}</div>}
      {children}
    </div>
  );
}
function ToggleRow({ label, desc, on, last }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 14, padding: '16px 18px',
      borderBottom: last ? 'none' : '1px solid var(--line)',
    }}>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13, fontWeight: 600 }}>{label}</div>
        {desc && <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>{desc}</div>}
      </div>
      <div className={`toggle ${on ? 'on' : ''}`}/>
    </div>
  );
}
function SelectRow({ label, value, last }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 14, padding: '14px 18px',
      borderBottom: last ? 'none' : '1px solid var(--line)',
    }}>
      <div style={{ flex: 1, fontSize: 13, fontWeight: 500 }}>{label}</div>
      <button className="select">{value} <I.chevDown size={11}/></button>
    </div>
  );
}

// ── General ──
function GeneralPane() {
  return (
    <>
      <SettingCard>
        <div style={{ margin: -4 }}>
          <SelectRow label="Default instance directory" value="~/Lodestone/instances"/>
          <SelectRow label="Startup behavior" value="Show library"/>
          <SelectRow label="On game launch" value="Minimize launcher"/>
          <SelectRow label="After game exits" value="Restore launcher" last/>
        </div>
      </SettingCard>
      <SettingCard title="Updates" desc="How Lodestone updates itself and Minecraft.">
        <div style={{ margin: -4 }}>
          <ToggleRow label="Auto-update Lodestone" desc="Install stable releases in the background" on={true}/>
          <ToggleRow label="Beta channel" desc="Get new features early (may be unstable)" on={false}/>
          <ToggleRow label="Auto-update game versions" desc="Pull new Minecraft releases automatically" on={true} last/>
        </div>
      </SettingCard>
      <SettingCard title="Concurrent downloads" desc="How many files to fetch at once per instance.">
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ position: 'relative', flex: 1, height: 6, background: 'var(--line)', borderRadius: 3 }}>
            <div style={{ position: 'absolute', left: 0, width: '55%', height: '100%', borderRadius: 3,
                          background: 'var(--mc-green)', boxShadow: '0 0 10px var(--mc-green-glow)' }}/>
            <div style={{ position: 'absolute', left: '55%', width: 16, height: 16, borderRadius: '50%',
                          background: '#fff', top: -5, transform: 'translateX(-50%)',
                          boxShadow: '0 2px 6px rgba(0,0,0,0.5), 0 0 0 3px rgba(34,255,132,0.25)' }}/>
          </div>
          <div style={{ fontFamily: 'var(--mono)', fontSize: 13, fontWeight: 700, minWidth: 28, textAlign: 'right' }}>11</div>
        </div>
      </SettingCard>
    </>
  );
}

// ── Accounts ──
function AccountsPane() {
  const accounts = [
    { name: 'Notch_37',  email: 'user@outlook.com', type: 'Microsoft', primary: true, color: '#22ff84' },
    { name: 'Steve',     email: 'Offline profile',  type: 'Offline',   color: '#9747ff' },
    { name: 'Alex_Dev',  email: 'dev@outlook.com',  type: 'Microsoft', color: '#47d9ff' },
  ];
  return (
    <>
      <SettingCard title="Signed-in accounts" desc="Switch between profiles with one click.">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {accounts.map((a, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 14,
              padding: '12px 14px', borderRadius: 10,
              border: a.primary ? '1px solid rgba(34,255,132,0.4)' : '1px solid var(--line)',
              background: a.primary ? 'rgba(34,255,132,0.05)' : 'rgba(255,255,255,0.02)',
            }}>
              <div style={{ width: 40, height: 40, borderRadius: 8,
                            background: `linear-gradient(135deg, ${a.color}, #0a5c33)`,
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            fontWeight: 800, fontSize: 14, color: '#062814' }}>
                {a.name[0]}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8 }}>
                  {a.name}
                  {a.primary && <span className="chip green" style={{ fontSize: 9 }}>PRIMARY</span>}
                </div>
                <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>{a.email} · {a.type}</div>
              </div>
              <button className="btn-icon" style={{ width: 32, height: 32 }}><I.more size={14}/></button>
            </div>
          ))}
          <button className="btn-ghost" style={{ marginTop: 6, justifyContent: 'center', padding: '12px' }}>
            <I.plus size={13}/> Add Microsoft account
          </button>
        </div>
      </SettingCard>
      <SkinBrowser/>
    </>
  );
}

// ── Java & Memory ──
function JavaPane() {
  const runtimes = [
    { label: 'Java 21 · Temurin', path: '/Library/Java/JavaVirtualMachines/temurin-21', active: true },
    { label: 'Java 17 · Zulu',     path: '~/.lodestone/java/zulu-17', active: false },
    { label: 'Java 8 · Corretto',  path: '~/.lodestone/java/corretto-8', active: false },
  ];
  return (
    <>
      <SettingCard title="Memory allocation" desc="Maximum RAM given to a Minecraft instance.">
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 16 }}>
          <div style={{ position: 'relative', flex: 1, height: 8, background: 'var(--line)', borderRadius: 4 }}>
            <div style={{ position: 'absolute', left: 0, width: '50%', height: '100%', borderRadius: 4,
                          background: 'linear-gradient(90deg, var(--cyan), var(--mc-green))',
                          boxShadow: '0 0 12px var(--mc-green-glow)' }}/>
            <div style={{ position: 'absolute', left: '50%', width: 18, height: 18, borderRadius: '50%',
                          background: '#fff', top: -5, transform: 'translateX(-50%)',
                          boxShadow: '0 2px 6px rgba(0,0,0,0.5), 0 0 0 4px rgba(34,255,132,0.25)' }}/>
          </div>
          <div style={{ fontFamily: 'var(--mono)', fontSize: 14, fontWeight: 700, minWidth: 60, textAlign: 'right' }}>8 GB</div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10,
                      color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>
          <span>2 GB · minimum</span><span>8 GB · recommended</span><span>16 GB · system max</span>
        </div>
      </SettingCard>

      <SettingCard title="Installed runtimes" desc="Per-instance Java — newest versions auto-downloaded.">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {runtimes.map((r, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '12px 14px', borderRadius: 10,
              border: r.active ? '1px solid rgba(34,255,132,0.4)' : '1px solid var(--line)',
              background: r.active ? 'rgba(34,255,132,0.05)' : 'transparent',
            }}>
              <I.cpu size={15} style={{ color: r.active ? 'var(--mc-green)' : 'var(--ink-3)' }}/>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{r.label}</div>
                <div style={{ fontSize: 10, color: 'var(--ink-4)', fontFamily: 'var(--mono)',
                              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.path}</div>
              </div>
              {r.active
                ? <span className="chip green" style={{ fontSize: 9 }}>DEFAULT</span>
                : <button className="btn-ghost" style={{ padding: '5px 10px', fontSize: 11 }}>Use</button>}
            </div>
          ))}
          <button className="btn-ghost" style={{ marginTop: 4, justifyContent: 'center', padding: 10 }}>
            <I.plus size={13}/> Add custom runtime
          </button>
        </div>
      </SettingCard>

      <SettingCard title="JVM arguments" desc="Passed to java before -jar.">
        <div style={{
          fontFamily: 'var(--mono)', fontSize: 12, color: 'var(--mc-green)',
          background: '#05060a', border: '1px solid var(--line)', borderRadius: 8,
          padding: 14, lineHeight: 1.6, whiteSpace: 'pre-wrap', wordBreak: 'break-all',
        }}>
          -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200{'\n'}
          -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:+AlwaysPreTouch
        </div>
      </SettingCard>
    </>
  );
}

// ── Appearance ──
function AppearancePane() {
  const accents = ['#22ff84', '#9747ff', '#ffb545', '#47d9ff', '#ff5ec8', '#ff6b3d'];
  const active = '#22ff84';
  return (
    <>
      <SettingCard title="Accent color" desc="Primary highlight used across the interface.">
        <div style={{ display: 'flex', gap: 10 }}>
          {accents.map(c => (
            <div key={c} style={{
              width: 44, height: 44, borderRadius: 12, cursor: 'pointer',
              background: c, position: 'relative',
              boxShadow: active === c ? `0 0 0 2px var(--bg-0), 0 0 0 4px ${c}, 0 0 20px ${c}80` : 'none',
            }}>
              {active === c && <I.check size={16} style={{ position: 'absolute', inset: 0, margin: 'auto', color: '#000' }}/>}
            </div>
          ))}
          <div style={{
            width: 44, height: 44, borderRadius: 12, cursor: 'pointer', border: '2px dashed var(--line-strong)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--ink-3)',
          }}><I.plus size={16}/></div>
        </div>
      </SettingCard>

      <SettingCard title="Theme" desc="Global color scheme and surface treatment.">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
          {[
            { id: 'void', name: 'Void', bg: '#08090a', active: true },
            { id: 'slate', name: 'Slate', bg: '#14181f' },
            { id: 'obsidian', name: 'Obsidian', bg: '#1a0f1e' },
          ].map(t => (
            <div key={t.id} style={{
              height: 110, borderRadius: 12, cursor: 'pointer',
              background: t.bg, position: 'relative', overflow: 'hidden',
              border: t.active ? '2px solid var(--mc-green)' : '1px solid var(--line)',
              boxShadow: t.active ? '0 0 0 4px rgba(34,255,132,0.12)' : 'none',
            }}>
              <div style={{ position: 'absolute', top: 10, left: 10, right: 10, height: 8, background: 'rgba(255,255,255,0.08)', borderRadius: 3 }}/>
              <div style={{ position: 'absolute', top: 24, left: 10, width: 30, height: 30, borderRadius: 6, background: active }}/>
              <div style={{ position: 'absolute', top: 24, left: 46, right: 10, height: 30, background: 'rgba(255,255,255,0.06)', borderRadius: 6 }}/>
              <div style={{ position: 'absolute', bottom: 10, left: 10, fontSize: 11, fontWeight: 700 }}>{t.name}</div>
            </div>
          ))}
        </div>
      </SettingCard>

      <div className="card" style={{ padding: 4, marginBottom: 16 }}>
        <ToggleRow label="Interface animations" desc="Card hovers, page transitions, micro-interactions" on={true}/>
        <ToggleRow label="Ambient particles" desc="Floating dust on hero banners" on={true}/>
        <ToggleRow label="Glass effect" desc="Frosted blur on panels and popovers" on={true}/>
        <ToggleRow label="Aurora backgrounds" desc="Soft color glows on idle screens" on={true}/>
        <ToggleRow label="Reduce motion" desc="Respect system prefers-reduced-motion" on={false} last/>
      </div>

      <SettingCard title="Typography" desc="Interface font.">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {[
            { name: 'Inter', desc: 'Geometric sans · default', active: true },
            { name: 'Space Grotesk', desc: 'Rounded geometric · playful' },
          ].map(f => (
            <div key={f.name} style={{
              padding: 14, borderRadius: 10,
              border: f.active ? '1px solid var(--mc-green)' : '1px solid var(--line)',
              background: f.active ? 'rgba(34,255,132,0.05)' : 'transparent',
              cursor: 'pointer',
            }}>
              <div style={{ fontSize: 24, fontWeight: 800, letterSpacing: -0.5, marginBottom: 2 }}>Aa Bb Cc</div>
              <div style={{ fontSize: 12, fontWeight: 600 }}>{f.name}</div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>{f.desc}</div>
            </div>
          ))}
        </div>
      </SettingCard>
    </>
  );
}

// ── Network ──
function NetworkPane() {
  return (
    <>
      <SettingCard title="Download speed" desc="Live, averaged over the last hour.">
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 14 }}>
          <div style={{ fontSize: 36, fontWeight: 800, fontFamily: 'var(--mono)', color: 'var(--mc-green)',
                        textShadow: '0 0 18px var(--mc-green-glow)' }}>42.8</div>
          <div style={{ fontSize: 13, color: 'var(--ink-3)' }}>MB/s</div>
          <div style={{ flex: 1 }}/>
          <span className="chip green"><span className="pulse-dot" style={{ width: 5, height: 5 }}/> CONNECTED</span>
        </div>
        {/* sparkline */}
        <svg viewBox="0 0 300 50" style={{ width: '100%', height: 50 }}>
          <defs>
            <linearGradient id="spark" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0" stopColor="#22ff84" stopOpacity="0.4"/>
              <stop offset="1" stopColor="#22ff84" stopOpacity="0"/>
            </linearGradient>
          </defs>
          <path d="M0 35 L15 28 L30 32 L45 22 L60 26 L75 16 L90 20 L105 14 L120 24 L135 18 L150 10 L165 22 L180 16 L195 28 L210 20 L225 12 L240 24 L255 18 L270 8 L285 16 L300 12 L300 50 L0 50 Z" fill="url(#spark)"/>
          <path d="M0 35 L15 28 L30 32 L45 22 L60 26 L75 16 L90 20 L105 14 L120 24 L135 18 L150 10 L165 22 L180 16 L195 28 L210 20 L225 12 L240 24 L255 18 L270 8 L285 16 L300 12"
                stroke="var(--mc-green)" strokeWidth="1.5" fill="none"/>
        </svg>
      </SettingCard>

      <SettingCard>
        <div style={{ margin: -4 }}>
          <SelectRow label="Max concurrent downloads" value="8"/>
          <SelectRow label="Mod source priority" value="Modrinth → CurseForge"/>
          <SelectRow label="Asset CDN" value="Auto (closest)"/>
          <SelectRow label="Connection timeout" value="30 s" last/>
        </div>
      </SettingCard>

      <SettingCard title="Proxy" desc="For restricted or corporate networks.">
        <div style={{ margin: -4 }}>
          <ToggleRow label="Use system proxy" desc="Follow the OS network configuration" on={true}/>
          <ToggleRow label="Custom HTTP proxy" desc="Override with proxy.yourorg.com:3128" on={false} last/>
        </div>
      </SettingCard>
    </>
  );
}

// ── Privacy ──
function PrivacyPane() {
  return (
    <>
      <SettingCard title="Telemetry" desc="Help improve Lodestone by sending anonymous usage data.">
        <div style={{ margin: -4 }}>
          <ToggleRow label="Send crash reports" desc="Stack traces with no personal data attached" on={true}/>
          <ToggleRow label="Anonymous usage stats" desc="Feature usage counters only" on={true}/>
          <ToggleRow label="Performance diagnostics" desc="FPS + launch times, per instance" on={false} last/>
        </div>
      </SettingCard>

      <SettingCard title="Mod data permissions" desc="Mods can request access to your system.">
        <div style={{ margin: -4 }}>
          <ToggleRow label="Allow filesystem access" desc="For mods with map import or screenshots" on={true}/>
          <ToggleRow label="Allow network requests" desc="Online skins, online leaderboards" on={true}/>
          <ToggleRow label="Allow hardware access" desc="Input devices, controllers, VR headsets" on={false} last/>
        </div>
      </SettingCard>

      <SettingCard title="Data" desc="Export or clear everything stored locally.">
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          <button className="btn-ghost"><I.download size={13}/> Export my data</button>
          <button className="btn-ghost"><I.refresh size={13}/> Clear cache · 1.2 GB</button>
          <button className="btn-ghost" style={{ color: '#ff6b6b', borderColor: 'rgba(255,107,107,0.3)' }}>
            <I.x size={13}/> Delete all local data
          </button>
        </div>
      </SettingCard>
    </>
  );
}

Object.assign(window, { ScreenSettings });
